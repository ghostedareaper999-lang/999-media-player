
import { IconSymbol } from '@/components/IconSymbol';
import { AnimatingThumbnail } from '@/components/AnimatingThumbnail';
import Slider from '@react-native-community/slider';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Modal,
  TextInput,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { useAudioPeakDetector } from '@/hooks/useAudioPeakDetector';
import { useRouter } from 'expo-router';
import { WaveformSeekbar } from '@/components/WaveformSeekbar';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  Easing,
} from 'react-native-reanimated';
import React, { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { usePlayer } from '@/contexts/PlayerContext';
import { colors, spacing, borderRadius, typography, formatDuration } from '@/styles/commonStyles';
import { useDynamicColors } from '@/hooks/useDynamicColors';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ParticleEffect } from '@/components/ParticleEffect';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  gradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '60%',
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.md,
  },
  headerButton: {
    padding: spacing.sm,
  },
  artworkContainer: {
    alignItems: 'center',
    marginTop: spacing.xl,
    marginBottom: spacing.xl,
  },
  trackInfo: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  trackTitle: {
    ...typography.headlineSmall,
    color: colors.text,
    textAlign: 'center',
    marginBottom: spacing.xs,
  },
  trackArtist: {
    ...typography.bodyLarge,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.xs,
  },
  trackAlbum: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  waveformContainer: {
    marginBottom: spacing.lg,
  },
  timeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.lg,
  },
  timeText: {
    ...typography.labelMedium,
    color: colors.textSecondary,
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: spacing.lg,
    marginBottom: spacing.xl,
  },
  controlButton: {
    padding: spacing.sm,
  },
  playButton: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  secondaryControls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  volumeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.lg,
  },
  slider: {
    flex: 1,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.xl,
    width: SCREEN_WIDTH - spacing.xl * 2,
    maxHeight: '80%',
  },
  modalTitle: {
    ...typography.headlineSmall,
    color: colors.text,
    marginBottom: spacing.lg,
    textAlign: 'center',
  },
  speedOption: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    marginBottom: spacing.sm,
    backgroundColor: colors.surfaceVariant,
  },
  speedOptionActive: {
    backgroundColor: colors.primaryContainer,
  },
  speedOptionText: {
    ...typography.bodyLarge,
    color: colors.text,
    textAlign: 'center',
  },
  closeButton: {
    marginTop: spacing.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    borderRadius: borderRadius.md,
    backgroundColor: colors.primary,
    alignItems: 'center',
  },
  closeButtonText: {
    ...typography.labelLarge,
    color: colors.onPrimary,
  },
});

export default function PlayerScreen() {
  const router = useRouter();
  const player = usePlayer();
  const [showSpeedModal, setShowSpeedModal] = useState(false);
  const [animatingThumbnail, setAnimatingThumbnail] = useState(true);
  const [particleEffects, setParticleEffects] = useState(true);
  const [waveformStyle, setWaveformStyle] = useState<'bars' | 'line' | 'filled' | 'gradient'>('bars');

  const audioPeak = useAudioPeakDetector(player.currentTrack ? {} : null);
  const dynamicColors = useDynamicColors(player.currentTrack?.artworkUrl);

  useEffect(() => {
    loadPlayerSettings();
  }, []);

  const loadPlayerSettings = async () => {
    try {
      const settings = await AsyncStorage.getItem('player_settings');
      if (settings) {
        const parsed = JSON.parse(settings);
        setAnimatingThumbnail(parsed.animatingThumbnail ?? true);
        setParticleEffects(parsed.particleEffects ?? true);
        setWaveformStyle(parsed.waveformStyle ?? 'bars');
        console.log('Loaded player settings');
      }
    } catch (error) {
      console.error('Error loading player settings:', error);
    }
  };

  const savePlayerSettings = async () => {
    try {
      const settings = {
        animatingThumbnail,
        particleEffects,
        waveformStyle,
      };
      await AsyncStorage.setItem('player_settings', JSON.stringify(settings));
      console.log('Saved player settings');
    } catch (error) {
      console.error('Error saving player settings:', error);
    }
  };

  useEffect(() => {
    savePlayerSettings();
  }, [animatingThumbnail, particleEffects, waveformStyle]);

  const handleClose = () => {
    console.log('Closing player screen');
    router.back();
  };

  if (!player.currentTrack) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.headerButton} onPress={handleClose}>
            <IconSymbol
              ios_icon_name="chevron.down"
              android_material_icon_name="arrow-back"
              size={28}
              color={colors.text}
            />
          </TouchableOpacity>
        </View>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <Text style={styles.trackTitle}>No track playing</Text>
        </View>
      </SafeAreaView>
    );
  }

  const handlePlayPause = () => {
    if (player.isPlaying) {
      player.pause();
    } else {
      player.resume();
    }
  };

  const handleSeek = (value: number) => {
    player.seekTo(value);
  };

  const handleSpeedChange = (speed: number) => {
    player.setPlaybackRate(speed);
    setShowSpeedModal(false);
  };

  const handleVolumeChange = (volume: number) => {
    player.setVolume(volume);
  };

  const trackTitle = player.currentTrack.title || player.currentTrack.fileName;
  const trackArtist = player.currentTrack.artist || 'Unknown Artist';
  const trackAlbum = player.currentTrack.album || '';

  const currentTimeFormatted = formatDuration(player.currentTime);
  const durationFormatted = formatDuration(player.duration);

  const gradientColors = dynamicColors
    ? [dynamicColors.darkVibrant, dynamicColors.darkMuted, colors.background]
    : [colors.primaryContainer, colors.tertiaryContainer, colors.background];

  const particleColor = dynamicColors?.vibrant || colors.primary;

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={gradientColors} style={styles.gradient} />
      
      {particleEffects && (
        <ParticleEffect
          audioPeak={audioPeak}
          enabled={particleEffects}
          particleCount={30}
          color={particleColor}
        />
      )}

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.headerButton} onPress={handleClose}>
            <IconSymbol
              ios_icon_name="chevron.down"
              android_material_icon_name="arrow-back"
              size={28}
              color={colors.text}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => router.push('/settings')}
          >
            <IconSymbol
              ios_icon_name="ellipsis"
              android_material_icon_name="more-vert"
              size={28}
              color={colors.text}
            />
          </TouchableOpacity>
        </View>

        <View style={styles.artworkContainer}>
          {animatingThumbnail ? (
            <AnimatingThumbnail
              source={player.currentTrack.artworkUrl}
              audioPeak={audioPeak}
              size={SCREEN_WIDTH - spacing.xl * 2}
              borderRadius={borderRadius.xl}
            />
          ) : (
            <View
              style={{
                width: SCREEN_WIDTH - spacing.xl * 2,
                height: SCREEN_WIDTH - spacing.xl * 2,
                borderRadius: borderRadius.xl,
                backgroundColor: colors.surfaceVariant,
              }}
            />
          )}
        </View>

        <View style={styles.trackInfo}>
          <Text style={styles.trackTitle} numberOfLines={2}>
            {trackTitle}
          </Text>
          <Text style={styles.trackArtist} numberOfLines={1}>
            {trackArtist}
          </Text>
          {trackAlbum && (
            <Text style={styles.trackAlbum} numberOfLines={1}>
              {trackAlbum}
            </Text>
          )}
        </View>

        <View style={styles.waveformContainer}>
          <WaveformSeekbar
            player={player}
            currentTime={player.currentTime}
            duration={player.duration}
            onSeek={handleSeek}
            style={waveformStyle}
            color={dynamicColors?.vibrant || colors.primary}
            height={60}
          />
        </View>

        <View style={styles.timeContainer}>
          <Text style={styles.timeText}>{currentTimeFormatted}</Text>
          <Text style={styles.timeText}>{durationFormatted}</Text>
        </View>

        <View style={styles.controls}>
          <TouchableOpacity style={styles.controlButton} onPress={player.previous}>
            <IconSymbol
              ios_icon_name="backward.fill"
              android_material_icon_name="skip-previous"
              size={36}
              color={colors.text}
            />
          </TouchableOpacity>

          <TouchableOpacity style={styles.playButton} onPress={handlePlayPause}>
            <IconSymbol
              ios_icon_name={player.isPlaying ? 'pause.fill' : 'play.fill'}
              android_material_icon_name={player.isPlaying ? 'pause' : 'play-arrow'}
              size={40}
              color={colors.onPrimary}
            />
          </TouchableOpacity>

          <TouchableOpacity style={styles.controlButton} onPress={player.next}>
            <IconSymbol
              ios_icon_name="forward.fill"
              android_material_icon_name="skip-next"
              size={36}
              color={colors.text}
            />
          </TouchableOpacity>
        </View>

        <View style={styles.secondaryControls}>
          <TouchableOpacity style={styles.controlButton} onPress={player.toggleShuffle}>
            <IconSymbol
              ios_icon_name="shuffle"
              android_material_icon_name="shuffle"
              size={24}
              color={player.isShuffle ? colors.primary : colors.textSecondary}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.controlButton}
            onPress={() => setShowSpeedModal(true)}
          >
            <Text style={{ color: colors.text, fontSize: 16 }}>
              {player.playbackRate}x
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.controlButton} onPress={player.toggleLoop}>
            <IconSymbol
              ios_icon_name="repeat"
              android_material_icon_name="repeat"
              size={24}
              color={player.isLooping ? colors.primary : colors.textSecondary}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.controlButton}
            onPress={() => router.push('/queue')}
          >
            <IconSymbol
              ios_icon_name="list.bullet"
              android_material_icon_name="queue-music"
              size={24}
              color={colors.text}
            />
          </TouchableOpacity>
        </View>

        <View style={styles.volumeContainer}>
          <IconSymbol
            ios_icon_name="speaker.fill"
            android_material_icon_name="volume-down"
            size={24}
            color={colors.textSecondary}
          />
          <Slider
            style={styles.slider}
            minimumValue={0}
            maximumValue={1}
            value={player.volume}
            onValueChange={handleVolumeChange}
            minimumTrackTintColor={colors.primary}
            maximumTrackTintColor={colors.outlineVariant}
            thumbTintColor={colors.primary}
          />
          <IconSymbol
            ios_icon_name="speaker.wave.3.fill"
            android_material_icon_name="volume-up"
            size={24}
            color={colors.textSecondary}
          />
        </View>
      </ScrollView>

      <Modal
        visible={showSpeedModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowSpeedModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Playback Speed</Text>
            {[0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0].map((speed) => (
              <TouchableOpacity
                key={speed}
                style={[
                  styles.speedOption,
                  player.playbackRate === speed && styles.speedOptionActive,
                ]}
                onPress={() => handleSpeedChange(speed)}
              >
                <Text style={styles.speedOptionText}>{speed}x</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setShowSpeedModal(false)}
            >
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
