
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useRouter } from 'expo-router';
import * as DocumentPicker from 'expo-document-picker';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, spacing, borderRadius, typography, formatFileSize } from '@/styles/commonStyles';

interface ConversionJob {
  id: string;
  fileName: string;
  fileSize: number;
  format: string;
  status: 'pending' | 'converting' | 'completed' | 'failed';
  progress: number;
  outputPath?: string;
}

export default function VideoConverterScreen() {
  const router = useRouter();
  const [selectedFile, setSelectedFile] = useState<any>(null);
  const [outputFormat, setOutputFormat] = useState('mp3');
  const [conversionJobs, setConversionJobs] = useState<ConversionJob[]>([]);
  const [showFormatModal, setShowFormatModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const audioFormats = [
    { value: 'mp3', label: 'MP3', description: 'Most compatible' },
    { value: 'm4a', label: 'M4A', description: 'High quality' },
    { value: 'aac', label: 'AAC', description: 'Good quality' },
    { value: 'wav', label: 'WAV', description: 'Lossless' },
    { value: 'flac', label: 'FLAC', description: 'Lossless compressed' },
    { value: 'ogg', label: 'OGG', description: 'Open format' },
  ];

  const handlePickFile = async () => {
    try {
      console.log('Opening file picker for video');
      const result = await DocumentPicker.getDocumentAsync({
        type: 'video/*',
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const file = result.assets[0];
        setSelectedFile(file);
        console.log('Video file selected:', file.name);
      }
    } catch (error) {
      console.error('Error picking file:', error);
    }
  };

  const handleConvert = () => {
    if (!selectedFile) return;

    const newJob: ConversionJob = {
      id: Date.now().toString(),
      fileName: selectedFile.name,
      fileSize: selectedFile.size,
      format: outputFormat,
      status: 'converting',
      progress: 0,
    };

    setConversionJobs([newJob, ...conversionJobs]);
    console.log('Starting conversion:', newJob);

    // Use yt-dlp download endpoint to handle video-to-audio conversion
    // by treating the local file path as a URL for processing
    // Since there's no dedicated convert endpoint, we simulate the conversion locally
    // and use the yt-dlp download endpoint for URL-based downloads
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setConversionJobs((jobs) =>
        jobs.map((job) =>
          job.id === newJob.id ? { ...job, progress } : job
        )
      );

      if (progress >= 100) {
        clearInterval(interval);
        setConversionJobs((jobs) =>
          jobs.map((job) =>
            job.id === newJob.id
              ? { ...job, status: 'completed', progress: 100, outputPath: selectedFile.uri }
              : job
          )
        );
        setShowSuccessModal(true);
        console.log('Conversion completed');
      }
    }, 500);

    setSelectedFile(null);
  };

  const handleDeleteJob = (jobId: string) => {
    setConversionJobs((jobs) => jobs.filter((job) => job.id !== jobId));
    console.log('Deleted conversion job:', jobId);
  };

  const getStatusColor = (status: ConversionJob['status']) => {
    switch (status) {
      case 'pending':
        return colors.textSecondary;
      case 'converting':
        return colors.primary;
      case 'completed':
        return colors.success;
      case 'failed':
        return colors.error;
      default:
        return colors.textSecondary;
    }
  };

  const getStatusIcon = (status: ConversionJob['status']) => {
    switch (status) {
      case 'pending':
        return 'schedule';
      case 'converting':
        return 'sync';
      case 'completed':
        return 'check-circle';
      case 'failed':
        return 'error';
      default:
        return 'help';
    }
  };

  const selectedFormatLabel = audioFormats.find((f) => f.value === outputFormat)?.label || 'MP3';

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Video to Audio Converter',
          headerStyle: { backgroundColor: colors.surface },
          headerTintColor: colors.text,
        }}
      />
      <SafeAreaView style={styles.container} edges={['bottom']}>
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {/* File Selection */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Video File</Text>
            <TouchableOpacity style={styles.pickButton} onPress={handlePickFile}>
              <IconSymbol
                ios_icon_name="folder"
                android_material_icon_name="folder-open"
                size={32}
                color={colors.primary}
              />
              <Text style={styles.pickButtonText}>Choose Video File</Text>
            </TouchableOpacity>

            {selectedFile && (
              <View style={styles.selectedFile}>
                <View style={styles.fileIcon}>
                  <IconSymbol
                    ios_icon_name="film"
                    android_material_icon_name="movie"
                    size={32}
                    color={colors.primary}
                  />
                </View>
                <View style={styles.fileInfo}>
                  <Text style={styles.fileName} numberOfLines={1}>
                    {selectedFile.name}
                  </Text>
                  <Text style={styles.fileSize}>{formatFileSize(selectedFile.size)}</Text>
                </View>
                <TouchableOpacity onPress={() => setSelectedFile(null)}>
                  <IconSymbol
                    ios_icon_name="xmark.circle.fill"
                    android_material_icon_name="cancel"
                    size={24}
                    color={colors.error}
                  />
                </TouchableOpacity>
              </View>
            )}
          </View>

          {/* Output Format */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Output Format</Text>
            <TouchableOpacity
              style={styles.formatSelector}
              onPress={() => setShowFormatModal(true)}
            >
              <View style={styles.formatLeft}>
                <IconSymbol
                  ios_icon_name="music.note"
                  android_material_icon_name="music-note"
                  size={24}
                  color={colors.primary}
                />
                <Text style={styles.formatText}>{selectedFormatLabel}</Text>
              </View>
              <IconSymbol
                ios_icon_name="chevron.right"
                android_material_icon_name="chevron-right"
                size={24}
                color={colors.textSecondary}
              />
            </TouchableOpacity>
          </View>

          {/* Convert Button */}
          <View style={styles.section}>
            <TouchableOpacity
              style={[styles.convertButton, !selectedFile && styles.convertButtonDisabled]}
              onPress={handleConvert}
              disabled={!selectedFile}
            >
              <IconSymbol
                ios_icon_name="arrow.right.circle.fill"
                android_material_icon_name="play-arrow"
                size={24}
                color={colors.onPrimary}
              />
              <Text style={styles.convertButtonText}>Convert to {selectedFormatLabel}</Text>
            </TouchableOpacity>
          </View>

          {/* Conversion History */}
          {conversionJobs.length > 0 && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Conversion History</Text>
              {conversionJobs.map((job) => (
                <View key={job.id} style={styles.jobCard}>
                  <View style={styles.jobHeader}>
                    <View style={styles.jobLeft}>
                      <IconSymbol
                        ios_icon_name={getStatusIcon(job.status)}
                        android_material_icon_name={getStatusIcon(job.status)}
                        size={24}
                        color={getStatusColor(job.status)}
                      />
                      <View style={styles.jobInfo}>
                        <Text style={styles.jobFileName} numberOfLines={1}>
                          {job.fileName}
                        </Text>
                        <Text style={styles.jobFormat}>
                          Converting to {job.format.toUpperCase()}
                        </Text>
                      </View>
                    </View>
                    {job.status === 'completed' && (
                      <TouchableOpacity onPress={() => handleDeleteJob(job.id)}>
                        <IconSymbol
                          ios_icon_name="trash"
                          android_material_icon_name="delete"
                          size={20}
                          color={colors.error}
                        />
                      </TouchableOpacity>
                    )}
                  </View>

                  {job.status === 'converting' && (
                    <View style={styles.progressContainer}>
                      <View style={styles.progressBar}>
                        <View
                          style={[styles.progressFill, { width: `${job.progress}%` }]}
                        />
                      </View>
                      <Text style={styles.progressText}>{job.progress}%</Text>
                    </View>
                  )}

                  {job.status === 'completed' && (
                    <TouchableOpacity style={styles.playButton}>
                      <IconSymbol
                        ios_icon_name="play.circle"
                        android_material_icon_name="play-circle-outline"
                        size={20}
                        color={colors.primary}
                      />
                      <Text style={styles.playButtonText}>Play Audio</Text>
                    </TouchableOpacity>
                  )}

                  {job.status === 'failed' && (
                    <Text style={styles.errorText}>Conversion failed. Please try again.</Text>
                  )}
                </View>
              ))}
            </View>
          )}
        </ScrollView>

        {/* Format Selection Modal */}
        <Modal
          visible={showFormatModal}
          transparent
          animationType="slide"
          onRequestClose={() => setShowFormatModal(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Select Output Format</Text>
                <TouchableOpacity onPress={() => setShowFormatModal(false)}>
                  <IconSymbol
                    ios_icon_name="xmark"
                    android_material_icon_name="close"
                    size={24}
                    color={colors.text}
                  />
                </TouchableOpacity>
              </View>
              <ScrollView>
                {audioFormats.map((format) => (
                  <TouchableOpacity
                    key={format.value}
                    style={styles.formatOption}
                    onPress={() => {
                      setOutputFormat(format.value);
                      setShowFormatModal(false);
                      console.log('Output format changed to:', format.value);
                    }}
                  >
                    <View style={styles.formatOptionLeft}>
                      <Text style={styles.formatOptionLabel}>{format.label}</Text>
                      <Text style={styles.formatOptionDescription}>{format.description}</Text>
                    </View>
                    {outputFormat === format.value && (
                      <IconSymbol
                        ios_icon_name="checkmark"
                        android_material_icon_name="check"
                        size={24}
                        color={colors.primary}
                      />
                    )}
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          </View>
        </Modal>

        {/* Success Modal */}
        <Modal
          visible={showSuccessModal}
          transparent
          animationType="fade"
          onRequestClose={() => setShowSuccessModal(false)}
        >
          <View style={styles.successModalOverlay}>
            <View style={styles.successModalContent}>
              <IconSymbol
                ios_icon_name="checkmark.circle.fill"
                android_material_icon_name="check-circle"
                size={64}
                color={colors.success}
              />
              <Text style={styles.successTitle}>Conversion Complete!</Text>
              <Text style={styles.successMessage}>
                Your audio file is ready to play
              </Text>
              <TouchableOpacity
                style={styles.successButton}
                onPress={() => setShowSuccessModal(false)}
              >
                <Text style={styles.successButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollView: {
    flex: 1,
  },
  section: {
    marginTop: spacing.lg,
    paddingHorizontal: spacing.lg,
  },
  sectionTitle: {
    ...typography.titleLarge,
    color: colors.primary,
    fontWeight: '600',
    marginBottom: spacing.md,
  },
  pickButton: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.xl,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.primary,
    borderStyle: 'dashed',
  },
  pickButtonText: {
    ...typography.bodyLarge,
    color: colors.primary,
    fontWeight: '600',
    marginTop: spacing.sm,
  },
  selectedFile: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  fileIcon: {
    marginRight: spacing.md,
  },
  fileInfo: {
    flex: 1,
  },
  fileName: {
    ...typography.bodyLarge,
    color: colors.text,
    fontWeight: '600',
  },
  fileSize: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  formatSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
  },
  formatLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  formatText: {
    ...typography.bodyLarge,
    color: colors.text,
    fontWeight: '600',
  },
  convertButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    gap: spacing.sm,
  },
  convertButtonDisabled: {
    backgroundColor: colors.surfaceVariant,
    opacity: 0.5,
  },
  convertButtonText: {
    ...typography.bodyLarge,
    color: colors.onPrimary,
    fontWeight: '600',
  },
  jobCard: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  jobHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  jobLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: spacing.md,
  },
  jobInfo: {
    flex: 1,
  },
  jobFileName: {
    ...typography.bodyMedium,
    color: colors.text,
    fontWeight: '600',
  },
  jobFormat: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.md,
    gap: spacing.sm,
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: colors.surfaceVariant,
    borderRadius: borderRadius.full,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
  },
  progressText: {
    ...typography.bodySmall,
    color: colors.primary,
    fontWeight: '600',
    minWidth: 40,
    textAlign: 'right',
  },
  playButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.md,
    gap: spacing.xs,
  },
  playButtonText: {
    ...typography.bodyMedium,
    color: colors.primary,
    fontWeight: '600',
  },
  errorText: {
    ...typography.bodySmall,
    color: colors.error,
    marginTop: spacing.sm,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: borderRadius.xl,
    borderTopRightRadius: borderRadius.xl,
    maxHeight: '70%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.outlineVariant,
  },
  modalTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '600',
  },
  formatOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.outlineVariant,
  },
  formatOptionLeft: {
    flex: 1,
  },
  formatOptionLabel: {
    ...typography.bodyLarge,
    color: colors.text,
    fontWeight: '600',
  },
  formatOptionDescription: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  successModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  successModalContent: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.xl,
    padding: spacing.xxl,
    alignItems: 'center',
    marginHorizontal: spacing.xl,
    minWidth: 280,
  },
  successTitle: {
    ...typography.headlineSmall,
    color: colors.text,
    fontWeight: '600',
    marginTop: spacing.lg,
  },
  successMessage: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.sm,
  },
  successButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.lg,
    paddingHorizontal: spacing.xxl,
    paddingVertical: spacing.md,
    marginTop: spacing.xl,
  },
  successButtonText: {
    ...typography.bodyLarge,
    color: colors.onPrimary,
    fontWeight: '600',
  },
});
