
import React, { useState, useEffect } from 'react';
import { IconSymbol } from '@/components/IconSymbol';
import Slider from '@react-native-community/slider';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Modal,
  TextInput,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useRouter } from 'expo-router';
import { colors, spacing, borderRadius, typography } from '@/styles/commonStyles';
import * as ImagePicker from 'expo-image-picker';

interface AppSettings {
  // Playback
  autoplayNext: boolean;
  autoResume: boolean;
  backgroundPlay: boolean;
  crossfadeEnabled: boolean;
  crossfadeDuration: number;
  playPauseFade: boolean;
  skipSilence: boolean;
  replayGain: boolean;
  
  // Audio
  equalizerEnabled: boolean;
  bassBoost: number;
  virtualizer: number;
  
  // Pause Scenarios
  pauseOnCall: boolean;
  pauseOnNotification: boolean;
  pauseOnVolumeZero: boolean;
  pauseOnHeadphoneDisconnect: boolean;
  
  // Sleep Timer
  sleepTimerEnabled: boolean;
  sleepTimerDuration: number;
  
  // Video
  floatingWindow: boolean;
  hardwareAcceleration: boolean;
  hdrMode: boolean;
  defaultQuality: 'Auto' | '8K' | '4K' | '1080p' | '720p' | '480p' | '360p';
  
  // Subtitles
  autoDownloadSubtitles: boolean;
  subtitleLanguage: string;
  subtitleFontSize: number;
  subtitleEncoding: string;
  
  // Themes & Colors
  dynamicTheming: boolean;
  monochromeMode: boolean;
  playerColorSource: 'artwork' | 'dynamic' | 'static' | 'custom';
  customPlayerColor: string;
  customBackground: string | null;
  
  // UI
  animationSpeed: number;
  homeWidgetStyle: 'grid' | 'list' | 'carousel' | 'compact';
  notificationStyle: 'expanded' | 'compact' | 'minimal';
  showAlbumArt: boolean;
  
  // Visual Effects
  animatingThumbnail: boolean;
  miniplayerPartyMode: boolean;
  particleEffects: boolean;
  waveformSeekbar: boolean;
  waveformStyle: 'bars' | 'line' | 'filled' | 'gradient';
  
  // Library
  minFileSize: number;
  minDuration: number;
  preventDuplicates: boolean;
  scanHiddenFiles: boolean;
  excludedFolders: string[];
}

const DEFAULT_SETTINGS: AppSettings = {
  autoplayNext: true,
  autoResume: true,
  backgroundPlay: true,
  crossfadeEnabled: false,
  crossfadeDuration: 3,
  playPauseFade: true,
  skipSilence: false,
  replayGain: false,
  equalizerEnabled: false,
  bassBoost: 0,
  virtualizer: 0,
  pauseOnCall: true,
  pauseOnNotification: false,
  pauseOnVolumeZero: false,
  pauseOnHeadphoneDisconnect: true,
  sleepTimerEnabled: false,
  sleepTimerDuration: 30,
  floatingWindow: false,
  hardwareAcceleration: true,
  hdrMode: false,
  defaultQuality: 'Auto',
  autoDownloadSubtitles: false,
  subtitleLanguage: 'en',
  subtitleFontSize: 16,
  subtitleEncoding: 'UTF-8',
  dynamicTheming: true,
  monochromeMode: false,
  playerColorSource: 'artwork',
  customPlayerColor: colors.primary,
  customBackground: null,
  animationSpeed: 1.0,
  homeWidgetStyle: 'grid',
  notificationStyle: 'expanded',
  showAlbumArt: true,
  animatingThumbnail: true,
  miniplayerPartyMode: true,
  particleEffects: true,
  waveformSeekbar: true,
  waveformStyle: 'bars',
  minFileSize: 0,
  minDuration: 0,
  preventDuplicates: true,
  scanHiddenFiles: false,
  excludedFolders: [],
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    ...typography.titleLarge,
    color: colors.text,
    marginBottom: spacing.md,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.outline,
  },
  settingLabel: {
    ...typography.bodyLarge,
    color: colors.text,
    flex: 1,
  },
  sliderRow: {
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.outline,
  },
  sliderLabel: {
    ...typography.bodyLarge,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  sliderValue: {
    ...typography.labelMedium,
    color: colors.textSecondary,
    textAlign: 'right',
  },
  slider: {
    width: '100%',
    height: 40,
  },
  selectRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.outline,
  },
  selectValue: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
  },
  backgroundPreview: {
    width: 60,
    height: 60,
    borderRadius: borderRadius.sm,
    backgroundColor: colors.surfaceVariant,
  },
  saveButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
    marginTop: spacing.lg,
  },
  saveButtonText: {
    ...typography.labelLarge,
    color: colors.onPrimary,
  },
});

export default function SettingsScreen() {
  const router = useRouter();
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const saved = await AsyncStorage.getItem('@settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        setSettings({ ...DEFAULT_SETTINGS, ...parsed });
        console.log('Loaded settings');
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const handleSaveSettings = async (newSettings: AppSettings) => {
    try {
      await AsyncStorage.setItem('@settings', JSON.stringify(newSettings));
      console.log('Settings saved');
      
      // Also save player-specific settings
      await AsyncStorage.setItem('player_settings', JSON.stringify({
        animatingThumbnail: newSettings.animatingThumbnail,
        particleEffects: newSettings.particleEffects,
        waveformStyle: newSettings.waveformStyle,
      }));
      
      // Save miniplayer settings
      await AsyncStorage.setItem('miniplayer_settings', JSON.stringify({
        partyMode: newSettings.miniplayerPartyMode,
      }));
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  const updateSetting = <K extends keyof AppSettings>(
    key: K,
    value: AppSettings[K]
  ) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    handleSaveSettings(newSettings);
  };

  const handlePickBackground = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled && result.assets[0]) {
      updateSetting('customBackground', result.assets[0].uri);
    }
  };

  const renderSettingRow = (
    label: string,
    value: boolean,
    onValueChange: (value: boolean) => void,
    icon: string
  ) => (
    <View style={styles.settingRow}>
      <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
        <IconSymbol
          ios_icon_name={icon}
          android_material_icon_name={icon}
          size={24}
          color={colors.textSecondary}
          style={{ marginRight: spacing.md }}
        />
        <Text style={styles.settingLabel}>{label}</Text>
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: colors.outline, true: colors.primaryContainer }}
        thumbColor={value ? colors.primary : colors.surfaceVariant}
      />
    </View>
  );

  const renderSliderRow = (
    label: string,
    value: number,
    onValueChange: (value: number) => void,
    min: number,
    max: number,
    step: number,
    unit: string
  ) => (
    <View style={styles.sliderRow}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: spacing.sm }}>
        <Text style={styles.sliderLabel}>{label}</Text>
        <Text style={styles.sliderValue}>
          {value}
          {unit}
        </Text>
      </View>
      <Slider
        style={styles.slider}
        minimumValue={min}
        maximumValue={max}
        step={step}
        value={value}
        onValueChange={onValueChange}
        minimumTrackTintColor={colors.primary}
        maximumTrackTintColor={colors.outlineVariant}
        thumbTintColor={colors.primary}
      />
    </View>
  );

  const renderSelectRow = (
    label: string,
    value: string,
    icon: string,
    onPress: () => void
  ) => (
    <TouchableOpacity style={styles.selectRow} onPress={onPress}>
      <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
        <IconSymbol
          ios_icon_name={icon}
          android_material_icon_name={icon}
          size={24}
          color={colors.textSecondary}
          style={{ marginRight: spacing.md }}
        />
        <Text style={styles.settingLabel}>{label}</Text>
      </View>
      <Text style={styles.selectValue}>{value}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Visual Effects Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Visual Effects</Text>
          {renderSettingRow(
            'Animating Thumbnail',
            settings.animatingThumbnail,
            (value) => updateSetting('animatingThumbnail', value),
            'animation'
          )}
          {renderSettingRow(
            'Miniplayer Party Mode',
            settings.miniplayerPartyMode,
            (value) => updateSetting('miniplayerPartyMode', value),
            'celebration'
          )}
          {renderSettingRow(
            'Particle Effects',
            settings.particleEffects,
            (value) => updateSetting('particleEffects', value),
            'auto-awesome'
          )}
          {renderSettingRow(
            'Waveform Seekbar',
            settings.waveformSeekbar,
            (value) => updateSetting('waveformSeekbar', value),
            'graphic-eq'
          )}
        </View>

        {/* Playback Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Playback</Text>
          {renderSettingRow(
            'Autoplay Next',
            settings.autoplayNext,
            (value) => updateSetting('autoplayNext', value),
            'skip-next'
          )}
          {renderSettingRow(
            'Auto Resume',
            settings.autoResume,
            (value) => updateSetting('autoResume', value),
            'play-arrow'
          )}
          {renderSettingRow(
            'Background Play',
            settings.backgroundPlay,
            (value) => updateSetting('backgroundPlay', value),
            'headphones'
          )}
          {renderSettingRow(
            'Crossfade',
            settings.crossfadeEnabled,
            (value) => updateSetting('crossfadeEnabled', value),
            'shuffle'
          )}
          {settings.crossfadeEnabled &&
            renderSliderRow(
              'Crossfade Duration',
              settings.crossfadeDuration,
              (value) => updateSetting('crossfadeDuration', value),
              1,
              10,
              1,
              's'
            )}
        </View>

        {/* Audio Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Audio</Text>
          {renderSettingRow(
            'Equalizer',
            settings.equalizerEnabled,
            (value) => updateSetting('equalizerEnabled', value),
            'equalizer'
          )}
          {renderSliderRow(
            'Bass Boost',
            settings.bassBoost,
            (value) => updateSetting('bassBoost', value),
            0,
            100,
            10,
            '%'
          )}
          {renderSliderRow(
            'Virtualizer',
            settings.virtualizer,
            (value) => updateSetting('virtualizer', value),
            0,
            100,
            10,
            '%'
          )}
        </View>

        {/* Pause Scenarios Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Pause Scenarios</Text>
          {renderSettingRow(
            'Pause on Call',
            settings.pauseOnCall,
            (value) => updateSetting('pauseOnCall', value),
            'phone'
          )}
          {renderSettingRow(
            'Pause on Notification',
            settings.pauseOnNotification,
            (value) => updateSetting('pauseOnNotification', value),
            'notifications'
          )}
          {renderSettingRow(
            'Pause on Volume Zero',
            settings.pauseOnVolumeZero,
            (value) => updateSetting('pauseOnVolumeZero', value),
            'volume-off'
          )}
          {renderSettingRow(
            'Pause on Headphone Disconnect',
            settings.pauseOnHeadphoneDisconnect,
            (value) => updateSetting('pauseOnHeadphoneDisconnect', value),
            'headset-off'
          )}
        </View>

        {/* Video Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Video</Text>
          {renderSettingRow(
            'Hardware Acceleration',
            settings.hardwareAcceleration,
            (value) => updateSetting('hardwareAcceleration', value),
            'speed'
          )}
          {renderSettingRow(
            'HDR Mode',
            settings.hdrMode,
            (value) => updateSetting('hdrMode', value),
            'hdr-on'
          )}
        </View>

        {/* Themes & Colors Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Themes & Colors</Text>
          {renderSettingRow(
            'Dynamic Theming',
            settings.dynamicTheming,
            (value) => updateSetting('dynamicTheming', value),
            'palette'
          )}
          {renderSettingRow(
            'Monochrome Mode',
            settings.monochromeMode,
            (value) => updateSetting('monochromeMode', value),
            'filter-b-and-w'
          )}
          {renderSelectRow(
            'Custom Background',
            settings.customBackground ? 'Set' : 'None',
            'wallpaper',
            handlePickBackground
          )}
        </View>

        {/* Library Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Library</Text>
          {renderSettingRow(
            'Prevent Duplicates',
            settings.preventDuplicates,
            (value) => updateSetting('preventDuplicates', value),
            'content-copy'
          )}
          {renderSettingRow(
            'Scan Hidden Files',
            settings.scanHiddenFiles,
            (value) => updateSetting('scanHiddenFiles', value),
            'visibility'
          )}
          {renderSliderRow(
            'Min File Size (MB)',
            settings.minFileSize,
            (value) => updateSetting('minFileSize', value),
            0,
            100,
            5,
            'MB'
          )}
          {renderSliderRow(
            'Min Duration (sec)',
            settings.minDuration,
            (value) => updateSetting('minDuration', value),
            0,
            300,
            30,
            's'
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
