
import { IconSymbol } from '@/components/IconSymbol';
import React, { useState, useRef, useEffect } from 'react';
import Slider from '@react-native-community/slider';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams, Stack } from 'expo-router';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Modal,
  ScrollView,
  PanResponder,
  Animated as RNAnimated,
  GestureResponderEvent,
} from 'react-native';
import * as ScreenOrientation from 'expo-screen-orientation';
import { colors, spacing, borderRadius, typography } from '@/styles/commonStyles';
import { VideoView, useVideoPlayer } from 'expo-video';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  videoContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  video: {
    width: '100%',
    height: '100%',
  },
  controlsOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'space-between',
  },
  topControls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.lg,
  },
  bottomControls: {
    padding: spacing.lg,
  },
  centerControls: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  playButton: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  timeText: {
    ...typography.labelMedium,
    color: '#fff',
  },
  slider: {
    flex: 1,
  },
  controlButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  controlButton: {
    padding: spacing.sm,
  },
  gestureIndicator: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: [{ translateX: -75 }, { translateY: -75 }],
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  gestureText: {
    ...typography.titleMedium,
    color: '#fff',
    marginTop: spacing.sm,
  },
  speedModal: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  speedModalContent: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.xl,
    width: SCREEN_WIDTH - spacing.xl * 2,
  },
  speedModalTitle: {
    ...typography.headlineSmall,
    color: colors.text,
    marginBottom: spacing.lg,
    textAlign: 'center',
  },
  speedOption: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    marginBottom: spacing.sm,
    backgroundColor: colors.surfaceVariant,
  },
  speedOptionActive: {
    backgroundColor: colors.primaryContainer,
  },
  speedOptionText: {
    ...typography.bodyLarge,
    color: colors.text,
    textAlign: 'center',
  },
});

export default function VideoPlayerScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const videoUrl = params.url as string;
  const videoTitle = params.title as string || 'Video';

  const player = useVideoPlayer(videoUrl, (player) => {
    player.loop = false;
    player.play();
  });

  const [showControls, setShowControls] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [volume, setVolume] = useState(1.0);
  const [showSpeedModal, setShowSpeedModal] = useState(false);
  const [gestureIndicator, setGestureIndicator] = useState<{
    visible: boolean;
    text: string;
    icon: string;
  }>({ visible: false, text: '', icon: '' });

  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastTapRef = useRef<number | null>(null);
  const gestureOpacity = useRef(new RNAnimated.Value(0)).current;

  useEffect(() => {
    if (player) {
      player.volume = volume;
    }
  }, [player, volume]);

  useEffect(() => {
    if (showControls) {
      resetControlsTimeout();
    }
  }, [showControls]);

  const resetControlsTimeout = () => {
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      setShowControls(false);
    }, 3000);
  };

  const toggleControls = () => {
    setShowControls(!showControls);
  };

  const handleDoubleTap = (event: GestureResponderEvent) => {
    const now = Date.now();
    const { locationX } = event.nativeEvent;
    
    if (lastTapRef.current && now - lastTapRef.current < 300) {
      const isLeftSide = locationX < SCREEN_WIDTH / 2;
      
      if (isLeftSide) {
        skipBackward();
        showGestureIndicatorWithIcon('-10s', 'replay-10');
      } else {
        skipForward();
        showGestureIndicatorWithIcon('+10s', 'forward-10');
      }
      
      lastTapRef.current = null;
    } else {
      lastTapRef.current = now;
      setTimeout(() => {
        if (lastTapRef.current === now) {
          toggleControls();
        }
      }, 300);
    }
  };

  const showGestureIndicatorWithIcon = (text: string, icon: string) => {
    setGestureIndicator({ visible: true, text, icon });
    
    RNAnimated.sequence([
      RNAnimated.timing(gestureOpacity, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }),
      RNAnimated.delay(800),
      RNAnimated.timing(gestureOpacity, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setGestureIndicator({ visible: false, text: '', icon: '' });
    });
  };

  const togglePlayPause = () => {
    if (player.playing) {
      player.pause();
    } else {
      player.play();
    }
  };

  const handleSeek = (value: number) => {
    player.currentTime = value;
  };

  const changePlaybackSpeed = (speed: number) => {
    setPlaybackSpeed(speed);
    player.playbackRate = speed;
    setShowSpeedModal(false);
  };

  const skipForward = () => {
    const newTime = Math.min(player.currentTime + 10, player.duration);
    player.currentTime = newTime;
  };

  const skipBackward = () => {
    const newTime = Math.max(player.currentTime - 10, 0);
    player.currentTime = newTime;
  };

  const toggleFullscreen = async () => {
    if (isFullscreen) {
      await ScreenOrientation.lockAsync(
        ScreenOrientation.OrientationLock.PORTRAIT_UP
      );
    } else {
      await ScreenOrientation.lockAsync(
        ScreenOrientation.OrientationLock.LANDSCAPE
      );
    }
    setIsFullscreen(!isFullscreen);
  };

  const handleClose = async () => {
    await ScreenOrientation.lockAsync(
      ScreenOrientation.OrientationLock.PORTRAIT_UP
    );
    player.pause();
    router.back();
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const minsDisplay = mins.toString();
    const secsDisplay = secs.toString().padStart(2, '0');
    return `${minsDisplay}:${secsDisplay}`;
  };

  const currentTimeFormatted = formatTime(player.currentTime || 0);
  const durationFormatted = formatTime(player.duration || 0);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <Stack.Screen options={{ headerShown: false }} />
      
      <View style={styles.videoContainer}>
        <VideoView
          style={styles.video}
          player={player}
          allowsFullscreen
          allowsPictureInPicture
        />

        <TouchableOpacity
          style={StyleSheet.absoluteFill}
          activeOpacity={1}
          onPress={handleDoubleTap}
        />

        {gestureIndicator.visible && (
          <RNAnimated.View
            style={[styles.gestureIndicator, { opacity: gestureOpacity }]}
          >
            <IconSymbol
              ios_icon_name={gestureIndicator.icon}
              android_material_icon_name={gestureIndicator.icon}
              size={48}
              color="#fff"
            />
            <Text style={styles.gestureText}>{gestureIndicator.text}</Text>
          </RNAnimated.View>
        )}

        {showControls && (
          <View style={styles.controlsOverlay}>
            <View style={styles.topControls}>
              <TouchableOpacity onPress={handleClose}>
                <IconSymbol
                  ios_icon_name="chevron.down"
                  android_material_icon_name="arrow-back"
                  size={28}
                  color="#fff"
                />
              </TouchableOpacity>
              <Text style={[typography.titleMedium, { color: '#fff' }]}>
                {videoTitle}
              </Text>
              <TouchableOpacity onPress={() => setShowSpeedModal(true)}>
                <Text style={{ color: '#fff', fontSize: 16 }}>
                  {playbackSpeed}x
                </Text>
              </TouchableOpacity>
            </View>

            <View style={styles.centerControls}>
              <TouchableOpacity style={styles.playButton} onPress={togglePlayPause}>
                <IconSymbol
                  ios_icon_name={player.playing ? 'pause.fill' : 'play.fill'}
                  android_material_icon_name={player.playing ? 'pause' : 'play-arrow'}
                  size={40}
                  color="#fff"
                />
              </TouchableOpacity>
            </View>

            <View style={styles.bottomControls}>
              <View style={styles.progressContainer}>
                <Text style={styles.timeText}>{currentTimeFormatted}</Text>
                <Slider
                  style={styles.slider}
                  minimumValue={0}
                  maximumValue={player.duration || 0}
                  value={player.currentTime || 0}
                  onValueChange={handleSeek}
                  minimumTrackTintColor="#fff"
                  maximumTrackTintColor="rgba(255, 255, 255, 0.3)"
                  thumbTintColor="#fff"
                />
                <Text style={styles.timeText}>{durationFormatted}</Text>
              </View>

              <View style={styles.controlButtons}>
                <TouchableOpacity style={styles.controlButton} onPress={skipBackward}>
                  <IconSymbol
                    ios_icon_name="gobackward.10"
                    android_material_icon_name="replay-10"
                    size={32}
                    color="#fff"
                  />
                </TouchableOpacity>

                <TouchableOpacity style={styles.controlButton} onPress={skipForward}>
                  <IconSymbol
                    ios_icon_name="goforward.10"
                    android_material_icon_name="forward-10"
                    size={32}
                    color="#fff"
                  />
                </TouchableOpacity>

                <TouchableOpacity style={styles.controlButton} onPress={toggleFullscreen}>
                  <IconSymbol
                    ios_icon_name={isFullscreen ? 'arrow.down.right.and.arrow.up.left' : 'arrow.up.left.and.arrow.down.right'}
                    android_material_icon_name={isFullscreen ? 'fullscreen-exit' : 'fullscreen'}
                    size={32}
                    color="#fff"
                  />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
      </View>

      <Modal
        visible={showSpeedModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowSpeedModal(false)}
      >
        <View style={styles.speedModal}>
          <View style={styles.speedModalContent}>
            <Text style={styles.speedModalTitle}>Playback Speed</Text>
            {[0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0].map((speed) => (
              <TouchableOpacity
                key={speed}
                style={[
                  styles.speedOption,
                  playbackSpeed === speed && styles.speedOptionActive,
                ]}
                onPress={() => changePlaybackSpeed(speed)}
              >
                <Text style={styles.speedOptionText}>{speed}x</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              style={[styles.speedOption, { backgroundColor: colors.primary, marginTop: spacing.md }]}
              onPress={() => setShowSpeedModal(false)}
            >
              <Text style={[styles.speedOptionText, { color: colors.onPrimary }]}>
                Close
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
