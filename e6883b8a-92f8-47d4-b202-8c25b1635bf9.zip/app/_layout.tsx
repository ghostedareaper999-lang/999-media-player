
import { useFonts } from 'expo-font';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';
import * as SplashScreen from 'expo-splash-screen';
import {
  DarkTheme,
  ThemeProvider,
} from '@react-navigation/native';
import { WidgetProvider } from '@/contexts/WidgetContext';
import { PlayerProvider } from '@/contexts/PlayerContext';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { SystemBars } from 'react-native-edge-to-edge';
import React, { useEffect } from 'react';
import { Stack, useRouter, useSegments } from 'expo-router';
import { ActivityIndicator, View } from 'react-native';
import { MiniPlayer } from '@/components/MiniPlayer';

SplashScreen.preventAutoHideAsync();

function RootNavigator() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const segments = useSegments();

  useEffect(() => {
    if (loading) return;

    const inAuthGroup = segments[0] === 'auth';
    const inAuthPopup = segments[0] === 'auth-popup';
    const inAuthCallback = segments[0] === 'auth-callback';

    if (!user && !inAuthGroup && !inAuthPopup && !inAuthCallback) {
      router.replace('/auth');
    } else if (user && inAuthGroup) {
      router.replace('/');
    }
  }, [user, loading, segments]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: '#0A0E27', justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#6750A4" />
      </View>
    );
  }

  return (
    <>
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: '#0A0E27' },
        }}
      >
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen
          name="player"
          options={{
            presentation: 'modal',
            headerShown: false,
            animation: 'slide_from_bottom',
          }}
        />
        <Stack.Screen
          name="video-player"
          options={{
            presentation: 'fullScreenModal',
            headerShown: false,
            animation: 'fade',
          }}
        />
        <Stack.Screen
          name="yt-downloader"
          options={{
            presentation: 'modal',
            headerShown: true,
            title: 'YouTube Downloader',
          }}
        />
        <Stack.Screen
          name="video-converter"
          options={{
            presentation: 'modal',
            headerShown: true,
            title: 'Video Converter',
          }}
        />
        <Stack.Screen
          name="settings"
          options={{
            presentation: 'modal',
            headerShown: true,
            title: 'Settings',
          }}
        />
        <Stack.Screen
          name="history"
          options={{
            presentation: 'modal',
            headerShown: true,
            title: 'Play History',
          }}
        />
        <Stack.Screen
          name="queue"
          options={{
            presentation: 'modal',
            headerShown: true,
            title: 'Queue',
          }}
        />
        <Stack.Screen
          name="about"
          options={{
            presentation: 'modal',
            headerShown: true,
            title: 'About',
          }}
        />
        <Stack.Screen name="auth" options={{ headerShown: false }} />
        <Stack.Screen name="auth-popup" options={{ headerShown: false }} />
        <Stack.Screen name="auth-callback" options={{ headerShown: false }} />
        <Stack.Screen name="+not-found" />
      </Stack>
      {user && <MiniPlayer />}
    </>
  );
}

export default function RootLayout() {
  const [loaded] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
  });

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ThemeProvider value={DarkTheme}>
        <AuthProvider>
          <WidgetProvider>
            <PlayerProvider>
              <SystemBars style="light" />
              <StatusBar style="light" />
              <RootNavigator />
            </PlayerProvider>
          </WidgetProvider>
        </AuthProvider>
      </ThemeProvider>
    </GestureHandlerRootView>
  );
}
