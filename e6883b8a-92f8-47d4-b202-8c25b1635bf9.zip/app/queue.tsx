
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useRouter } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { usePlayer } from '@/contexts/PlayerContext';
import { colors, spacing, borderRadius, typography, commonStyles, formatDuration } from '@/styles/commonStyles';

export default function QueueScreen() {
  const { queue, currentIndex, currentTrack, play, clearQueue } = usePlayer();
  const router = useRouter();

  const handlePlayTrack = (track: any, index: number) => {
    console.log('[Queue] Playing track at index:', index);
    play(track);
  };

  const handleClearQueue = () => {
    console.log('[Queue] Clearing queue');
    clearQueue();
  };

  const renderTrackItem = ({ item, index }: { item: any; index: number }) => {
    const isCurrentTrack = index === currentIndex;
    const displayTitle = item.title || item.fileName || 'Unknown Track';
    const displayArtist = item.artist || 'Unknown Artist';
    const durationText = formatDuration(item.duration || 0);

    return (
      <TouchableOpacity
        style={[styles.trackItem, isCurrentTrack && styles.currentTrackItem]}
        onPress={() => handlePlayTrack(item, index)}
      >
        <View style={styles.trackArtwork}>
          {item.artworkUrl ? (
            <Image source={{ uri: item.artworkUrl }} style={styles.artworkImage} />
          ) : (
            <View style={styles.placeholderArtwork}>
              <IconSymbol
                ios_icon_name="music.note"
                android_material_icon_name="music-note"
                size={20}
                color={colors.textSecondary}
              />
            </View>
          )}
          {isCurrentTrack && (
            <View style={styles.playingIndicator}>
              <IconSymbol
                ios_icon_name="speaker.wave.2.fill"
                android_material_icon_name="volume-up"
                size={16}
                color={colors.onPrimary}
              />
            </View>
          )}
        </View>
        <View style={styles.trackInfo}>
          <Text style={[styles.trackTitle, isCurrentTrack && styles.currentTrackText]}>
            {displayTitle}
          </Text>
          <Text style={styles.trackArtist}>{displayArtist}</Text>
        </View>
        <Text style={styles.trackDuration}>{durationText}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'Queue',
          headerStyle: { backgroundColor: colors.background },
          headerTintColor: colors.text,
          headerBackTitle: 'Back',
        }}
      />
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.queueCount}>
            {queue.length} {queue.length === 1 ? 'track' : 'tracks'} in queue
          </Text>
          {queue.length > 0 && (
            <TouchableOpacity style={styles.clearButton} onPress={handleClearQueue}>
              <Text style={styles.clearButtonText}>Clear All</Text>
            </TouchableOpacity>
          )}
        </View>

        {queue.length === 0 ? (
          <View style={styles.emptyState}>
            <IconSymbol
              ios_icon_name="music.note.list"
              android_material_icon_name="queue-music"
              size={64}
              color={colors.textSecondary}
            />
            <Text style={styles.emptyTitle}>Queue is empty</Text>
            <Text style={styles.emptySubtitle}>
              Add tracks to your queue to see them here
            </Text>
          </View>
        ) : (
          <FlatList
            data={queue}
            renderItem={renderTrackItem}
            keyExtractor={(item, index) => `${item.id}-${index}`}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  queueCount: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
  },
  clearButton: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    backgroundColor: colors.errorContainer,
  },
  clearButtonText: {
    ...typography.labelMedium,
    color: colors.error,
    fontWeight: '600',
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 100,
  },
  trackItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  currentTrackItem: {
    backgroundColor: colors.primaryContainer,
  },
  trackArtwork: {
    width: 48,
    height: 48,
    borderRadius: borderRadius.sm,
    marginRight: spacing.md,
    overflow: 'hidden',
    position: 'relative',
  },
  artworkImage: {
    width: '100%',
    height: '100%',
  },
  placeholderArtwork: {
    width: '100%',
    height: '100%',
    backgroundColor: colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
  },
  playingIndicator: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(103, 80, 164, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackInfo: {
    flex: 1,
  },
  trackTitle: {
    ...typography.titleSmall,
    color: colors.text,
    fontWeight: '600',
  },
  currentTrackText: {
    color: colors.primary,
  },
  trackArtist: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  trackDuration: {
    ...typography.bodySmall,
    color: colors.textSecondary,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
  },
  emptyTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '600',
    marginTop: spacing.lg,
  },
  emptySubtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.sm,
  },
});
