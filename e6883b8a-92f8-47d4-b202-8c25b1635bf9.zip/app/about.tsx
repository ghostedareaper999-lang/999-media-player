
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useRouter } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, spacing, borderRadius, typography, commonStyles } from '@/styles/commonStyles';
import { LinearGradient } from 'expo-linear-gradient';

export default function AboutScreen() {
  const router = useRouter();

  const features = [
    {
      icon: 'music-note',
      title: 'Universal Format Support',
      description: 'Plays all audio formats including MP3, FLAC, WAV, AAC, OGG, and more',
    },
    {
      icon: 'movie',
      title: 'Video Playback',
      description: 'Supports MKV, MP4, AVI, MOV, FLV, and 4K/8K video playback',
    },
    {
      icon: 'queue-music',
      title: 'Advanced Queue System',
      description: 'Persistent queue with shuffle, repeat, and smart track generation',
    },
    {
      icon: 'speed',
      title: 'Playback Controls',
      description: 'Variable speed, crossfade, replay gain, and audio normalization',
    },
    {
      icon: 'lyrics',
      title: 'Lyrics Support',
      description: 'Auto-fetch synced and plain lyrics with word-level synchronization',
    },
    {
      icon: 'equalizer',
      title: 'Audio Enhancement',
      description: 'Built-in equalizer with presets and custom audio profiles',
    },
    {
      icon: 'swap-horiz',
      title: 'Video Converter',
      description: 'Convert videos to audio formats with one click',
    },
    {
      icon: 'folder',
      title: 'Smart Library',
      description: 'Folder-based organization with tag editing and duplicate prevention',
    },
    {
      icon: 'bedtime',
      title: 'Sleep Timer',
      description: 'Auto-stop playback after set time or number of tracks',
    },
    {
      icon: 'history',
      title: 'Play History',
      description: 'Track your listening habits with detailed history and statistics',
    },
    {
      icon: 'playlist-play',
      title: 'Smart Playlists',
      description: 'Create custom playlists with artwork and automatic ordering',
    },
    {
      icon: 'closed-caption',
      title: 'Subtitle Support',
      description: 'Online subtitle search and customizable subtitle styling',
    },
  ];

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'About',
          headerStyle: { backgroundColor: colors.background },
          headerTintColor: colors.text,
          headerBackTitle: 'Back',
        }}
      />
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <LinearGradient
          colors={[colors.primary, colors.primaryContainer]}
          style={styles.header}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <View style={styles.appIcon}>
            <IconSymbol
              ios_icon_name="music.note"
              android_material_icon_name="music-note"
              size={48}
              color={colors.onPrimary}
            />
          </View>
          <Text style={styles.appName}>Advanced Media Player</Text>
          <Text style={styles.appVersion}>Version 1.0.0</Text>
          <Text style={styles.appTagline}>
            Your ultimate music and video player
          </Text>
        </LinearGradient>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Key Features</Text>
          <View style={styles.featuresGrid}>
            {features.map((feature, index) => (
              <View key={index} style={styles.featureCard}>
                <View style={styles.featureIcon}>
                  <IconSymbol
                    ios_icon_name={feature.icon}
                    android_material_icon_name={feature.icon}
                    size={28}
                    color={colors.primary}
                  />
                </View>
                <Text style={styles.featureTitle}>{feature.title}</Text>
                <Text style={styles.featureDescription}>{feature.description}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Advanced Capabilities</Text>
          <View style={styles.capabilityCard}>
            <IconSymbol
              ios_icon_name="waveform"
              android_material_icon_name="graphic-eq"
              size={24}
              color={colors.primary}
            />
            <View style={styles.capabilityContent}>
              <Text style={styles.capabilityTitle}>Waveform Seekbar</Text>
              <Text style={styles.capabilityText}>
                Visual audio waveform for precise seeking
              </Text>
            </View>
          </View>
          <View style={styles.capabilityCard}>
            <IconSymbol
              ios_icon_name="paintbrush"
              android_material_icon_name="palette"
              size={24}
              color={colors.primary}
            />
            <View style={styles.capabilityContent}>
              <Text style={styles.capabilityTitle}>Dynamic Theming</Text>
              <Text style={styles.capabilityText}>
                Colors adapt to album artwork automatically
              </Text>
            </View>
          </View>
          <View style={styles.capabilityCard}>
            <IconSymbol
              ios_icon_name="tag"
              android_material_icon_name="label"
              size={24}
              color={colors.primary}
            />
            <View style={styles.capabilityContent}>
              <Text style={styles.capabilityTitle}>Tag Editor</Text>
              <Text style={styles.capabilityText}>
                Edit metadata with powerful jaudiotagger integration
              </Text>
            </View>
          </View>
          <View style={styles.capabilityCard}>
            <IconSymbol
              ios_icon_name="hand.tap"
              android_material_icon_name="touch-app"
              size={24}
              color={colors.primary}
            />
            <View style={styles.capabilityContent}>
              <Text style={styles.capabilityTitle}>Gesture Controls</Text>
              <Text style={styles.capabilityText}>
                Swipe for volume, brightness, and seeking
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Privacy & Security</Text>
          <View style={styles.infoCard}>
            <IconSymbol
              ios_icon_name="lock.shield"
              android_material_icon_name="security"
              size={32}
              color={colors.primary}
            />
            <Text style={styles.infoText}>
              Your privacy matters. We don't collect or share your personal data.
              All your media stays on your device.
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support</Text>
          <TouchableOpacity style={styles.linkCard}>
            <IconSymbol
              ios_icon_name="questionmark.circle"
              android_material_icon_name="help"
              size={24}
              color={colors.primary}
            />
            <Text style={styles.linkText}>Help & FAQ</Text>
            <IconSymbol
              ios_icon_name="chevron.right"
              android_material_icon_name="chevron-right"
              size={20}
              color={colors.textSecondary}
            />
          </TouchableOpacity>
          <TouchableOpacity style={styles.linkCard}>
            <IconSymbol
              ios_icon_name="envelope"
              android_material_icon_name="email"
              size={24}
              color={colors.primary}
            />
            <Text style={styles.linkText}>Contact Us</Text>
            <IconSymbol
              ios_icon_name="chevron.right"
              android_material_icon_name="chevron-right"
              size={20}
              color={colors.textSecondary}
            />
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Made with ❤️ for music and video lovers
          </Text>
          <Text style={styles.copyright}>
            © 2024 Advanced Media Player. All rights reserved.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    alignItems: 'center',
    paddingVertical: spacing.xxl,
    paddingHorizontal: spacing.lg,
  },
  appIcon: {
    width: 96,
    height: 96,
    borderRadius: borderRadius.xl,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  appName: {
    ...typography.headlineLarge,
    color: colors.onPrimary,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: spacing.xs,
  },
  appVersion: {
    ...typography.bodyMedium,
    color: colors.onPrimary,
    opacity: 0.9,
    marginBottom: spacing.sm,
  },
  appTagline: {
    ...typography.bodyLarge,
    color: colors.onPrimary,
    opacity: 0.9,
    textAlign: 'center',
  },
  section: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.xl,
  },
  sectionTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '700',
    marginBottom: spacing.lg,
  },
  featuresGrid: {
    gap: spacing.md,
  },
  featureCard: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.lg,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  featureIcon: {
    width: 48,
    height: 48,
    borderRadius: borderRadius.md,
    backgroundColor: colors.primaryContainer,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  featureTitle: {
    ...typography.titleSmall,
    color: colors.text,
    fontWeight: '600',
    marginBottom: spacing.xs,
    flex: 1,
  },
  featureDescription: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    lineHeight: 20,
    flex: 1,
  },
  capabilityCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  capabilityContent: {
    flex: 1,
    marginLeft: spacing.md,
  },
  capabilityTitle: {
    ...typography.bodyLarge,
    color: colors.text,
    fontWeight: '600',
    marginBottom: spacing.xs,
  },
  capabilityText: {
    ...typography.bodySmall,
    color: colors.textSecondary,
  },
  infoCard: {
    backgroundColor: colors.primaryContainer,
    borderRadius: borderRadius.md,
    padding: spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
  },
  infoText: {
    ...typography.bodyMedium,
    color: colors.text,
    flex: 1,
    marginLeft: spacing.md,
    lineHeight: 22,
  },
  linkCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  linkText: {
    ...typography.bodyLarge,
    color: colors.text,
    flex: 1,
    marginLeft: spacing.md,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: spacing.xxl,
    paddingHorizontal: spacing.lg,
  },
  footerText: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  copyright: {
    ...typography.bodySmall,
    color: colors.textTertiary,
    textAlign: 'center',
  },
});
