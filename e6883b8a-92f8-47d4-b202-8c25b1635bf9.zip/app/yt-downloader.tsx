
import React, { useState, useEffect } from 'react';
import { IconSymbol } from '@/components/IconSymbol';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useRouter } from 'expo-router';
import { colors, spacing, borderRadius, typography, formatFileSize } from '@/styles/commonStyles';
import { authenticatedGet, authenticatedPost, authenticatedDelete } from '@/utils/api';

interface Download {
  id: string;
  url: string;
  title: string;
  format: 'video' | 'audio';
  quality: string;
  status: 'pending' | 'downloading' | 'processing' | 'completed' | 'failed';
  progress: number;
  outputPath?: string;
  fileSize?: number;
  errorMessage?: string;
  createdAt: string;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
  },
  inputSection: {
    marginBottom: spacing.xl,
  },
  label: {
    ...typography.labelLarge,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  input: {
    backgroundColor: colors.surfaceVariant,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    color: colors.text,
    ...typography.bodyLarge,
    marginBottom: spacing.md,
  },
  formatSelector: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  formatButton: {
    flex: 1,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    backgroundColor: colors.surfaceVariant,
    alignItems: 'center',
  },
  formatButtonActive: {
    backgroundColor: colors.primaryContainer,
  },
  formatButtonText: {
    ...typography.labelLarge,
    color: colors.text,
  },
  qualitySelector: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  qualityButton: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.sm,
    backgroundColor: colors.surfaceVariant,
  },
  qualityButtonActive: {
    backgroundColor: colors.primaryContainer,
  },
  qualityButtonText: {
    ...typography.labelMedium,
    color: colors.text,
  },
  downloadButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  downloadButtonDisabled: {
    backgroundColor: colors.outlineVariant,
  },
  downloadButtonText: {
    ...typography.labelLarge,
    color: colors.onPrimary,
  },
  downloadsSection: {
    marginTop: spacing.lg,
  },
  sectionTitle: {
    ...typography.titleLarge,
    color: colors.text,
    marginBottom: spacing.md,
  },
  downloadCard: {
    backgroundColor: colors.surfaceVariant,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  downloadHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.sm,
  },
  downloadTitle: {
    ...typography.bodyLarge,
    color: colors.text,
    flex: 1,
    marginRight: spacing.sm,
  },
  downloadInfo: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  progressBar: {
    height: 4,
    backgroundColor: colors.outline,
    borderRadius: 2,
    marginTop: spacing.sm,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
  },
  statusBadge: {
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.sm,
    borderRadius: borderRadius.sm,
    alignSelf: 'flex-start',
  },
  statusText: {
    ...typography.labelSmall,
    color: colors.onPrimary,
  },
  deleteButton: {
    padding: spacing.xs,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
  },
  emptyStateText: {
    ...typography.bodyLarge,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.xl,
    width: '80%',
  },
  modalTitle: {
    ...typography.headlineSmall,
    color: colors.text,
    marginBottom: spacing.md,
    textAlign: 'center',
  },
  modalText: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
    textAlign: 'center',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  modalButton: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  modalButtonCancel: {
    backgroundColor: colors.surfaceVariant,
  },
  modalButtonConfirm: {
    backgroundColor: colors.error,
  },
  modalButtonText: {
    ...typography.labelLarge,
    color: colors.text,
  },
});

export default function YTDownloaderScreen() {
  const router = useRouter();
  const [url, setUrl] = useState('');
  const [format, setFormat] = useState<'video' | 'audio'>('video');
  const [quality, setQuality] = useState('best');
  const [downloads, setDownloads] = useState<Download[]>([]);
  const [loading, setLoading] = useState(false);
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [downloadToDelete, setDownloadToDelete] = useState<Download | null>(null);
  const [errorModalVisible, setErrorModalVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    loadDownloads();
    const interval = setInterval(loadDownloads, 3000);
    return () => clearInterval(interval);
  }, []);

  const loadDownloads = async () => {
    try {
      const data = await authenticatedGet<Download[]>('/api/ytdlp/downloads');
      setDownloads(Array.isArray(data) ? data : []);
      console.log('[API] Loaded downloads:', Array.isArray(data) ? data.length : 0);
    } catch (error) {
      console.error('[API] Failed to load downloads:', error);
    }
  };

  const handleDownload = async () => {
    if (!url.trim()) {
      console.log('URL is empty');
      return;
    }

    try {
      setLoading(true);
      console.log('[API] Starting download:', { url, format, quality });
      
      const result = await authenticatedPost<{ id: string; status: string }>('/api/ytdlp/downloads', {
        url: url.trim(),
        format,
        quality,
      });

      console.log('[API] Download started:', result);
      setUrl('');
      await loadDownloads();
    } catch (error: any) {
      console.error('[API] Download failed:', error);
      setErrorMessage(error?.message || 'Failed to start download. Please check the URL and try again.');
      setErrorModalVisible(true);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteDownload = (download: Download) => {
    setDownloadToDelete(download);
    setDeleteModalVisible(true);
  };

  const confirmDelete = async () => {
    if (!downloadToDelete) return;

    try {
      console.log('[API] Deleting download:', downloadToDelete.id);
      await authenticatedDelete(`/api/ytdlp/downloads/${downloadToDelete.id}`);
      await loadDownloads();
      console.log('[API] Download deleted');
    } catch (error) {
      console.error('[API] Failed to delete download:', error);
    } finally {
      setDeleteModalVisible(false);
      setDownloadToDelete(null);
    }
  };

  const getStatusColor = (status: Download['status']) => {
    const statusColorMap = {
      pending: colors.tertiary,
      downloading: colors.primary,
      processing: colors.secondary,
      completed: colors.success,
      failed: colors.error,
    };
    return statusColorMap[status];
  };

  const getStatusText = (status: Download['status']) => {
    const statusTextMap = {
      pending: 'Pending',
      downloading: 'Downloading',
      processing: 'Processing',
      completed: 'Completed',
      failed: 'Failed',
    };
    return statusTextMap[status];
  };

  const videoQualities = ['best', '2160p', '1440p', '1080p', '720p', '480p', '360p'];
  const audioQualities = ['best', '320kbps', '256kbps', '192kbps', '128kbps'];
  const qualities = format === 'video' ? videoQualities : audioQualities;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.inputSection}>
          <Text style={styles.label}>YouTube URL</Text>
          <TextInput
            style={styles.input}
            placeholder="https://youtube.com/watch?v=..."
            placeholderTextColor={colors.textSecondary}
            value={url}
            onChangeText={setUrl}
            autoCapitalize="none"
            autoCorrect={false}
          />

          <Text style={styles.label}>Format</Text>
          <View style={styles.formatSelector}>
            <TouchableOpacity
              style={[
                styles.formatButton,
                format === 'video' && styles.formatButtonActive,
              ]}
              onPress={() => setFormat('video')}
            >
              <Text style={styles.formatButtonText}>Video</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.formatButton,
                format === 'audio' && styles.formatButtonActive,
              ]}
              onPress={() => setFormat('audio')}
            >
              <Text style={styles.formatButtonText}>Audio</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.label}>Quality</Text>
          <View style={styles.qualitySelector}>
            {qualities.map((q) => (
              <TouchableOpacity
                key={q}
                style={[
                  styles.qualityButton,
                  quality === q && styles.qualityButtonActive,
                ]}
                onPress={() => setQuality(q)}
              >
                <Text style={styles.qualityButtonText}>{q}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity
            style={[
              styles.downloadButton,
              (!url.trim() || loading) && styles.downloadButtonDisabled,
            ]}
            onPress={handleDownload}
            disabled={!url.trim() || loading}
          >
            {loading ? (
              <ActivityIndicator color={colors.onPrimary} />
            ) : (
              <Text style={styles.downloadButtonText}>Start Download</Text>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.downloadsSection}>
          <Text style={styles.sectionTitle}>Downloads</Text>
          {downloads.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateText}>No downloads yet</Text>
            </View>
          ) : (
            downloads.map((download) => (
              <View key={download.id} style={styles.downloadCard}>
                <View style={styles.downloadHeader}>
                  <Text style={styles.downloadTitle} numberOfLines={2}>
                    {download.title || download.url}
                  </Text>
                  <TouchableOpacity
                    style={styles.deleteButton}
                    onPress={() => handleDeleteDownload(download)}
                  >
                    <IconSymbol
                      ios_icon_name="trash"
                      android_material_icon_name="delete"
                      size={20}
                      color={colors.error}
                    />
                  </TouchableOpacity>
                </View>

                <Text style={styles.downloadInfo}>
                  {download.format.toUpperCase()} • {download.quality}
                </Text>

                {download.fileSize && (
                  <Text style={styles.downloadInfo}>
                    Size: {formatFileSize(download.fileSize)}
                  </Text>
                )}

                <View
                  style={[
                    styles.statusBadge,
                    { backgroundColor: getStatusColor(download.status) },
                  ]}
                >
                  <Text style={styles.statusText}>
                    {getStatusText(download.status)}
                  </Text>
                </View>

                {(download.status === 'downloading' ||
                  download.status === 'processing') && (
                  <View style={styles.progressBar}>
                    <View
                      style={[
                        styles.progressFill,
                        { width: `${download.progress}%` },
                      ]}
                    />
                  </View>
                )}

                {download.status === 'failed' && download.errorMessage && (
                  <Text style={[styles.downloadInfo, { color: colors.error }]}>
                    {download.errorMessage}
                  </Text>
                )}
              </View>
            ))
          )}
        </View>
      </ScrollView>

      <Modal
        visible={deleteModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setDeleteModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Delete Download</Text>
            <Text style={styles.modalText}>
              Are you sure you want to delete this download?
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonCancel]}
                onPress={() => setDeleteModalVisible(false)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonConfirm]}
                onPress={confirmDelete}
              >
                <Text style={[styles.modalButtonText, { color: colors.onError }]}>
                  Delete
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={errorModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setErrorModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Download Error</Text>
            <Text style={styles.modalText}>{errorMessage}</Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonCancel]}
                onPress={() => setErrorModalVisible(false)}
              >
                <Text style={styles.modalButtonText}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
