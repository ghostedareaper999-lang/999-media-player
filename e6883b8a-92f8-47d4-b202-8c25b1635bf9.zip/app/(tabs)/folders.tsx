
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, spacing, borderRadius, typography, commonStyles } from '@/styles/commonStyles';

interface Folder {
  id: string;
  name: string;
  path: string;
  trackCount: number;
  excluded: boolean;
}

export default function FoldersScreen() {
  const [folders] = useState<Folder[]>([
    { id: '1', name: 'Music', path: '/storage/Music', trackCount: 45, excluded: false },
    { id: '2', name: 'Downloads', path: '/storage/Downloads', trackCount: 12, excluded: false },
    { id: '3', name: 'Podcasts', path: '/storage/Podcasts', trackCount: 8, excluded: true },
  ]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newFolderPath, setNewFolderPath] = useState('');

  const handleAddFolder = () => {
    console.log('[Folders] Adding folder:', newFolderPath);
    setShowAddModal(false);
    setNewFolderPath('');
    // TODO: Backend Integration - POST /api/folders with { path } → { id, name, path, trackCount, excluded }
  };

  const handleToggleExclude = (folder: Folder) => {
    console.log('[Folders] Toggling exclude for folder:', folder.name);
    // TODO: Backend Integration - PUT /api/folders/:id with { excluded: !folder.excluded }
  };

  const renderFolderItem = ({ item }: { item: Folder }) => {
    const trackCountText = `${item.trackCount} ${item.trackCount === 1 ? 'track' : 'tracks'}`;
    const statusText = item.excluded ? 'Excluded' : 'Included';
    const statusColor = item.excluded ? colors.error : colors.success;

    return (
      <TouchableOpacity
        style={styles.folderItem}
        onPress={() => console.log('[Folders] Tapped folder:', item.name)}
      >
        <View style={styles.folderIcon}>
          <IconSymbol
            ios_icon_name="folder.fill"
            android_material_icon_name="folder"
            size={32}
            color={item.excluded ? colors.textSecondary : colors.primary}
          />
        </View>
        <View style={styles.folderInfo}>
          <Text style={styles.folderName}>{item.name}</Text>
          <Text style={styles.folderPath}>{item.path}</Text>
          <View style={styles.folderMeta}>
            <Text style={styles.trackCount}>{trackCountText}</Text>
            <Text style={[styles.status, { color: statusColor }]}>{statusText}</Text>
          </View>
        </View>
        <TouchableOpacity
          style={styles.excludeButton}
          onPress={() => handleToggleExclude(item)}
        >
          <IconSymbol
            ios_icon_name={item.excluded ? 'eye.slash' : 'eye'}
            android_material_icon_name={item.excluded ? 'visibility-off' : 'visibility'}
            size={20}
            color={colors.textSecondary}
          />
        </TouchableOpacity>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={styles.container}>
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Folders</Text>
            <Text style={styles.subtitle}>Manage your music folders</Text>
          </View>
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => setShowAddModal(true)}
          >
            <IconSymbol
              ios_icon_name="plus"
              android_material_icon_name="add"
              size={24}
              color={colors.onPrimary}
            />
          </TouchableOpacity>
        </View>

        <FlatList
          data={folders}
          renderItem={renderFolderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />

        <Modal
          visible={showAddModal}
          transparent
          animationType="fade"
          onRequestClose={() => setShowAddModal(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Add Folder</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Enter folder path..."
                placeholderTextColor={colors.textSecondary}
                value={newFolderPath}
                onChangeText={setNewFolderPath}
              />
              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={[styles.modalButton, styles.cancelButton]}
                  onPress={() => setShowAddModal(false)}
                >
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalButton, styles.addButtonModal]}
                  onPress={handleAddFolder}
                >
                  <Text style={styles.addButtonText}>Add</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.md,
  },
  title: {
    ...typography.headlineLarge,
    color: colors.text,
    fontWeight: '700',
  },
  subtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: borderRadius.full,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 100,
  },
  folderItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  folderIcon: {
    width: 56,
    height: 56,
    borderRadius: borderRadius.md,
    backgroundColor: colors.primaryContainer,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  folderInfo: {
    flex: 1,
  },
  folderName: {
    ...typography.titleMedium,
    color: colors.text,
    fontWeight: '600',
  },
  folderPath: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  folderMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.xs,
  },
  trackCount: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginRight: spacing.md,
  },
  status: {
    ...typography.labelSmall,
    fontWeight: '600',
  },
  excludeButton: {
    padding: spacing.sm,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    width: '85%',
    maxWidth: 400,
  },
  modalTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '600',
    marginBottom: spacing.md,
  },
  modalInput: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    ...typography.bodyMedium,
    color: colors.text,
    marginBottom: spacing.lg,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  modalButton: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    marginLeft: spacing.sm,
  },
  cancelButton: {
    backgroundColor: colors.surfaceVariant,
  },
  cancelButtonText: {
    ...typography.labelLarge,
    color: colors.text,
  },
  addButtonModal: {
    backgroundColor: colors.primary,
  },
  addButtonText: {
    ...typography.labelLarge,
    color: colors.onPrimary,
    fontWeight: '600',
  },
});
