
import { Tabs } from 'expo-router';
import React from 'react';
import { Platform, Dimensions } from 'react-native';
import FloatingTabBar from '@/components/FloatingTabBar';
import { colors } from '@/styles/commonStyles';

const { width: screenWidth } = Dimensions.get('window');

export default function TabLayout() {
  if (Platform.OS === 'ios') {
    return null; // iOS uses native tabs from _layout.ios.tsx
  }

  const tabs = [
    {
      name: '(home)',
      label: 'Home',
      icon: 'home',
      route: '/(tabs)/(home)' as any,
    },
    {
      name: 'tracks',
      label: 'Tracks',
      icon: 'music-note',
      route: '/(tabs)/tracks' as any,
    },
    {
      name: 'albums',
      label: 'Albums',
      icon: 'album',
      route: '/(tabs)/albums' as any,
    },
    {
      name: 'artists',
      label: 'Artists',
      icon: 'person',
      route: '/(tabs)/artists' as any,
    },
    {
      name: 'playlists',
      label: 'Playlists',
      icon: 'playlist-play',
      route: '/(tabs)/playlists' as any,
    },
  ];

  return (
    <>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarStyle: { display: 'none' },
        }}
      >
        <Tabs.Screen name="(home)" options={{ headerShown: false }} />
        <Tabs.Screen name="tracks" options={{ headerShown: false }} />
        <Tabs.Screen name="albums" options={{ headerShown: false }} />
        <Tabs.Screen name="artists" options={{ headerShown: false }} />
        <Tabs.Screen name="genres" options={{ headerShown: false }} />
        <Tabs.Screen name="playlists" options={{ headerShown: false }} />
        <Tabs.Screen name="folders" options={{ headerShown: false }} />
        <Tabs.Screen name="library" options={{ href: null }} />
        <Tabs.Screen name="profile" options={{ href: null }} />
      </Tabs>
      <FloatingTabBar tabs={tabs} containerWidth={screenWidth * 0.92} />
    </>
  );
}
