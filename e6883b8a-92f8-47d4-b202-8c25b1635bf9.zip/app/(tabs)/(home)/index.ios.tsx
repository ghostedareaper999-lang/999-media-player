
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { IconSymbol } from '@/components/IconSymbol';
import { usePlayer } from '@/contexts/PlayerContext';
import { useAuth } from '@/contexts/AuthContext';
import { authenticatedGet, authenticatedPost } from '@/utils/api';
import { colors, spacing, borderRadius, typography, commonStyles } from '@/styles/commonStyles';
import * as DocumentPicker from 'expo-document-picker';
import { Stack, useRouter } from 'expo-router';
import { MediaTrack, PlayHistory } from '@/types/media';
import Drawer from '@/components/Drawer';

export default function HomeScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const { play, setQueue } = usePlayer();
  const [recentTracks, setRecentTracks] = useState<MediaTrack[]>([]);
  const [mostPlayed, setMostPlayed] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [showDrawer, setShowDrawer] = useState(false);

  useEffect(() => {
    loadHomeData();
  }, []);

  const loadHomeData = async () => {
    try {
      setLoading(true);
      console.log('[Home] Loading home data');

      const [tracksData, historyData] = await Promise.all([
        authenticatedGet<MediaTrack[]>('/api/tracks'),
        authenticatedGet<any[]>('/api/history/most-played'),
      ]);

      console.log('[Home] Loaded', tracksData.length, 'tracks');
      console.log('[Home] Loaded', historyData.length, 'most played tracks');

      setRecentTracks(tracksData.slice(0, 10));
      setMostPlayed(historyData.slice(0, 10));
    } catch (error) {
      console.error('[Home] Error loading home data:', error);
    } finally {
      setLoading(false);
    }
  };

  const pickMediaFiles = async () => {
    try {
      console.log('[Home] Opening document picker');
      const result = await DocumentPicker.getDocumentAsync({
        type: ['audio/*', 'video/*'],
        copyToCacheDirectory: true,
        multiple: true,
      });

      if (result.canceled) {
        console.log('[Home] Document picker canceled');
        return;
      }

      setUploading(true);
      console.log('[Home] Uploading', result.assets.length, 'files');

      for (const asset of result.assets) {
        const formData = new FormData();
        formData.append('file', {
          uri: asset.uri,
          name: asset.name,
          type: asset.mimeType || 'application/octet-stream',
        } as any);

        try {
          await authenticatedPost('/api/tracks', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
          });
          console.log('[Home] Uploaded:', asset.name);
        } catch (error) {
          console.error('[Home] Error uploading file:', asset.name, error);
        }
      }

      await loadHomeData();
    } catch (error) {
      console.error('[Home] Error picking media files:', error);
    } finally {
      setUploading(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={commonStyles.centerContent}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Loading your library...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.menuButton}
            onPress={() => setShowDrawer(true)}
          >
            <IconSymbol
              ios_icon_name="line.horizontal.3"
              android_material_icon_name="menu"
              size={24}
              color={colors.text}
            />
          </TouchableOpacity>
          <View>
            <Text style={styles.greeting}>Welcome back</Text>
            <Text style={styles.userName}>{user?.name || 'Music Lover'}</Text>
          </View>
          <View style={styles.headerSpacer} />
        </View>

        <View style={styles.quickActions}>
          <QuickActionCard
            icon="upload"
            title="Upload Music"
            onPress={pickMediaFiles}
          />
          <QuickActionCard
            icon="swap-horiz"
            title="Video Converter"
            onPress={() => router.push('/video-converter')}
          />
          <QuickActionCard
            icon="playlist-play"
            title="Playlists"
            onPress={() => console.log('[Home] Navigate to playlists')}
          />
          <QuickActionCard
            icon="settings"
            title="Settings"
            onPress={() => router.push('/settings')}
          />
        </View>

        {mostPlayed.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Most Played</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.horizontalList}
            >
              {mostPlayed.map((item, index) => (
                <TrackCard
                  key={index}
                  track={item.track}
                  playCount={item.playCount}
                />
              ))}
            </ScrollView>
          </View>
        )}

        {recentTracks.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Recent Tracks</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.horizontalList}
            >
              {recentTracks.map((track, index) => (
                <TrackCard key={index} track={track} />
              ))}
            </ScrollView>
          </View>
        )}

        {recentTracks.length === 0 && mostPlayed.length === 0 && (
          <View style={styles.emptyState}>
            <IconSymbol
              ios_icon_name="music.note"
              android_material_icon_name="music-note"
              size={64}
              color={colors.textSecondary}
            />
            <Text style={styles.emptyTitle}>No music yet</Text>
            <Text style={styles.emptySubtitle}>
              Upload your first tracks to get started
            </Text>
            <TouchableOpacity style={styles.uploadButton} onPress={pickMediaFiles}>
              <Text style={styles.uploadButtonText}>Upload Music</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>

      <Drawer visible={showDrawer} onClose={() => setShowDrawer(false)} />

      {uploading && (
        <Modal transparent visible={uploading}>
          <View style={styles.uploadingOverlay}>
            <View style={styles.uploadingCard}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={styles.uploadingText}>Uploading files...</Text>
            </View>
          </View>
        </Modal>
      )}
    </SafeAreaView>
  );
}

function QuickActionCard({
  icon,
  title,
  onPress,
}: {
  icon: string;
  title: string;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity style={styles.quickActionCard} onPress={onPress}>
      <View style={styles.quickActionIcon}>
        <IconSymbol
          ios_icon_name={icon}
          android_material_icon_name={icon}
          size={24}
          color={colors.primary}
        />
      </View>
      <Text style={styles.quickActionTitle}>{title}</Text>
    </TouchableOpacity>
  );
}

function TrackCard({ track, playCount }: { track: any; playCount?: number }) {
  const { play } = usePlayer();

  const handlePress = () => {
    console.log('[Home] Playing track:', track.title || track.fileName);
    play(track);
  };

  const displayTitle = track.title || track.fileName || 'Unknown Track';
  const displayArtist = track.artist || 'Unknown Artist';

  return (
    <TouchableOpacity style={styles.trackCard} onPress={handlePress}>
      <View style={styles.trackArtwork}>
        {track.artworkUrl ? (
          <Image source={{ uri: track.artworkUrl }} style={styles.artworkImage} />
        ) : (
          <View style={styles.placeholderArtwork}>
            <IconSymbol
              ios_icon_name="music.note"
              android_material_icon_name="music-note"
              size={32}
              color={colors.textSecondary}
            />
          </View>
        )}
      </View>
      <Text style={styles.trackTitle} numberOfLines={1}>
        {displayTitle}
      </Text>
      <Text style={styles.trackArtist} numberOfLines={1}>
        {displayArtist}
      </Text>
      {playCount !== undefined && (
        <Text style={styles.playCount}>{playCount} plays</Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.lg,
  },
  menuButton: {
    padding: spacing.sm,
  },
  greeting: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
  },
  userName: {
    ...typography.headlineSmall,
    color: colors.text,
    fontWeight: '700',
    marginTop: spacing.xs,
  },
  headerSpacer: {
    width: 40,
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.lg,
  },
  quickActionCard: {
    width: '48%',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginRight: '2%',
    marginBottom: spacing.sm,
    alignItems: 'center',
  },
  quickActionIcon: {
    width: 56,
    height: 56,
    borderRadius: borderRadius.full,
    backgroundColor: colors.primaryContainer,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  quickActionTitle: {
    ...typography.labelLarge,
    color: colors.text,
    textAlign: 'center',
  },
  section: {
    marginBottom: spacing.lg,
  },
  sectionTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '700',
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  horizontalList: {
    paddingHorizontal: spacing.lg,
  },
  trackCard: {
    width: 140,
    marginRight: spacing.md,
  },
  trackArtwork: {
    width: 140,
    height: 140,
    borderRadius: borderRadius.md,
    marginBottom: spacing.sm,
    overflow: 'hidden',
  },
  artworkImage: {
    width: '100%',
    height: '100%',
  },
  placeholderArtwork: {
    width: '100%',
    height: '100%',
    backgroundColor: colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackTitle: {
    ...typography.titleSmall,
    color: colors.text,
    fontWeight: '600',
  },
  trackArtist: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  playCount: {
    ...typography.labelSmall,
    color: colors.primary,
    marginTop: spacing.xs,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxl,
    paddingHorizontal: spacing.lg,
  },
  emptyTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '600',
    marginTop: spacing.lg,
  },
  emptySubtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.sm,
  },
  uploadButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.full,
    marginTop: spacing.lg,
  },
  uploadButtonText: {
    ...typography.labelLarge,
    color: colors.onPrimary,
    fontWeight: '600',
  },
  loadingText: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.md,
  },
  uploadingOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  uploadingCard: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.xl,
    alignItems: 'center',
  },
  uploadingText: {
    ...typography.bodyLarge,
    color: colors.text,
    marginTop: spacing.md,
  },
});
