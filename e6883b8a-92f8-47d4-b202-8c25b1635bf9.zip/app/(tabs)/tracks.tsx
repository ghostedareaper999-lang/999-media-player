
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  TextInput,
  Platform,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, spacing, borderRadius, typography, commonStyles, formatDuration } from '@/styles/commonStyles';
import { usePlayer } from '@/contexts/PlayerContext';
import { MediaTrack } from '@/types/media';
import { authenticatedGet, authenticatedDelete } from '@/utils/api';

export default function TracksScreen() {
  const [tracks, setTracks] = useState<MediaTrack[]>([]);
  const [filteredTracks, setFilteredTracks] = useState<MediaTrack[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'title' | 'artist' | 'album' | 'duration'>('title');
  const [errorMessage, setErrorMessage] = useState('');
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [deleteConfirmTrack, setDeleteConfirmTrack] = useState<MediaTrack | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const player = usePlayer();

  useEffect(() => {
    loadTracks();
  }, []);

  useEffect(() => {
    filterAndSortTracks();
  }, [tracks, searchQuery, sortBy]);

  const loadTracks = async () => {
    console.log('[API] Loading tracks');
    setLoading(true);
    try {
      const data = await authenticatedGet<MediaTrack[]>('/api/tracks');
      console.log('[API] Tracks loaded:', data.length);
      setTracks(data);
    } catch (error) {
      console.error('[API] Error loading tracks:', error);
      setErrorMessage('Failed to load tracks. Please try again.');
      setShowErrorModal(true);
    } finally {
      setLoading(false);
    }
  };

  const filterAndSortTracks = () => {
    let result = [...tracks];

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (track) =>
          track.title?.toLowerCase().includes(query) ||
          track.artist?.toLowerCase().includes(query) ||
          track.album?.toLowerCase().includes(query) ||
          track.fileName.toLowerCase().includes(query)
      );
    }

    // Sort
    result.sort((a, b) => {
      switch (sortBy) {
        case 'title':
          const titleA = a.title || a.fileName;
          const titleB = b.title || b.fileName;
          return titleA.localeCompare(titleB);
        case 'artist':
          const artistA = a.artist || '';
          const artistB = b.artist || '';
          return artistA.localeCompare(artistB);
        case 'album':
          const albumA = a.album || '';
          const albumB = b.album || '';
          return albumA.localeCompare(albumB);
        case 'duration':
          const durationA = a.duration || 0;
          const durationB = b.duration || 0;
          return durationB - durationA;
        default:
          return 0;
      }
    });

    setFilteredTracks(result);
  };

  const handlePlayTrack = (track: MediaTrack, index: number) => {
    console.log('Playing track:', track.title || track.fileName);
    player.setQueue(filteredTracks, index);
  };

  const handleAddToQueue = (track: MediaTrack) => {
    console.log('Adding track to queue:', track.title || track.fileName);
    player.addToQueue(track);
  };

  const handleDeleteTrack = (track: MediaTrack) => {
    setDeleteConfirmTrack(track);
    setShowDeleteModal(true);
  };

  const confirmDeleteTrack = async () => {
    if (!deleteConfirmTrack) return;
    try {
      console.log('[API] Deleting track:', deleteConfirmTrack.id);
      await authenticatedDelete(`/api/tracks/${deleteConfirmTrack.id}`);
      setTracks((prev) => prev.filter((t) => t.id !== deleteConfirmTrack.id));
      console.log('[API] Track deleted successfully');
    } catch (error) {
      console.error('[API] Error deleting track:', error);
      setErrorMessage('Failed to delete track. Please try again.');
      setShowErrorModal(true);
    } finally {
      setShowDeleteModal(false);
      setDeleteConfirmTrack(null);
    }
  };

  const renderTrackItem = ({ item, index }: { item: MediaTrack; index: number }) => {
    const isPlaying = player.currentTrack?.id === item.id && player.isPlaying;
    const artworkUri = item.artworkUrl || 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=100';
    const trackTitle = item.title || item.fileName;
    const trackArtist = item.artist || 'Unknown Artist';
    const trackDuration = formatDuration(item.duration || 0);

    return (
      <TouchableOpacity
        style={[styles.trackItem, isPlaying && styles.trackItemPlaying]}
        onPress={() => handlePlayTrack(item, index)}
      >
        <Image source={{ uri: artworkUri }} style={styles.trackItemArtwork} />
        <View style={styles.trackItemInfo}>
          <Text style={styles.trackItemTitle} numberOfLines={1}>
            {trackTitle}
          </Text>
          <Text style={styles.trackItemArtist} numberOfLines={1}>
            {trackArtist}
          </Text>
        </View>
        <Text style={styles.trackItemDuration}>{trackDuration}</Text>
        <TouchableOpacity
          style={styles.trackItemMore}
          onPress={() => handleAddToQueue(item)}
        >
          <IconSymbol
            ios_icon_name="plus.circle"
            android_material_icon_name="playlist-add"
            size={24}
            color={colors.textSecondary}
          />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.trackItemMore}
          onPress={() => handleDeleteTrack(item)}
        >
          <IconSymbol
            ios_icon_name="trash"
            android_material_icon_name="delete"
            size={24}
            color={colors.error}
          />
        </TouchableOpacity>
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={commonStyles.centerContent}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  const tracksCountText = `${filteredTracks.length} tracks`;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Tracks</Text>
        <Text style={styles.headerSubtitle}>{tracksCountText}</Text>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <IconSymbol
          ios_icon_name="magnifyingglass"
          android_material_icon_name="search"
          size={20}
          color={colors.textSecondary}
        />
        <TextInput
          style={styles.searchInput}
          placeholder="Search tracks..."
          placeholderTextColor={colors.textSecondary}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity onPress={() => setSearchQuery('')}>
            <IconSymbol
              ios_icon_name="xmark.circle.fill"
              android_material_icon_name="cancel"
              size={20}
              color={colors.textSecondary}
            />
          </TouchableOpacity>
        )}
      </View>

      {/* Sort Options */}
      <View style={styles.sortContainer}>
        <Text style={styles.sortLabel}>Sort by:</Text>
        <View style={styles.sortButtons}>
          <SortButton
            label="Title"
            active={sortBy === 'title'}
            onPress={() => setSortBy('title')}
          />
          <SortButton
            label="Artist"
            active={sortBy === 'artist'}
            onPress={() => setSortBy('artist')}
          />
          <SortButton
            label="Album"
            active={sortBy === 'album'}
            onPress={() => setSortBy('album')}
          />
          <SortButton
            label="Duration"
            active={sortBy === 'duration'}
            onPress={() => setSortBy('duration')}
          />
        </View>
      </View>

      {/* Tracks List */}
      {filteredTracks.length > 0 ? (
        <FlatList
          data={filteredTracks}
          renderItem={renderTrackItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.emptyState}>
          <IconSymbol
            ios_icon_name="music.note"
            android_material_icon_name="music-note"
            size={64}
            color={colors.textSecondary}
          />
          <Text style={styles.emptyTitle}>No Tracks Found</Text>
          <Text style={styles.emptyText}>
            {searchQuery ? 'Try a different search term' : 'Add music files to get started'}
          </Text>
        </View>
      )}

      {/* Error Modal */}
      <Modal
        visible={showErrorModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowErrorModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Error</Text>
            <Text style={styles.modalMessage}>{errorMessage}</Text>
            <TouchableOpacity
              style={styles.modalButtonPrimary}
              onPress={() => setShowErrorModal(false)}
            >
              <Text style={styles.modalButtonTextPrimary}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Delete Confirm Modal */}
      <Modal
        visible={showDeleteModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowDeleteModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Delete Track</Text>
            <Text style={styles.modalMessage}>
              Are you sure you want to delete "{deleteConfirmTrack?.title || deleteConfirmTrack?.fileName}"?
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.modalButtonCancel}
                onPress={() => { setShowDeleteModal(false); setDeleteConfirmTrack(null); }}
              >
                <Text style={styles.modalButtonTextCancel}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalButtonDelete}
                onPress={confirmDeleteTrack}
              >
                <Text style={styles.modalButtonTextPrimary}>Delete</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function SortButton({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <TouchableOpacity
      style={[styles.sortButton, active && styles.sortButtonActive]}
      onPress={onPress}
    >
      <Text style={[styles.sortButtonText, active && styles.sortButtonTextActive]}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 48 : 0,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: {
    ...typography.headlineLarge,
    color: colors.text,
    fontWeight: '700',
  },
  headerSubtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.full,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  searchInput: {
    flex: 1,
    ...typography.bodyMedium,
    color: colors.text,
    marginLeft: spacing.sm,
  },
  sortContainer: {
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  sortLabel: {
    ...typography.labelMedium,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  sortButtons: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  sortButton: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    backgroundColor: colors.surface,
  },
  sortButtonActive: {
    backgroundColor: colors.primary,
  },
  sortButtonText: {
    ...typography.labelMedium,
    color: colors.textSecondary,
  },
  sortButtonTextActive: {
    color: colors.onPrimary,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 120,
  },
  trackItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.outlineVariant,
  },
  trackItemPlaying: {
    backgroundColor: colors.primaryContainer,
    borderRadius: borderRadius.sm,
    paddingHorizontal: spacing.sm,
  },
  trackItemArtwork: {
    width: 48,
    height: 48,
    borderRadius: borderRadius.sm,
    backgroundColor: colors.surfaceVariant,
  },
  trackItemInfo: {
    flex: 1,
    marginLeft: spacing.md,
  },
  trackItemTitle: {
    ...typography.bodyMedium,
    color: colors.text,
    fontWeight: '600',
  },
  trackItemArtist: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: 2,
  },
  trackItemDuration: {
    ...typography.labelSmall,
    color: colors.textSecondary,
    marginRight: spacing.sm,
  },
  trackItemMore: {
    padding: spacing.xs,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  emptyTitle: {
    ...typography.headlineSmall,
    color: colors.text,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  emptyText: {
    ...typography.bodyLarge,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '600',
    marginBottom: spacing.sm,
  },
  modalMessage: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  modalButtonPrimary: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.sm,
    alignItems: 'center',
  },
  modalButtonCancel: {
    flex: 1,
    backgroundColor: colors.surfaceVariant,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.sm,
    alignItems: 'center',
  },
  modalButtonDelete: {
    flex: 1,
    backgroundColor: colors.errorContainer,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.sm,
    alignItems: 'center',
  },
  modalButtonTextPrimary: {
    ...typography.labelLarge,
    color: colors.onPrimary,
    fontWeight: '600',
  },
  modalButtonTextCancel: {
    ...typography.labelLarge,
    color: colors.text,
    fontWeight: '600',
  },
});
