
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '@react-navigation/native';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { LinearGradient } from 'expo-linear-gradient';

export default function LibraryScreen() {
  const theme = useTheme();

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient
        colors={[colors.background, colors.card]}
        style={styles.gradient}
      >
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <Text style={styles.title}>Library</Text>
            <Text style={styles.subtitle}>Your media collection</Text>
          </View>

          <View style={styles.emptyState}>
            <IconSymbol
              android_material_icon_name="video-library"
              ios_icon_name="folder.fill"
              size={100}
              color={colors.textSecondary}
            />
            <Text style={styles.emptyText}>No saved media</Text>
            <Text style={styles.emptySubtext}>
              Your recently played media will appear here
            </Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>Supported Formats</Text>
            <View style={styles.formatsList}>
              <FormatItem category="Video" formats="MP4, MOV, AVI, MKV, WebM" />
              <FormatItem category="Audio" formats="MP3, WAV, AAC, FLAC, OGG" />
            </View>
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

function FormatItem({ category, formats }: { category: string; formats: string }) {
  return (
    <View style={styles.formatItem}>
      <Text style={styles.formatCategory}>{category}</Text>
      <Text style={styles.formatText}>{formats}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  gradient: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 100,
  },
  header: {
    marginBottom: 24,
    paddingTop: Platform.OS === 'android' ? 24 : 0,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
    backgroundColor: colors.card,
    borderRadius: 20,
    marginBottom: 24,
  },
  emptyText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 20,
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  infoCard: {
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 20,
  },
  infoTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  formatsList: {
    gap: 16,
  },
  formatItem: {
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
    paddingLeft: 16,
  },
  formatCategory: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  formatText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
});
