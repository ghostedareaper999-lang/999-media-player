
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Platform,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, spacing, borderRadius, typography, commonStyles } from '@/styles/commonStyles';
import { Album } from '@/types/media';
import { authenticatedGet } from '@/utils/api';

export default function AlbumsScreen() {
  const [albums, setAlbums] = useState<Album[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [showErrorModal, setShowErrorModal] = useState(false);

  useEffect(() => {
    loadAlbums();
  }, []);

  const loadAlbums = async () => {
    console.log('[API] Loading albums');
    setLoading(true);
    try {
      const data = await authenticatedGet<Album[]>('/api/tracks/albums');
      console.log('[API] Albums loaded:', data.length);
      setAlbums(data);
    } catch (error) {
      console.error('[API] Error loading albums:', error);
      setErrorMessage('Failed to load albums. Please try again.');
      setShowErrorModal(true);
    } finally {
      setLoading(false);
    }
  };

  const handleAlbumPress = (album: Album) => {
    console.log('Album tapped:', album.album);
    // Navigate to album details
  };

  const renderAlbumItem = ({ item }: { item: Album }) => {
    const artworkUri = item.artworkUrl || 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300';
    const albumName = item.album || 'Unknown Album';
    const artistName = item.artist || 'Unknown Artist';
    const trackCountText = `${item.trackCount} tracks`;

    return (
      <TouchableOpacity
        style={styles.albumCard}
        onPress={() => handleAlbumPress(item)}
      >
        <Image source={{ uri: artworkUri }} style={styles.albumArtwork} />
        <Text style={styles.albumName} numberOfLines={2}>
          {albumName}
        </Text>
        <Text style={styles.albumArtist} numberOfLines={1}>
          {artistName}
        </Text>
        <Text style={styles.albumTracks}>{trackCountText}</Text>
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={commonStyles.centerContent}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  const albumsCountText = `${albums.length} albums`;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Albums</Text>
        <Text style={styles.headerSubtitle}>{albumsCountText}</Text>
      </View>

      {albums.length > 0 ? (
        <FlatList
          data={albums}
          renderItem={renderAlbumItem}
          keyExtractor={(item, index) => `${item.album}-${index}`}
          numColumns={2}
          contentContainerStyle={styles.listContent}
          columnWrapperStyle={styles.columnWrapper}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.emptyState}>
          <IconSymbol
            ios_icon_name="square.stack"
            android_material_icon_name="album"
            size={64}
            color={colors.textSecondary}
          />
          <Text style={styles.emptyTitle}>No Albums Found</Text>
          <Text style={styles.emptyText}>
            Add music files with album information to see them here
          </Text>
        </View>
      )}

      {/* Error Modal */}
      <Modal
        visible={showErrorModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowErrorModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Error</Text>
            <Text style={styles.modalMessage}>{errorMessage}</Text>
            <TouchableOpacity
              style={styles.modalButtonPrimary}
              onPress={() => setShowErrorModal(false)}
            >
              <Text style={styles.modalButtonText}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 48 : 0,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: {
    ...typography.headlineLarge,
    color: colors.text,
    fontWeight: '700',
  },
  headerSubtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 120,
  },
  columnWrapper: {
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
  albumCard: {
    width: '48%',
  },
  albumArtwork: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: borderRadius.md,
    backgroundColor: colors.surfaceVariant,
    marginBottom: spacing.sm,
  },
  albumName: {
    ...typography.bodyMedium,
    color: colors.text,
    fontWeight: '600',
    marginBottom: 2,
  },
  albumArtist: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginBottom: 2,
  },
  albumTracks: {
    ...typography.labelSmall,
    color: colors.textTertiary,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  emptyTitle: {
    ...typography.headlineSmall,
    color: colors.text,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  emptyText: {
    ...typography.bodyLarge,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '600',
    marginBottom: spacing.sm,
  },
  modalMessage: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
  },
  modalButtonPrimary: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.sm,
    alignItems: 'center',
  },
  modalButtonText: {
    ...typography.labelLarge,
    color: colors.onPrimary,
    fontWeight: '600',
  },
});
