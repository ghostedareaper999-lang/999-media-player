
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  TextInput,
  Modal,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, spacing, borderRadius, typography, commonStyles } from '@/styles/commonStyles';
import { Playlist } from '@/types/media';
import { authenticatedGet, authenticatedPost, authenticatedDelete } from '@/utils/api';

export default function PlaylistsScreen() {
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [creating, setCreating] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [deleteConfirmPlaylist, setDeleteConfirmPlaylist] = useState<Playlist | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  useEffect(() => {
    loadPlaylists();
  }, []);

  const loadPlaylists = async () => {
    console.log('[API] Loading playlists');
    setLoading(true);
    try {
      const data = await authenticatedGet<Playlist[]>('/api/playlists');
      console.log('[API] Playlists loaded:', data.length);
      setPlaylists(data);
    } catch (error) {
      console.error('[API] Error loading playlists:', error);
      setErrorMessage('Failed to load playlists. Please try again.');
      setShowErrorModal(true);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePlaylist = async () => {
    if (!newPlaylistName.trim()) {
      console.log('Playlist name is empty');
      return;
    }

    console.log('[API] Creating playlist:', newPlaylistName);
    setCreating(true);
    try {
      const created = await authenticatedPost<Playlist>('/api/playlists', { name: newPlaylistName.trim() });
      console.log('[API] Playlist created:', created.id);
      setNewPlaylistName('');
      setShowCreateModal(false);
      setPlaylists((prev) => [created, ...prev]);
    } catch (error) {
      console.error('[API] Error creating playlist:', error);
      setErrorMessage('Failed to create playlist. Please try again.');
      setShowErrorModal(true);
    } finally {
      setCreating(false);
    }
  };

  const handleDeletePlaylist = (playlist: Playlist) => {
    setDeleteConfirmPlaylist(playlist);
    setShowDeleteModal(true);
  };

  const confirmDeletePlaylist = async () => {
    if (!deleteConfirmPlaylist) return;
    try {
      console.log('[API] Deleting playlist:', deleteConfirmPlaylist.id);
      await authenticatedDelete(`/api/playlists/${deleteConfirmPlaylist.id}`);
      setPlaylists((prev) => prev.filter((p) => p.id !== deleteConfirmPlaylist.id));
      console.log('[API] Playlist deleted successfully');
    } catch (error) {
      console.error('[API] Error deleting playlist:', error);
      setErrorMessage('Failed to delete playlist. Please try again.');
      setShowErrorModal(true);
    } finally {
      setShowDeleteModal(false);
      setDeleteConfirmPlaylist(null);
    }
  };

  const handlePlaylistPress = (playlist: Playlist) => {
    console.log('Playlist tapped:', playlist.name);
    // Navigate to playlist details
  };

  const renderPlaylistItem = ({ item }: { item: Playlist }) => {
    const artworkUri = item.artworkUrl || 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300';
    const playlistName = item.name;
    const trackCountText = `${item.trackCount} tracks`;

    return (
      <TouchableOpacity
        style={styles.playlistCard}
        onPress={() => handlePlaylistPress(item)}
      >
        <Image source={{ uri: artworkUri }} style={styles.playlistArtwork} />
        <View style={styles.playlistInfo}>
          <Text style={styles.playlistName} numberOfLines={2}>
            {playlistName}
          </Text>
          <Text style={styles.playlistTracks}>{trackCountText}</Text>
        </View>
        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => handleDeletePlaylist(item)}
        >
          <IconSymbol
            ios_icon_name="trash"
            android_material_icon_name="delete"
            size={20}
            color={colors.error}
          />
        </TouchableOpacity>
        <IconSymbol
          ios_icon_name="chevron.right"
          android_material_icon_name="chevron-right"
          size={24}
          color={colors.textSecondary}
        />
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={commonStyles.centerContent}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  const playlistsCountText = `${playlists.length} playlists`;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Playlists</Text>
          <Text style={styles.headerSubtitle}>{playlistsCountText}</Text>
        </View>
        <TouchableOpacity
          style={styles.createButton}
          onPress={() => setShowCreateModal(true)}
        >
          <IconSymbol
            ios_icon_name="plus.circle.fill"
            android_material_icon_name="add-circle"
            size={32}
            color={colors.primary}
          />
        </TouchableOpacity>
      </View>

      {playlists.length > 0 ? (
        <FlatList
          data={playlists}
          renderItem={renderPlaylistItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.emptyState}>
          <IconSymbol
            ios_icon_name="music.note.list"
            android_material_icon_name="playlist-play"
            size={64}
            color={colors.textSecondary}
          />
          <Text style={styles.emptyTitle}>No Playlists Yet</Text>
          <Text style={styles.emptyText}>
            Create your first playlist to organize your music
          </Text>
          <TouchableOpacity
            style={styles.emptyButton}
            onPress={() => setShowCreateModal(true)}
          >
            <Text style={styles.emptyButtonText}>Create Playlist</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Create Playlist Modal */}
      <Modal
        visible={showCreateModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowCreateModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Create Playlist</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Playlist name"
              placeholderTextColor={colors.textSecondary}
              value={newPlaylistName}
              onChangeText={setNewPlaylistName}
              autoFocus
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonCancel]}
                onPress={() => {
                  setShowCreateModal(false);
                  setNewPlaylistName('');
                }}
              >
                <Text style={styles.modalButtonTextCancel}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonCreate]}
                onPress={handleCreatePlaylist}
                disabled={creating}
              >
                {creating ? (
                  <ActivityIndicator size="small" color={colors.onPrimary} />
                ) : (
                  <Text style={styles.modalButtonTextCreate}>Create</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Error Modal */}
      <Modal
        visible={showErrorModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowErrorModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Error</Text>
            <Text style={styles.modalMessage}>{errorMessage}</Text>
            <TouchableOpacity
              style={[styles.modalButton, styles.modalButtonCreate]}
              onPress={() => setShowErrorModal(false)}
            >
              <Text style={styles.modalButtonTextCreate}>OK</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Delete Confirm Modal */}
      <Modal
        visible={showDeleteModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowDeleteModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Delete Playlist</Text>
            <Text style={styles.modalMessage}>
              Are you sure you want to delete "{deleteConfirmPlaylist?.name}"?
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonCancel]}
                onPress={() => { setShowDeleteModal(false); setDeleteConfirmPlaylist(null); }}
              >
                <Text style={styles.modalButtonTextCancel}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonDelete]}
                onPress={confirmDeletePlaylist}
              >
                <Text style={styles.modalButtonTextCreate}>Delete</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingTop: Platform.OS === 'android' ? 48 : 0,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerTitle: {
    ...typography.headlineLarge,
    color: colors.text,
    fontWeight: '700',
  },
  headerSubtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  createButton: {
    padding: spacing.xs,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 120,
  },
  playlistCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  playlistArtwork: {
    width: 64,
    height: 64,
    borderRadius: borderRadius.sm,
    backgroundColor: colors.surfaceVariant,
  },
  playlistInfo: {
    flex: 1,
    marginLeft: spacing.md,
  },
  playlistName: {
    ...typography.bodyLarge,
    color: colors.text,
    fontWeight: '600',
    marginBottom: spacing.xs,
  },
  playlistTracks: {
    ...typography.bodySmall,
    color: colors.textSecondary,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  emptyTitle: {
    ...typography.headlineSmall,
    color: colors.text,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  emptyText: {
    ...typography.bodyLarge,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  emptyButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.full,
  },
  emptyButtonText: {
    ...typography.labelLarge,
    color: colors.onPrimary,
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  modalContent: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '600',
    marginBottom: spacing.md,
  },
  modalInput: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.sm,
    padding: spacing.md,
    ...typography.bodyMedium,
    color: colors.text,
    marginBottom: spacing.lg,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  modalButton: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.sm,
    alignItems: 'center',
  },
  modalButtonCancel: {
    backgroundColor: colors.surfaceVariant,
  },
  modalButtonCreate: {
    backgroundColor: colors.primary,
  },
  modalButtonTextCancel: {
    ...typography.labelLarge,
    color: colors.text,
    fontWeight: '600',
  },
  modalButtonTextCreate: {
    ...typography.labelLarge,
    color: colors.onPrimary,
    fontWeight: '600',
  },
  modalButtonDelete: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.sm,
    alignItems: 'center',
    backgroundColor: colors.errorContainer,
  },
  modalMessage: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
  },
  deleteButton: {
    padding: spacing.xs,
    marginRight: spacing.xs,
  },
});
