
import React from 'react';
import { NativeTabs, Icon, Label } from 'expo-router/unstable-native-tabs';
import { Platform } from 'react-native';

export default function TabLayout() {
  return (
    <NativeTabs>
      <NativeTabs.Trigger name="(home)">
        <Label>Home</Label>
        <Icon sf={{ default: 'house', selected: 'house.fill' }} drawable="home" />
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="tracks">
        <Label>Tracks</Label>
        <Icon sf={{ default: 'music.note', selected: 'music.note' }} drawable="music-note" />
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="albums">
        <Label>Albums</Label>
        <Icon sf={{ default: 'square.stack', selected: 'square.stack.fill' }} drawable="album" />
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="playlists">
        <Label>Playlists</Label>
        <Icon sf={{ default: 'music.note.list', selected: 'music.note.list' }} drawable="playlist-play" />
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="profile">
        <Label>Profile</Label>
        <Icon sf={{ default: 'person', selected: 'person.fill' }} drawable="person" />
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}
