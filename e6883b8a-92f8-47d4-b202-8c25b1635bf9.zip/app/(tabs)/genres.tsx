
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, spacing, borderRadius, typography, commonStyles } from '@/styles/commonStyles';
import { authenticatedGet } from '@/utils/api';

interface Genre {
  genre: string;
  trackCount: number;
}

export default function GenresScreen() {
  const [genres, setGenres] = useState<Genre[]>([]);
  const [filteredGenres, setFilteredGenres] = useState<Genre[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadGenres();
  }, []);

  useEffect(() => {
    filterGenres();
  }, [genres, searchQuery]);

  const loadGenres = async () => {
    try {
      setLoading(true);
      console.log('[Genres] Loading genres from API');
      const data = await authenticatedGet<Genre[]>('/api/tracks/genres');
      console.log('[Genres] Loaded', data.length, 'genres');
      setGenres(data);
    } catch (error) {
      console.error('[Genres] Error loading genres:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterGenres = () => {
    if (!searchQuery.trim()) {
      setFilteredGenres(genres);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = genres.filter((genre) =>
      genre.genre.toLowerCase().includes(query)
    );
    setFilteredGenres(filtered);
  };

  const getGenreColor = (index: number) => {
    const genreColors = [
      colors.primary,
      colors.secondary,
      colors.tertiary,
      colors.error,
      colors.success,
      colors.warning,
      colors.info,
    ];
    return genreColors[index % genreColors.length];
  };

  const renderGenreItem = ({ item, index }: { item: Genre; index: number }) => {
    const trackCountText = `${item.trackCount} ${item.trackCount === 1 ? 'track' : 'tracks'}`;
    const genreColor = getGenreColor(index);

    return (
      <TouchableOpacity
        style={styles.genreItem}
        onPress={() => console.log('[Genres] Tapped genre:', item.genre)}
      >
        <View style={[styles.genreIcon, { backgroundColor: genreColor + '20' }]}>
          <IconSymbol
            ios_icon_name="music.note"
            android_material_icon_name="music-note"
            size={28}
            color={genreColor}
          />
        </View>
        <View style={styles.genreInfo}>
          <Text style={styles.genreName}>{item.genre}</Text>
          <Text style={styles.trackCount}>{trackCountText}</Text>
        </View>
        <IconSymbol
          ios_icon_name="chevron.right"
          android_material_icon_name="chevron-right"
          size={20}
          color={colors.textSecondary}
        />
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <View style={commonStyles.centerContent}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Loading genres...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Genres</Text>
          <Text style={styles.subtitle}>
            {filteredGenres.length} {filteredGenres.length === 1 ? 'genre' : 'genres'}
          </Text>
        </View>

        <View style={styles.searchContainer}>
          <IconSymbol
            ios_icon_name="magnifyingglass"
            android_material_icon_name="search"
            size={20}
            color={colors.textSecondary}
          />
          <TextInput
            style={styles.searchInput}
            placeholder="Search genres..."
            placeholderTextColor={colors.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <IconSymbol
                ios_icon_name="xmark.circle.fill"
                android_material_icon_name="cancel"
                size={20}
                color={colors.textSecondary}
              />
            </TouchableOpacity>
          )}
        </View>

        <FlatList
          data={filteredGenres}
          renderItem={renderGenreItem}
          keyExtractor={(item, index) => `${item.genre}-${index}`}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.sm,
  },
  title: {
    ...typography.headlineLarge,
    color: colors.text,
    fontWeight: '700',
  },
  subtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  searchInput: {
    flex: 1,
    ...typography.bodyMedium,
    color: colors.text,
    marginLeft: spacing.sm,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 100,
  },
  genreItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  genreIcon: {
    width: 56,
    height: 56,
    borderRadius: borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  genreInfo: {
    flex: 1,
  },
  genreName: {
    ...typography.titleMedium,
    color: colors.text,
    fontWeight: '600',
  },
  trackCount: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  loadingText: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.md,
  },
});
