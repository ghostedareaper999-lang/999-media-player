
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { usePlayer } from '@/contexts/PlayerContext';
import { authenticatedGet } from '@/utils/api';
import { colors, spacing, borderRadius, typography, commonStyles } from '@/styles/commonStyles';

interface HistoryItem {
  id: string;
  track: {
    id: string;
    title?: string;
    artist?: string;
    album?: string;
    artworkUrl?: string;
  };
  playedAt: string;
  duration: number;
  completed: boolean;
}

export default function HistoryScreen() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const { play } = usePlayer();

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      setLoading(true);
      console.log('[History] Loading play history');
      const data = await authenticatedGet<HistoryItem[]>('/api/history');
      console.log('[History] Loaded', data.length, 'history items');
      setHistory(data);
    } catch (error) {
      console.error('[History] Error loading history:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const renderHistoryItem = ({ item }: { item: HistoryItem }) => {
    const displayTitle = item.track.title || 'Unknown Track';
    const displayArtist = item.track.artist || 'Unknown Artist';
    const playedAtText = formatDate(item.playedAt);

    return (
      <TouchableOpacity
        style={styles.historyItem}
        onPress={() => {
          console.log('[History] Playing track from history:', displayTitle);
          play(item.track as any);
        }}
      >
        <View style={styles.trackArtwork}>
          {item.track.artworkUrl ? (
            <Image source={{ uri: item.track.artworkUrl }} style={styles.artworkImage} />
          ) : (
            <View style={styles.placeholderArtwork}>
              <IconSymbol
                ios_icon_name="music.note"
                android_material_icon_name="music-note"
                size={20}
                color={colors.textSecondary}
              />
            </View>
          )}
        </View>
        <View style={styles.trackInfo}>
          <Text style={styles.trackTitle}>{displayTitle}</Text>
          <Text style={styles.trackArtist}>{displayArtist}</Text>
          <Text style={styles.playedAt}>{playedAtText}</Text>
        </View>
        <IconSymbol
          ios_icon_name="play.circle"
          android_material_icon_name="play-circle-outline"
          size={24}
          color={colors.primary}
        />
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={commonStyles.safeArea}>
        <Stack.Screen
          options={{
            headerShown: true,
            title: 'History',
            headerStyle: { backgroundColor: colors.background },
            headerTintColor: colors.text,
            headerBackTitle: 'Back',
          }}
        />
        <View style={commonStyles.centerContent}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Loading history...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={commonStyles.safeArea}>
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'History',
          headerStyle: { backgroundColor: colors.background },
          headerTintColor: colors.text,
          headerBackTitle: 'Back',
        }}
      />
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.historyCount}>
            {history.length} {history.length === 1 ? 'track' : 'tracks'} played
          </Text>
        </View>

        {history.length === 0 ? (
          <View style={styles.emptyState}>
            <IconSymbol
              ios_icon_name="clock"
              android_material_icon_name="history"
              size={64}
              color={colors.textSecondary}
            />
            <Text style={styles.emptyTitle}>No history yet</Text>
            <Text style={styles.emptySubtitle}>
              Your listening history will appear here
            </Text>
          </View>
        ) : (
          <FlatList
            data={history}
            renderItem={renderHistoryItem}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  historyCount: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 100,
  },
  historyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  trackArtwork: {
    width: 48,
    height: 48,
    borderRadius: borderRadius.sm,
    marginRight: spacing.md,
    overflow: 'hidden',
  },
  artworkImage: {
    width: '100%',
    height: '100%',
  },
  placeholderArtwork: {
    width: '100%',
    height: '100%',
    backgroundColor: colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackInfo: {
    flex: 1,
  },
  trackTitle: {
    ...typography.titleSmall,
    color: colors.text,
    fontWeight: '600',
  },
  trackArtist: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  playedAt: {
    ...typography.labelSmall,
    color: colors.textTertiary,
    marginTop: spacing.xs,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
  },
  emptyTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '600',
    marginTop: spacing.lg,
  },
  emptySubtitle: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.sm,
  },
  loadingText: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginTop: spacing.md,
  },
});
