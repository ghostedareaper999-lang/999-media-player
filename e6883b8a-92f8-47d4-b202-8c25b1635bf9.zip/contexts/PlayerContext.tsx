
import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import { useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { MediaTrack } from '@/types/media';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authenticatedPost, authenticatedDelete } from '@/utils/api';

interface PlayerContextType {
  currentTrack: MediaTrack | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  playbackRate: number;
  isLooping: boolean;
  isShuffle: boolean;
  queue: MediaTrack[];
  currentIndex: number;
  play: (track: MediaTrack) => void;
  pause: () => void;
  resume: () => void;
  stop: () => void;
  seekTo: (seconds: number) => void;
  setVolume: (volume: number) => void;
  setPlaybackRate: (rate: number) => void;
  toggleLoop: () => void;
  toggleShuffle: () => void;
  next: () => void;
  previous: () => void;
  addToQueue: (track: MediaTrack) => void;
  setQueue: (tracks: MediaTrack[], startIndex?: number) => void;
  clearQueue: () => void;
}

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

export function PlayerProvider({ children }: { children: ReactNode }) {
  const [currentTrack, setCurrentTrack] = useState<MediaTrack | null>(null);
  const [queue, setQueueState] = useState<MediaTrack[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [volume, setVolumeState] = useState(1.0);
  const [playbackRate, setPlaybackRateState] = useState(1.0);
  const [isLooping, setIsLooping] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  
  const player = useAudioPlayer(currentTrack?.filePath || null);
  const status = useAudioPlayerStatus(player);

  const isPlaying = status.playing || false;
  const currentTime = status.currentTime || 0;
  const duration = status.duration || 0;

  // Load saved queue and position on mount
  useEffect(() => {
    loadSavedState();
  }, []);

  // Save queue and position when they change
  useEffect(() => {
    saveState();
  }, [queue, currentIndex, currentTrack]);

  // Auto-play next track when current finishes
  useEffect(() => {
    if (status.isLoaded && !status.playing && currentTime > 0 && duration > 0) {
      const isFinished = Math.abs(currentTime - duration) < 1;
      if (isFinished) {
        console.log('Track finished, playing next');
        if (isLooping) {
          player.seekTo(0);
          player.play();
        } else {
          next();
        }
      }
    }
  }, [status.playing, currentTime, duration, isLooping]);

  const loadSavedState = async () => {
    try {
      const savedQueue = await AsyncStorage.getItem('player_queue');
      const savedIndex = await AsyncStorage.getItem('player_index');
      const savedTrack = await AsyncStorage.getItem('player_current_track');
      
      if (savedQueue) {
        const parsedQueue = JSON.parse(savedQueue);
        setQueueState(parsedQueue);
      }
      
      if (savedIndex) {
        setCurrentIndex(parseInt(savedIndex, 10));
      }
      
      if (savedTrack) {
        setCurrentTrack(JSON.parse(savedTrack));
      }
      
      console.log('Loaded saved player state');
    } catch (error) {
      console.error('Error loading saved player state:', error);
    }
  };

  const saveState = async () => {
    try {
      await AsyncStorage.setItem('player_queue', JSON.stringify(queue));
      await AsyncStorage.setItem('player_index', currentIndex.toString());
      if (currentTrack) {
        await AsyncStorage.setItem('player_current_track', JSON.stringify(currentTrack));
      }
    } catch (error) {
      console.error('Error saving player state:', error);
    }
  };

  const play = (track: MediaTrack) => {
    console.log('Playing track:', track.title || track.fileName);
    setCurrentTrack(track);
    player.replace(track.filePath);
    player.play();

    // Record play history
    authenticatedPost('/api/history', { trackId: track.id, duration: 0, completed: false })
      .then(() => console.log('[API] Play history recorded for:', track.id))
      .catch((err) => console.error('[API] Failed to record play history:', err));
  };

  const pause = () => {
    console.log('Pausing playback');
    player.pause();
  };

  const resume = () => {
    console.log('Resuming playback');
    player.play();
  };

  const stop = () => {
    console.log('Stopping playback');
    player.pause();
    player.seekTo(0);
  };

  const seekTo = (seconds: number) => {
    console.log('Seeking to:', seconds);
    player.seekTo(seconds);
  };

  const setVolume = (newVolume: number) => {
    console.log('Setting volume:', newVolume);
    setVolumeState(newVolume);
    player.volume = newVolume;
  };

  const setPlaybackRate = (rate: number) => {
    console.log('Setting playback rate:', rate);
    setPlaybackRateState(rate);
    player.setPlaybackRate(rate, 'high');
  };

  const toggleLoop = () => {
    const newLooping = !isLooping;
    console.log('Toggle loop:', newLooping);
    setIsLooping(newLooping);
    player.loop = newLooping;
  };

  const toggleShuffle = () => {
    const newShuffle = !isShuffle;
    console.log('Toggle shuffle:', newShuffle);
    setIsShuffle(newShuffle);
  };

  const next = () => {
    console.log('Playing next track');
    if (queue.length === 0) return;
    
    let nextIndex = currentIndex + 1;
    if (nextIndex >= queue.length) {
      nextIndex = 0;
    }
    
    setCurrentIndex(nextIndex);
    play(queue[nextIndex]);
  };

  const previous = () => {
    console.log('Playing previous track');
    if (queue.length === 0) return;
    
    // If more than 3 seconds into the track, restart it
    if (currentTime > 3) {
      seekTo(0);
      return;
    }
    
    let prevIndex = currentIndex - 1;
    if (prevIndex < 0) {
      prevIndex = queue.length - 1;
    }
    
    setCurrentIndex(prevIndex);
    play(queue[prevIndex]);
  };

  const addToQueue = (track: MediaTrack) => {
    console.log('Adding to queue:', track.title || track.fileName);
    const newQueue = [...queue, track];
    setQueueState(newQueue);

    // Sync to backend queue
    authenticatedPost('/api/queue', { trackId: track.id, position: newQueue.length - 1 })
      .then(() => console.log('[API] Track added to backend queue:', track.id))
      .catch((err) => console.error('[API] Failed to add track to backend queue:', err));
  };

  const setQueue = (tracks: MediaTrack[], startIndex: number = 0) => {
    console.log('Setting queue with', tracks.length, 'tracks, starting at index', startIndex);
    setQueueState(tracks);
    setCurrentIndex(startIndex);
    if (tracks.length > 0) {
      play(tracks[startIndex]);
    }
  };

  const clearQueue = () => {
    console.log('Clearing queue');
    setQueueState([]);
    setCurrentIndex(0);
    stop();

    // Clear backend queue
    authenticatedDelete('/api/queue')
      .then(() => console.log('[API] Backend queue cleared'))
      .catch((err) => console.error('[API] Failed to clear backend queue:', err));
  };

  const value: PlayerContextType = {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    playbackRate,
    isLooping,
    isShuffle,
    queue,
    currentIndex,
    play,
    pause,
    resume,
    stop,
    seekTo,
    setVolume,
    setPlaybackRate,
    toggleLoop,
    toggleShuffle,
    next,
    previous,
    addToQueue,
    setQueue,
    clearQueue,
  };

  return <PlayerContext.Provider value={value}>{children}</PlayerContext.Provider>;
}

export function usePlayer() {
  const context = useContext(PlayerContext);
  if (context === undefined) {
    throw new Error('usePlayer must be used within a PlayerProvider');
  }
  return context;
}
