import { describe, test, expect } from "bun:test";
import { api, authenticatedApi, signUpTestUser, expectStatus, connectWebSocket, connectAuthenticatedWebSocket, waitForMessage } from "./helpers";

describe("API Integration Tests", () => {
  let authToken: string;
  let userId: string;
  let trackId: string;
  let playlistId: string;
  let historyId: string;
  let queueId: string;

  // ============================================================================
  // Authentication Setup
  // ============================================================================

  test("Sign up test user", async () => {
    const { token, user } = await signUpTestUser();
    authToken = token;
    userId = user.id;
    expect(authToken).toBeDefined();
    expect(userId).toBeDefined();
  });

  // ============================================================================
  // Tracks Tests
  // ============================================================================

  describe("Tracks", () => {
    test("GET /api/tracks - should return empty array initially", async () => {
      const res = await authenticatedApi("/api/tracks", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
    });

    test("POST /api/tracks - should create a track with required fields", async () => {
      const res = await authenticatedApi("/api/tracks", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: "/music/test.mp3",
          fileName: "test.mp3",
          title: "Test Song",
          artist: "Test Artist",
          album: "Test Album",
          genre: "Rock",
          duration: 180,
          fileSize: 5000000,
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      trackId = data.id;
      expect(data.id).toBeDefined();
      expect(data.title).toBe("Test Song");
      expect(data.userId).toBe(userId);
    });

    test("POST /api/tracks - should fail without required fields", async () => {
      const res = await authenticatedApi("/api/tracks", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: "No Path" }),
      });
      await expectStatus(res, 400);
    });

    test("GET /api/tracks/{id} - should return the created track", async () => {
      const res = await authenticatedApi(`/api/tracks/${trackId}`, authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.id).toBe(trackId);
      expect(data.title).toBe("Test Song");
    });

    test("GET /api/tracks/{id} - should return 404 for nonexistent track", async () => {
      const res = await authenticatedApi("/api/tracks/00000000-0000-0000-0000-000000000000", authToken);
      await expectStatus(res, 404);
    });

    test("PUT /api/tracks/{id} - should update track metadata", async () => {
      const res = await authenticatedApi(`/api/tracks/${trackId}`, authToken, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: "Updated Song",
          artist: "Updated Artist",
          year: 2023,
        }),
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.title).toBe("Updated Song");
      expect(data.artist).toBe("Updated Artist");
      expect(data.year).toBe(2023);
    });

    test("PUT /api/tracks/{id} - should return 404 for nonexistent track", async () => {
      const res = await authenticatedApi("/api/tracks/00000000-0000-0000-0000-000000000000", authToken, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: "Updated" }),
      });
      await expectStatus(res, 404);
    });

    test("GET /api/tracks - should return the created track in list", async () => {
      const res = await authenticatedApi("/api/tracks", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
      const found = data.find((t: any) => t.id === trackId);
      expect(found).toBeDefined();
    });

    test("GET /api/tracks/search - should find track by query", async () => {
      const res = await authenticatedApi("/api/tracks/search?q=Updated", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
      const found = data.find((t: any) => t.id === trackId);
      expect(found).toBeDefined();
    });

    test("GET /api/tracks/search - should return empty array for no matches", async () => {
      const res = await authenticatedApi("/api/tracks/search?q=nonexistent-xyz", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
    });

    test("GET /api/tracks/albums - should return albums with track count", async () => {
      const res = await authenticatedApi("/api/tracks/albums", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
      if (data.length > 0) {
        expect(data[0].album).toBeDefined();
        expect(data[0].trackCount).toBeDefined();
      }
    });

    test("GET /api/tracks/artists - should return artists with track count", async () => {
      const res = await authenticatedApi("/api/tracks/artists", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
      if (data.length > 0) {
        expect(data[0].artist).toBeDefined();
        expect(data[0].trackCount).toBeDefined();
      }
    });

    test("GET /api/tracks/genres - should return genres with track count", async () => {
      const res = await authenticatedApi("/api/tracks/genres", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
      if (data.length > 0) {
        expect(data[0].genre).toBeDefined();
        expect(data[0].trackCount).toBeDefined();
      }
    });

    test("DELETE /api/tracks/{id} - should delete the track", async () => {
      const res = await authenticatedApi(`/api/tracks/${trackId}`, authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    });

    test("GET /api/tracks/{id} - should return 404 after deletion", async () => {
      const res = await authenticatedApi(`/api/tracks/${trackId}`, authToken);
      await expectStatus(res, 404);
    });

    test("DELETE /api/tracks/{id} - should return 404 for nonexistent track", async () => {
      const res = await authenticatedApi("/api/tracks/00000000-0000-0000-0000-000000000000", authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 404);
    });
  });

  // ============================================================================
  // Playlists Tests
  // ============================================================================

  describe("Playlists", () => {
    let playlistTrackId: string;

    test("Create a track for playlist testing", async () => {
      const res = await authenticatedApi("/api/tracks", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: "/music/playlist-test.mp3",
          fileName: "playlist-test.mp3",
          title: "Playlist Test Track",
          artist: "Test Artist",
          duration: 200,
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      playlistTrackId = data.id;
    });

    test("GET /api/playlists - should return empty array initially", async () => {
      const res = await authenticatedApi("/api/playlists", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
    });

    test("POST /api/playlists - should create a playlist", async () => {
      const res = await authenticatedApi("/api/playlists", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: "My Playlist",
          description: "A test playlist",
          artworkUrl: "http://example.com/artwork.png",
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      playlistId = data.id;
      expect(data.name).toBe("My Playlist");
      expect(data.userId).toBe(userId);
      expect(data.trackCount).toBe(0);
    });

    test("POST /api/playlists - should fail without name", async () => {
      const res = await authenticatedApi("/api/playlists", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ description: "No name" }),
      });
      await expectStatus(res, 400);
    });

    test("GET /api/playlists/{id} - should return the playlist with empty tracks", async () => {
      const res = await authenticatedApi(`/api/playlists/${playlistId}`, authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.id).toBe(playlistId);
      expect(data.name).toBe("My Playlist");
      expect(Array.isArray(data.tracks)).toBe(true);
    });

    test("GET /api/playlists/{id} - should return 404 for nonexistent playlist", async () => {
      const res = await authenticatedApi("/api/playlists/00000000-0000-0000-0000-000000000000", authToken);
      await expectStatus(res, 404);
    });

    test("POST /api/playlists/{id}/tracks - should add a track to playlist", async () => {
      const res = await authenticatedApi(`/api/playlists/${playlistId}/tracks`, authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId: playlistTrackId,
          position: 0,
        }),
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.id).toBe(playlistId);
      expect(data.trackCount).toBe(1);
    });

    test("GET /api/playlists/{id} - should show track in playlist", async () => {
      const res = await authenticatedApi(`/api/playlists/${playlistId}`, authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.trackCount).toBe(1);
      expect(Array.isArray(data.tracks)).toBe(true);
      expect(data.tracks.length).toBe(1);
    });

    test("PUT /api/playlists/{id}/reorder - should reorder tracks", async () => {
      const res = await authenticatedApi(`/api/playlists/${playlistId}/reorder`, authToken, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId: playlistTrackId,
          newPosition: 0,
        }),
      });
      await expectStatus(res, 200);
    });

    test("DELETE /api/playlists/{id}/tracks/{trackId} - should remove track from playlist", async () => {
      const res = await authenticatedApi(`/api/playlists/${playlistId}/tracks/${playlistTrackId}`, authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    });

    test("GET /api/playlists/{id} - should show empty tracks after removal", async () => {
      const res = await authenticatedApi(`/api/playlists/${playlistId}`, authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.trackCount).toBe(0);
    });

    test("PUT /api/playlists/{id} - should update playlist", async () => {
      const res = await authenticatedApi(`/api/playlists/${playlistId}`, authToken, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: "Updated Playlist",
          description: "Updated description",
        }),
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.name).toBe("Updated Playlist");
      expect(data.description).toBe("Updated description");
    });

    test("PUT /api/playlists/{id} - should return 404 for nonexistent playlist", async () => {
      const res = await authenticatedApi("/api/playlists/00000000-0000-0000-0000-000000000000", authToken, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: "Updated" }),
      });
      await expectStatus(res, 404);
    });

    test("GET /api/playlists - should return the created playlist", async () => {
      const res = await authenticatedApi("/api/playlists", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      const found = data.find((p: any) => p.id === playlistId);
      expect(found).toBeDefined();
    });

    test("DELETE /api/playlists/{id} - should delete the playlist", async () => {
      const res = await authenticatedApi(`/api/playlists/${playlistId}`, authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    });

    test("GET /api/playlists/{id} - should return 404 after deletion", async () => {
      const res = await authenticatedApi(`/api/playlists/${playlistId}`, authToken);
      await expectStatus(res, 404);
    });

    test("DELETE /api/playlists/{id} - should return 404 for nonexistent playlist", async () => {
      const res = await authenticatedApi("/api/playlists/00000000-0000-0000-0000-000000000000", authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 404);
    });
  });

  // ============================================================================
  // History Tests
  // ============================================================================

  describe("History", () => {
    let historyTrackId: string;

    test("Create a track for history testing", async () => {
      const res = await authenticatedApi("/api/tracks", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: "/music/history-test.mp3",
          fileName: "history-test.mp3",
          title: "History Test Track",
          artist: "Test Artist",
          duration: 150,
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      historyTrackId = data.id;
    });

    test("GET /api/history - should return empty array initially", async () => {
      const res = await authenticatedApi("/api/history", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
    });

    test("POST /api/history - should record a track play", async () => {
      const res = await authenticatedApi("/api/history", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId: historyTrackId,
          duration: 150,
          completed: true,
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      historyId = data.id;
      expect(data.trackId).toBe(historyTrackId);
      expect(data.userId).toBe(userId);
      expect(data.completed).toBe(true);
    });

    test("POST /api/history - should fail without required fields", async () => {
      const res = await authenticatedApi("/api/history", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId: historyTrackId,
          // missing 'completed'
        }),
      });
      await expectStatus(res, 400);
    });

    test("GET /api/history - should return recorded play in history", async () => {
      const res = await authenticatedApi("/api/history", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      const found = data.find((h: any) => h.id === historyId);
      expect(found).toBeDefined();
      expect(found.track).toBeDefined();
    });

    test("GET /api/history/most-played - should return most played tracks", async () => {
      const res = await authenticatedApi("/api/history/most-played", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
    });

    test("DELETE /api/history/{id} - should delete a history entry", async () => {
      const res = await authenticatedApi(`/api/history/${historyId}`, authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    });

    test("GET /api/history - should not show deleted entry", async () => {
      const res = await authenticatedApi("/api/history", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      const found = data.find((h: any) => h.id === historyId);
      expect(found).toBeUndefined();
    });

    test("DELETE /api/history/{id} - should return 404 for nonexistent entry", async () => {
      const res = await authenticatedApi("/api/history/00000000-0000-0000-0000-000000000000", authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 404);
    });
  });

  // ============================================================================
  // Queue Tests
  // ============================================================================

  describe("Queue", () => {
    let queueTrackId1: string;
    let queueTrackId2: string;
    let queueItemId: string;

    test("Create first track for queue testing", async () => {
      const res = await authenticatedApi("/api/tracks", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: "/music/queue-test-1.mp3",
          fileName: "queue-test-1.mp3",
          title: "Queue Test Track 1",
          artist: "Test Artist",
          duration: 180,
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      queueTrackId1 = data.id;
    });

    test("Create second track for queue testing", async () => {
      const res = await authenticatedApi("/api/tracks", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: "/music/queue-test-2.mp3",
          fileName: "queue-test-2.mp3",
          title: "Queue Test Track 2",
          artist: "Test Artist",
          duration: 200,
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      queueTrackId2 = data.id;
    });

    test("GET /api/queue - should return empty queue initially", async () => {
      const res = await authenticatedApi("/api/queue", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
    });

    test("POST /api/queue - should add a track to queue", async () => {
      const res = await authenticatedApi("/api/queue", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId: queueTrackId1,
          position: 0,
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
      expect(data.length).toBeGreaterThan(0);
      queueItemId = data[0].id;
    });

    test("POST /api/queue - should add second track to queue", async () => {
      const res = await authenticatedApi("/api/queue", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId: queueTrackId2,
          position: 1,
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      expect(data.length).toBe(2);
    });

    test("GET /api/queue - should return queued tracks", async () => {
      const res = await authenticatedApi("/api/queue", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.length).toBe(2);
      expect(data[0].track).toBeDefined();
    });

    test("PUT /api/queue/reorder - should reorder tracks in queue", async () => {
      const res = await authenticatedApi("/api/queue/reorder", authToken, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId: queueTrackId1,
          newPosition: 1,
        }),
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
    });

    test("DELETE /api/queue/{id} - should remove a track from queue", async () => {
      const res = await authenticatedApi(`/api/queue/${queueItemId}`, authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    });

    test("GET /api/queue - should show reduced queue after removal", async () => {
      const res = await authenticatedApi("/api/queue", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.length).toBe(1);
    });

    test("DELETE /api/queue - should clear entire queue", async () => {
      const res = await authenticatedApi("/api/queue", authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    });

    test("GET /api/queue - should return empty array after clear", async () => {
      const res = await authenticatedApi("/api/queue", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
      expect(data.length).toBe(0);
    });

    test("DELETE /api/queue/{id} - should return 404 for nonexistent queue item", async () => {
      const res = await authenticatedApi("/api/queue/00000000-0000-0000-0000-000000000000", authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 404);
    });
  });

  // ============================================================================
  // YT-DLP Tests
  // ============================================================================

  describe("YT-DLP", () => {
    let downloadId: string;

    test("POST /api/yt-dlp/metadata - should extract video metadata", async () => {
      const res = await authenticatedApi("/api/yt-dlp/metadata", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        }),
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.title).toBeDefined();
      expect(data.duration).toBeDefined();
    });

    test("POST /api/yt-dlp/metadata - should fail without url", async () => {
      const res = await authenticatedApi("/api/yt-dlp/metadata", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      await expectStatus(res, 400);
    });

    test("POST /api/yt-dlp/metadata - should return 400 for invalid url", async () => {
      const res = await authenticatedApi("/api/yt-dlp/metadata", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: "not-a-valid-url",
        }),
      });
      await expectStatus(res, 400);
    });

    test("POST /api/yt-dlp/download - should initiate a download", async () => {
      const res = await authenticatedApi("/api/yt-dlp/download", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
          format: "audio",
          quality: "best",
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      downloadId = data.downloadId;
      expect(data.downloadId).toBeDefined();
      expect(data.status).toBeDefined();
    });

    test("POST /api/yt-dlp/download - should fail without required fields", async () => {
      const res = await authenticatedApi("/api/yt-dlp/download", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        }),
      });
      await expectStatus(res, 400);
    });

    test("POST /api/yt-dlp/download - should fail with invalid format", async () => {
      const res = await authenticatedApi("/api/yt-dlp/download", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
          format: "invalid-format",
        }),
      });
      await expectStatus(res, 400);
    });

    test("GET /api/yt-dlp/downloads - should return list of downloads", async () => {
      const res = await authenticatedApi("/api/yt-dlp/downloads", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
    });

    test("GET /api/yt-dlp/download/{id} - should return download details", async () => {
      if (!downloadId) {
        // Skip if no download was created
        return;
      }
      const res = await authenticatedApi(`/api/yt-dlp/download/${downloadId}`, authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.id).toBe(downloadId);
      expect(data.status).toBeDefined();
    });

    test("GET /api/yt-dlp/download/{id} - should return 404 for nonexistent download", async () => {
      const res = await authenticatedApi("/api/yt-dlp/download/00000000-0000-0000-0000-000000000000", authToken);
      await expectStatus(res, 404);
    });

    test("GET /api/yt-dlp/download/{id}/status - should return download status", async () => {
      if (!downloadId) {
        // Skip if no download was created
        return;
      }
      const res = await authenticatedApi(`/api/yt-dlp/download/${downloadId}/status`, authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.id).toBe(downloadId);
      expect(data.status).toBeDefined();
      expect(data.progress).toBeDefined();
    });

    test("GET /api/yt-dlp/download/{id}/status - should return 404 for nonexistent download", async () => {
      const res = await authenticatedApi("/api/yt-dlp/download/00000000-0000-0000-0000-000000000000/status", authToken);
      await expectStatus(res, 404);
    });

    test("DELETE /api/yt-dlp/download/{id} - should delete a download", async () => {
      if (!downloadId) {
        // Skip if no download was created
        return;
      }
      const res = await authenticatedApi(`/api/yt-dlp/download/${downloadId}`, authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    });

    test("GET /api/yt-dlp/download/{id} - should return 404 after deletion", async () => {
      if (!downloadId) {
        // Skip if no download was created
        return;
      }
      const res = await authenticatedApi(`/api/yt-dlp/download/${downloadId}`, authToken);
      await expectStatus(res, 404);
    });

    test("DELETE /api/yt-dlp/download/{id} - should return 404 for nonexistent download", async () => {
      const res = await authenticatedApi("/api/yt-dlp/download/00000000-0000-0000-0000-000000000000", authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 404);
    });
  });

  // ============================================================================
  // YTDLP Downloads Tests
  // ============================================================================

  describe("YTDLP Downloads", () => {
    let ytdlpDownloadId: string;

    test("POST /api/ytdlp/downloads - should initiate a new download", async () => {
      const res = await authenticatedApi("/api/ytdlp/downloads", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
          format: "audio",
          quality: "best",
        }),
      });
      await expectStatus(res, 201);
      const data = await res.json();
      ytdlpDownloadId = data.id;
      expect(data.id).toBeDefined();
      expect(data.url).toBe("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
      expect(data.format).toBe("audio");
      expect(data.status).toBeDefined();
      expect(data.userId).toBe(userId);
    });

    test("POST /api/ytdlp/downloads - should fail without required fields", async () => {
      const res = await authenticatedApi("/api/ytdlp/downloads", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
          // missing 'format'
        }),
      });
      await expectStatus(res, 400);
    });

    test("POST /api/ytdlp/downloads - should fail with invalid format", async () => {
      const res = await authenticatedApi("/api/ytdlp/downloads", authToken, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
          format: "invalid-format",
        }),
      });
      await expectStatus(res, 400);
    });

    test("GET /api/ytdlp/downloads - should return list of downloads", async () => {
      const res = await authenticatedApi("/api/ytdlp/downloads", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      expect(Array.isArray(data)).toBe(true);
    });

    test("GET /api/ytdlp/downloads - should include created download in list", async () => {
      if (!ytdlpDownloadId) {
        return;
      }
      const res = await authenticatedApi("/api/ytdlp/downloads", authToken);
      await expectStatus(res, 200);
      const data = await res.json();
      const found = data.find((d: any) => d.id === ytdlpDownloadId);
      expect(found).toBeDefined();
    });

    test("DELETE /api/ytdlp/downloads/{id} - should delete a download", async () => {
      if (!ytdlpDownloadId) {
        return;
      }
      const res = await authenticatedApi(`/api/ytdlp/downloads/${ytdlpDownloadId}`, authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 200);
      const data = await res.json();
      expect(data.success).toBe(true);
    });

    test("DELETE /api/ytdlp/downloads/{id} - should return 404 for nonexistent download", async () => {
      const res = await authenticatedApi("/api/ytdlp/downloads/00000000-0000-0000-0000-000000000000", authToken, {
        method: "DELETE",
      });
      await expectStatus(res, 404);
    });
  });

  // ============================================================================
  // Authentication Tests
  // ============================================================================

  test("Unauthenticated request to /api/tracks should return 401", async () => {
    const res = await api("/api/tracks");
    await expectStatus(res, 401);
  });

  test("Unauthenticated POST to /api/playlists should return 401", async () => {
    const res = await api("/api/playlists", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "Test" }),
    });
    await expectStatus(res, 401);
  });

  test("Unauthenticated GET /api/history should return 401", async () => {
    const res = await api("/api/history");
    await expectStatus(res, 401);
  });

  test("Unauthenticated GET /api/queue should return 401", async () => {
    const res = await api("/api/queue");
    await expectStatus(res, 401);
  });

  test("Unauthenticated POST to /api/yt-dlp/download should return 401", async () => {
    const res = await api("/api/yt-dlp/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        format: "audio",
      }),
    });
    await expectStatus(res, 401);
  });

  test("Unauthenticated GET /api/yt-dlp/downloads should return 401", async () => {
    const res = await api("/api/yt-dlp/downloads");
    await expectStatus(res, 401);
  });

  test("Unauthenticated POST to /api/ytdlp/downloads should return 401", async () => {
    const res = await api("/api/ytdlp/downloads", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        format: "audio",
      }),
    });
    await expectStatus(res, 401);
  });

  test("Unauthenticated GET /api/ytdlp/downloads should return 401", async () => {
    const res = await api("/api/ytdlp/downloads");
    await expectStatus(res, 401);
  });
});
