import { pgTable, text, uuid, timestamp, integer, boolean, index, bigint, jsonb } from 'drizzle-orm/pg-core';

// Media tracks table
export const mediaTracks = pgTable('media_tracks', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  filePath: text('file_path').notNull(),
  fileName: text('file_name').notNull(),
  title: text('title'),
  artist: text('artist'),
  album: text('album'),
  genre: text('genre'),
  duration: integer('duration'), // seconds
  fileSize: integer('file_size'), // bytes
  mimeType: text('mime_type'),
  artworkUrl: text('artwork_url'),
  lyrics: text('lyrics'),
  year: integer('year'),
  trackNumber: integer('track_number'),
  bitrate: integer('bitrate'),
  sampleRate: integer('sample_rate'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index('media_tracks_user_id_idx').on(table.userId),
  filePathIdx: index('media_tracks_file_path_idx').on(table.filePath),
}));

// Playlists table
export const playlists = pgTable('playlists', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  name: text('name').notNull(),
  description: text('description'),
  artworkUrl: text('artwork_url'),
  trackCount: integer('track_count').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index('playlists_user_id_idx').on(table.userId),
}));

// Playlist tracks junction table
export const playlistTracks = pgTable('playlist_tracks', {
  id: uuid('id').primaryKey().defaultRandom(),
  playlistId: uuid('playlist_id').notNull().references(() => playlists.id, { onDelete: 'cascade' }),
  trackId: uuid('track_id').notNull().references(() => mediaTracks.id, { onDelete: 'cascade' }),
  position: integer('position').notNull(),
  addedAt: timestamp('added_at', { withTimezone: true }).notNull().defaultNow(),
});

// Play history table
export const playHistory = pgTable('play_history', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  trackId: uuid('track_id').notNull().references(() => mediaTracks.id, { onDelete: 'cascade' }),
  playedAt: timestamp('played_at', { withTimezone: true }).notNull(),
  duration: integer('duration'), // seconds played
  completed: boolean('completed').notNull().default(false),
}, (table) => ({
  userIdIdx: index('play_history_user_id_idx').on(table.userId),
}));

// Queue table
export const queue = pgTable('queue', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  trackId: uuid('track_id').notNull().references(() => mediaTracks.id, { onDelete: 'cascade' }),
  position: integer('position').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index('queue_user_id_idx').on(table.userId),
}));

// Downloads table
export const downloads = pgTable('downloads', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').notNull(),
  url: text('url').notNull(),
  title: text('title'),
  format: text('format').notNull(), // 'video' | 'audio'
  quality: text('quality'),
  status: text('status').notNull().default('pending'), // 'pending' | 'downloading' | 'processing' | 'completed' | 'failed'
  progress: integer('progress').notNull().default(0), // 0-100
  outputPath: text('output_path'),
  fileSize: bigint('file_size', { mode: 'number' }),
  metadata: jsonb('metadata'),
  errorMessage: text('error_message'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index('downloads_user_id_idx').on(table.userId),
  statusIdx: index('downloads_status_idx').on(table.status),
}));
