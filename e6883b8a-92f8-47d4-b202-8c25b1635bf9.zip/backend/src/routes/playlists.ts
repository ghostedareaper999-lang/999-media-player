import type { App } from '../index.js';
import type { FastifyRequest, FastifyReply } from 'fastify';
import { eq, and, desc } from 'drizzle-orm';
import { playlists, playlistTracks, mediaTracks } from '../db/schema/schema.js';

interface CreatePlaylistBody {
  name: string;
  description?: string;
  artworkUrl?: string;
}

interface UpdatePlaylistBody {
  name?: string;
  description?: string;
  artworkUrl?: string;
}

interface AddTrackBody {
  trackId: string;
  position?: number;
}

interface ReorderBody {
  trackId: string;
  newPosition: number;
}

export function registerPlaylistRoutes(app: App) {
  const requireAuth = app.requireAuth();

  // GET /api/playlists - Get all playlists for user
  app.fastify.get('/api/playlists', {
    schema: {
      description: 'Get all playlists for the current user',
      tags: ['playlists'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              userId: { type: 'string' },
              name: { type: 'string' },
              description: { type: 'string' },
              artworkUrl: { type: 'string' },
              trackCount: { type: 'integer' },
              createdAt: { type: 'string', format: 'date-time' },
              updatedAt: { type: 'string', format: 'date-time' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching all playlists');
    const userPlaylists = await app.db.select().from(playlists).where(eq(playlists.userId, session.user.id));
    app.logger.info({ userId: session.user.id, count: userPlaylists.length }, 'Playlists retrieved');
    return userPlaylists;
  });

  // POST /api/playlists - Create new playlist
  app.fastify.post('/api/playlists', {
    schema: {
      description: 'Create a new playlist',
      tags: ['playlists'],
      body: {
        type: 'object',
        required: ['name'],
        properties: {
          name: { type: 'string' },
          description: { type: 'string' },
          artworkUrl: { type: 'string' },
        },
      },
      response: {
        201: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            name: { type: 'string' },
            description: { type: 'string' },
            artworkUrl: { type: 'string' },
            trackCount: { type: 'integer' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
          },
        },
        400: { type: 'object', properties: { error: { type: 'string' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Body: CreatePlaylistBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id, name: request.body.name }, 'Creating playlist');
    const playlist = await app.db.insert(playlists).values({
      userId: session.user.id,
      ...request.body,
    }).returning();

    app.logger.info({ userId: session.user.id, playlistId: playlist[0].id }, 'Playlist created successfully');
    reply.statusCode = 201;
    return playlist[0];
  });

  // GET /api/playlists/:id - Get playlist with tracks
  app.fastify.get('/api/playlists/:id', {
    schema: {
      description: 'Get a playlist with its tracks',
      tags: ['playlists'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            name: { type: 'string' },
            description: { type: 'string' },
            artworkUrl: { type: 'string' },
            trackCount: { type: 'integer' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
            tracks: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  id: { type: 'string' },
                  title: { type: 'string' },
                  artist: { type: 'string' },
                  album: { type: 'string' },
                  duration: { type: 'integer' },
                  artworkUrl: { type: 'string' },
                  position: { type: 'integer' },
                },
              },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ playlistId: request.params.id }, 'Fetching playlist');
    const playlist = await app.db.select().from(playlists).where(eq(playlists.id, request.params.id));

    if (playlist.length === 0) {
      app.logger.warn({ playlistId: request.params.id }, 'Playlist not found');
      reply.statusCode = 404;
      return { error: 'Playlist not found' };
    }

    const tracks = await app.db.select({
      id: mediaTracks.id,
      title: mediaTracks.title,
      artist: mediaTracks.artist,
      album: mediaTracks.album,
      duration: mediaTracks.duration,
      artworkUrl: mediaTracks.artworkUrl,
      position: playlistTracks.position,
    }).from(playlistTracks)
      .innerJoin(mediaTracks, eq(playlistTracks.trackId, mediaTracks.id))
      .where(eq(playlistTracks.playlistId, request.params.id))
      .orderBy(playlistTracks.position);

    app.logger.info({ playlistId: request.params.id, trackCount: tracks.length }, 'Playlist retrieved');
    return { ...playlist[0], tracks };
  });

  // PUT /api/playlists/:id - Update playlist
  app.fastify.put('/api/playlists/:id', {
    schema: {
      description: 'Update a playlist',
      tags: ['playlists'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      body: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          description: { type: 'string' },
          artworkUrl: { type: 'string' },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            name: { type: 'string' },
            description: { type: 'string' },
            artworkUrl: { type: 'string' },
            trackCount: { type: 'integer' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        403: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string }, Body: UpdatePlaylistBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ playlistId: request.params.id, userId: session.user.id }, 'Updating playlist');
    const playlist = await app.db.select().from(playlists).where(eq(playlists.id, request.params.id));

    if (playlist.length === 0) {
      app.logger.warn({ playlistId: request.params.id }, 'Playlist not found');
      reply.statusCode = 404;
      return { error: 'Playlist not found' };
    }

    if (playlist[0].userId !== session.user.id) {
      app.logger.warn({ playlistId: request.params.id, userId: session.user.id }, 'User does not own playlist');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    const updated = await app.db.update(playlists).set({
      ...request.body,
      updatedAt: new Date(),
    }).where(eq(playlists.id, request.params.id)).returning();

    app.logger.info({ playlistId: request.params.id }, 'Playlist updated successfully');
    return updated[0];
  });

  // DELETE /api/playlists/:id - Delete playlist
  app.fastify.delete('/api/playlists/:id', {
    schema: {
      description: 'Delete a playlist',
      tags: ['playlists'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: { type: 'object', properties: { success: { type: 'boolean' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        403: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ playlistId: request.params.id, userId: session.user.id }, 'Deleting playlist');
    const playlist = await app.db.select().from(playlists).where(eq(playlists.id, request.params.id));

    if (playlist.length === 0) {
      app.logger.warn({ playlistId: request.params.id }, 'Playlist not found');
      reply.statusCode = 404;
      return { error: 'Playlist not found' };
    }

    if (playlist[0].userId !== session.user.id) {
      app.logger.warn({ playlistId: request.params.id, userId: session.user.id }, 'User does not own playlist');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    await app.db.delete(playlists).where(eq(playlists.id, request.params.id));
    app.logger.info({ playlistId: request.params.id }, 'Playlist deleted successfully');
    return { success: true };
  });

  // POST /api/playlists/:id/tracks - Add track to playlist
  app.fastify.post('/api/playlists/:id/tracks', {
    schema: {
      description: 'Add a track to a playlist',
      tags: ['playlists'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      body: {
        type: 'object',
        required: ['trackId'],
        properties: {
          trackId: { type: 'string', format: 'uuid' },
          position: { type: 'integer' },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            name: { type: 'string' },
            description: { type: 'string' },
            artworkUrl: { type: 'string' },
            trackCount: { type: 'integer' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
            tracks: { type: 'array' },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string }, Body: AddTrackBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ playlistId: request.params.id, trackId: request.body.trackId }, 'Adding track to playlist');
    const playlist = await app.db.select().from(playlists).where(eq(playlists.id, request.params.id));

    if (playlist.length === 0) {
      app.logger.warn({ playlistId: request.params.id }, 'Playlist not found');
      reply.statusCode = 404;
      return { error: 'Playlist not found' };
    }

    const existingTracks = await app.db.select().from(playlistTracks).where(eq(playlistTracks.playlistId, request.params.id));
    const position = request.body.position ?? existingTracks.length;

    await app.db.insert(playlistTracks).values({
      playlistId: request.params.id,
      trackId: request.body.trackId,
      position,
    });

    // Update playlist trackCount
    const updatedCount = existingTracks.length + 1;
    await app.db.update(playlists).set({
      trackCount: updatedCount,
      updatedAt: new Date(),
    }).where(eq(playlists.id, request.params.id));

    const tracks = await app.db.select({
      id: mediaTracks.id,
      title: mediaTracks.title,
      artist: mediaTracks.artist,
      album: mediaTracks.album,
      duration: mediaTracks.duration,
      artworkUrl: mediaTracks.artworkUrl,
      position: playlistTracks.position,
    }).from(playlistTracks)
      .innerJoin(mediaTracks, eq(playlistTracks.trackId, mediaTracks.id))
      .where(eq(playlistTracks.playlistId, request.params.id))
      .orderBy(playlistTracks.position);

    app.logger.info({ playlistId: request.params.id, trackId: request.body.trackId }, 'Track added successfully');
    return { ...playlist[0], trackCount: updatedCount, tracks };
  });

  // DELETE /api/playlists/:id/tracks/:trackId - Remove track from playlist
  app.fastify.delete('/api/playlists/:id/tracks/:trackId', {
    schema: {
      description: 'Remove a track from a playlist',
      tags: ['playlists'],
      params: {
        type: 'object',
        required: ['id', 'trackId'],
        properties: {
          id: { type: 'string', format: 'uuid' },
          trackId: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: { type: 'object', properties: { success: { type: 'boolean' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        403: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string, trackId: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ playlistId: request.params.id, trackId: request.params.trackId }, 'Removing track from playlist');
    const playlist = await app.db.select().from(playlists).where(eq(playlists.id, request.params.id));

    if (playlist.length === 0) {
      app.logger.warn({ playlistId: request.params.id }, 'Playlist not found');
      reply.statusCode = 404;
      return { error: 'Playlist not found' };
    }

    if (playlist[0].userId !== session.user.id) {
      app.logger.warn({ playlistId: request.params.id, userId: session.user.id }, 'User does not own playlist');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    await app.db.delete(playlistTracks).where(
      and(
        eq(playlistTracks.playlistId, request.params.id),
        eq(playlistTracks.trackId, request.params.trackId)
      )
    );

    // Update trackCount
    const updatedTracks = await app.db.select().from(playlistTracks).where(eq(playlistTracks.playlistId, request.params.id));
    await app.db.update(playlists).set({
      trackCount: updatedTracks.length,
      updatedAt: new Date(),
    }).where(eq(playlists.id, request.params.id));

    app.logger.info({ playlistId: request.params.id, trackId: request.params.trackId }, 'Track removed successfully');
    return { success: true };
  });

  // PUT /api/playlists/:id/reorder - Reorder tracks in playlist
  app.fastify.put('/api/playlists/:id/reorder', {
    schema: {
      description: 'Reorder tracks in a playlist',
      tags: ['playlists'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      body: {
        type: 'object',
        required: ['trackId', 'newPosition'],
        properties: {
          trackId: { type: 'string', format: 'uuid' },
          newPosition: { type: 'integer' },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            name: { type: 'string' },
            description: { type: 'string' },
            artworkUrl: { type: 'string' },
            trackCount: { type: 'integer' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
            tracks: { type: 'array' },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string }, Body: ReorderBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ playlistId: request.params.id, trackId: request.body.trackId, newPosition: request.body.newPosition }, 'Reordering track in playlist');
    const playlist = await app.db.select().from(playlists).where(eq(playlists.id, request.params.id));

    if (playlist.length === 0) {
      app.logger.warn({ playlistId: request.params.id }, 'Playlist not found');
      reply.statusCode = 404;
      return { error: 'Playlist not found' };
    }

    const playlistTracksList = await app.db.select().from(playlistTracks).where(eq(playlistTracks.playlistId, request.params.id)).orderBy(playlistTracks.position);
    const trackIndex = playlistTracksList.findIndex(t => t.trackId === request.body.trackId);

    if (trackIndex === -1) {
      app.logger.warn({ playlistId: request.params.id, trackId: request.body.trackId }, 'Track not found in playlist');
      reply.statusCode = 404;
      return { error: 'Track not found in playlist' };
    }

    const oldPosition = playlistTracksList[trackIndex].position;
    const newPos = request.body.newPosition;

    if (oldPosition < newPos) {
      // Moving down
      for (let i = trackIndex + 1; i < playlistTracksList.length && playlistTracksList[i].position <= newPos; i++) {
        await app.db.update(playlistTracks).set({ position: playlistTracksList[i].position - 1 }).where(eq(playlistTracks.id, playlistTracksList[i].id));
      }
    } else if (oldPosition > newPos) {
      // Moving up
      for (let i = trackIndex - 1; i >= 0 && playlistTracksList[i].position >= newPos; i--) {
        await app.db.update(playlistTracks).set({ position: playlistTracksList[i].position + 1 }).where(eq(playlistTracks.id, playlistTracksList[i].id));
      }
    }

    await app.db.update(playlistTracks).set({ position: newPos }).where(
      and(
        eq(playlistTracks.playlistId, request.params.id),
        eq(playlistTracks.trackId, request.body.trackId)
      )
    );

    await app.db.update(playlists).set({ updatedAt: new Date() }).where(eq(playlists.id, request.params.id));

    const tracks = await app.db.select({
      id: mediaTracks.id,
      title: mediaTracks.title,
      artist: mediaTracks.artist,
      album: mediaTracks.album,
      duration: mediaTracks.duration,
      artworkUrl: mediaTracks.artworkUrl,
      position: playlistTracks.position,
    }).from(playlistTracks)
      .innerJoin(mediaTracks, eq(playlistTracks.trackId, mediaTracks.id))
      .where(eq(playlistTracks.playlistId, request.params.id))
      .orderBy(playlistTracks.position);

    app.logger.info({ playlistId: request.params.id, trackId: request.body.trackId }, 'Track reordered successfully');
    return { ...playlist[0], tracks };
  });
}
