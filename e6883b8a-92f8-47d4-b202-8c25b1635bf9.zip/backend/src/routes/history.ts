import type { App } from '../index.js';
import type { FastifyRequest, FastifyReply } from 'fastify';
import { eq, desc } from 'drizzle-orm';
import { playHistory, mediaTracks } from '../db/schema/schema.js';

interface CreateHistoryBody {
  trackId: string;
  duration?: number;
  completed: boolean;
}

export function registerHistoryRoutes(app: App) {
  const requireAuth = app.requireAuth();

  // GET /api/history - Get play history
  app.fastify.get('/api/history', {
    schema: {
      description: 'Get play history for the current user',
      tags: ['history'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              userId: { type: 'string' },
              trackId: { type: 'string' },
              track: {
                type: 'object',
                properties: {
                  id: { type: 'string' },
                  title: { type: 'string' },
                  artist: { type: 'string' },
                  album: { type: 'string' },
                  artworkUrl: { type: 'string' },
                },
              },
              playedAt: { type: 'string', format: 'date-time' },
              duration: { type: 'integer' },
              completed: { type: 'boolean' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching play history');
    const history = await app.db.select({
      id: playHistory.id,
      userId: playHistory.userId,
      trackId: playHistory.trackId,
      track: {
        id: mediaTracks.id,
        title: mediaTracks.title,
        artist: mediaTracks.artist,
        album: mediaTracks.album,
        artworkUrl: mediaTracks.artworkUrl,
      },
      playedAt: playHistory.playedAt,
      duration: playHistory.duration,
      completed: playHistory.completed,
    }).from(playHistory)
      .innerJoin(mediaTracks, eq(playHistory.trackId, mediaTracks.id))
      .where(eq(playHistory.userId, session.user.id))
      .orderBy(desc(playHistory.playedAt));

    app.logger.info({ userId: session.user.id, count: history.length }, 'Play history retrieved');
    return history;
  });

  // POST /api/history - Record play history
  app.fastify.post('/api/history', {
    schema: {
      description: 'Record a track play in history',
      tags: ['history'],
      body: {
        type: 'object',
        required: ['trackId', 'completed'],
        properties: {
          trackId: { type: 'string', format: 'uuid' },
          duration: { type: 'integer' },
          completed: { type: 'boolean' },
        },
      },
      response: {
        201: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            trackId: { type: 'string' },
            playedAt: { type: 'string', format: 'date-time' },
            duration: { type: 'integer' },
            completed: { type: 'boolean' },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Body: CreateHistoryBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id, trackId: request.body.trackId }, 'Recording play history');
    const entry = await app.db.insert(playHistory).values({
      userId: session.user.id,
      trackId: request.body.trackId,
      playedAt: new Date(),
      duration: request.body.duration,
      completed: request.body.completed,
    }).returning();

    app.logger.info({ userId: session.user.id, trackId: request.body.trackId }, 'Play history recorded');
    reply.statusCode = 201;
    return entry[0];
  });

  // GET /api/history/most-played - Get most played tracks
  app.fastify.get('/api/history/most-played', {
    schema: {
      description: 'Get most played tracks for the current user',
      tags: ['history'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              track: {
                type: 'object',
                properties: {
                  id: { type: 'string' },
                  title: { type: 'string' },
                  artist: { type: 'string' },
                  album: { type: 'string' },
                  artworkUrl: { type: 'string' },
                },
              },
              playCount: { type: 'integer' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching most played tracks');
    const history = await app.db.select({
      id: mediaTracks.id,
      title: mediaTracks.title,
      artist: mediaTracks.artist,
      album: mediaTracks.album,
      artworkUrl: mediaTracks.artworkUrl,
      trackId: playHistory.trackId,
    }).from(playHistory)
      .innerJoin(mediaTracks, eq(playHistory.trackId, mediaTracks.id))
      .where(eq(playHistory.userId, session.user.id));

    const trackPlayCounts = new Map<string, { track: any, count: number }>();
    history.forEach(entry => {
      const key = entry.id;
      if (!trackPlayCounts.has(key)) {
        trackPlayCounts.set(key, {
          track: {
            id: entry.id,
            title: entry.title,
            artist: entry.artist,
            album: entry.album,
            artworkUrl: entry.artworkUrl,
          },
          count: 0,
        });
      }
      trackPlayCounts.get(key)!.count += 1;
    });

    const results = Array.from(trackPlayCounts.values())
      .sort((a, b) => b.count - a.count)
      .map(item => ({
        track: item.track,
        playCount: item.count,
      }));

    app.logger.info({ userId: session.user.id, count: results.length }, 'Most played tracks retrieved');
    return results;
  });

  // DELETE /api/history/:id - Delete history entry
  app.fastify.delete('/api/history/:id', {
    schema: {
      description: 'Delete a play history entry',
      tags: ['history'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: { type: 'object', properties: { success: { type: 'boolean' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        403: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ historyId: request.params.id, userId: session.user.id }, 'Deleting history entry');
    const entry = await app.db.select().from(playHistory).where(eq(playHistory.id, request.params.id));

    if (entry.length === 0) {
      app.logger.warn({ historyId: request.params.id }, 'History entry not found');
      reply.statusCode = 404;
      return { error: 'History entry not found' };
    }

    if (entry[0].userId !== session.user.id) {
      app.logger.warn({ historyId: request.params.id, userId: session.user.id }, 'User does not own history entry');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    await app.db.delete(playHistory).where(eq(playHistory.id, request.params.id));
    app.logger.info({ historyId: request.params.id }, 'History entry deleted successfully');
    return { success: true };
  });
}
