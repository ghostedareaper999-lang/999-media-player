import type { App } from '../index.js';
import type { FastifyRequest, FastifyReply } from 'fastify';
import { eq, and } from 'drizzle-orm';
import { queue, mediaTracks } from '../db/schema/schema.js';

interface AddToQueueBody {
  trackId: string;
  position?: number;
}

interface ReorderQueueBody {
  trackId: string;
  newPosition: number;
}

export function registerQueueRoutes(app: App) {
  const requireAuth = app.requireAuth();

  // GET /api/queue - Get current queue
  app.fastify.get('/api/queue', {
    schema: {
      description: 'Get the current queue for the user',
      tags: ['queue'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              userId: { type: 'string' },
              trackId: { type: 'string' },
              track: {
                type: 'object',
                properties: {
                  id: { type: 'string' },
                  title: { type: 'string' },
                  artist: { type: 'string' },
                  album: { type: 'string' },
                  duration: { type: 'integer' },
                  artworkUrl: { type: 'string' },
                },
              },
              position: { type: 'integer' },
              createdAt: { type: 'string', format: 'date-time' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching queue');
    const queueItems = await app.db.select({
      id: queue.id,
      userId: queue.userId,
      trackId: queue.trackId,
      track: {
        id: mediaTracks.id,
        title: mediaTracks.title,
        artist: mediaTracks.artist,
        album: mediaTracks.album,
        duration: mediaTracks.duration,
        artworkUrl: mediaTracks.artworkUrl,
      },
      position: queue.position,
      createdAt: queue.createdAt,
    }).from(queue)
      .innerJoin(mediaTracks, eq(queue.trackId, mediaTracks.id))
      .where(eq(queue.userId, session.user.id))
      .orderBy(queue.position);

    app.logger.info({ userId: session.user.id, count: queueItems.length }, 'Queue retrieved');
    return queueItems;
  });

  // POST /api/queue - Add track to queue
  app.fastify.post('/api/queue', {
    schema: {
      description: 'Add a track to the queue',
      tags: ['queue'],
      body: {
        type: 'object',
        required: ['trackId'],
        properties: {
          trackId: { type: 'string', format: 'uuid' },
          position: { type: 'integer' },
        },
      },
      response: {
        201: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              userId: { type: 'string' },
              trackId: { type: 'string' },
              track: { type: 'object' },
              position: { type: 'integer' },
              createdAt: { type: 'string', format: 'date-time' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Body: AddToQueueBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id, trackId: request.body.trackId }, 'Adding track to queue');
    const queueItems = await app.db.select().from(queue).where(eq(queue.userId, session.user.id));
    const position = request.body.position ?? queueItems.length;

    await app.db.insert(queue).values({
      userId: session.user.id,
      trackId: request.body.trackId,
      position,
    });

    const updated = await app.db.select({
      id: queue.id,
      userId: queue.userId,
      trackId: queue.trackId,
      track: {
        id: mediaTracks.id,
        title: mediaTracks.title,
        artist: mediaTracks.artist,
        album: mediaTracks.album,
        duration: mediaTracks.duration,
        artworkUrl: mediaTracks.artworkUrl,
      },
      position: queue.position,
      createdAt: queue.createdAt,
    }).from(queue)
      .innerJoin(mediaTracks, eq(queue.trackId, mediaTracks.id))
      .where(eq(queue.userId, session.user.id))
      .orderBy(queue.position);

    app.logger.info({ userId: session.user.id, trackId: request.body.trackId }, 'Track added to queue');
    reply.statusCode = 201;
    return updated;
  });

  // DELETE /api/queue/:id - Remove track from queue
  app.fastify.delete('/api/queue/:id', {
    schema: {
      description: 'Remove a track from the queue',
      tags: ['queue'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: { type: 'object', properties: { success: { type: 'boolean' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        403: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ queueId: request.params.id, userId: session.user.id }, 'Removing track from queue');
    const item = await app.db.select().from(queue).where(eq(queue.id, request.params.id));

    if (item.length === 0) {
      app.logger.warn({ queueId: request.params.id }, 'Queue item not found');
      reply.statusCode = 404;
      return { error: 'Queue item not found' };
    }

    if (item[0].userId !== session.user.id) {
      app.logger.warn({ queueId: request.params.id, userId: session.user.id }, 'User does not own queue item');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    await app.db.delete(queue).where(eq(queue.id, request.params.id));
    app.logger.info({ queueId: request.params.id }, 'Track removed from queue');
    return { success: true };
  });

  // DELETE /api/queue - Clear entire queue
  app.fastify.delete('/api/queue', {
    schema: {
      description: 'Clear the entire queue for the current user',
      tags: ['queue'],
      response: {
        200: { type: 'object', properties: { success: { type: 'boolean' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Clearing queue');
    await app.db.delete(queue).where(eq(queue.userId, session.user.id));
    app.logger.info({ userId: session.user.id }, 'Queue cleared');
    return { success: true };
  });

  // PUT /api/queue/reorder - Reorder queue
  app.fastify.put('/api/queue/reorder', {
    schema: {
      description: 'Reorder a track in the queue',
      tags: ['queue'],
      body: {
        type: 'object',
        required: ['trackId', 'newPosition'],
        properties: {
          trackId: { type: 'string', format: 'uuid' },
          newPosition: { type: 'integer' },
        },
      },
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              userId: { type: 'string' },
              trackId: { type: 'string' },
              track: { type: 'object' },
              position: { type: 'integer' },
              createdAt: { type: 'string', format: 'date-time' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Body: ReorderQueueBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id, trackId: request.body.trackId, newPosition: request.body.newPosition }, 'Reordering queue');
    const queueItems = await app.db.select().from(queue).where(eq(queue.userId, session.user.id)).orderBy(queue.position);

    const itemIndex = queueItems.findIndex(item => item.trackId === request.body.trackId);
    if (itemIndex === -1) {
      app.logger.warn({ userId: session.user.id, trackId: request.body.trackId }, 'Track not found in queue');
      return { error: 'Track not found in queue' };
    }

    const oldPosition = queueItems[itemIndex].position;
    const newPos = request.body.newPosition;

    if (oldPosition < newPos) {
      // Moving down
      for (let i = itemIndex + 1; i < queueItems.length && queueItems[i].position <= newPos; i++) {
        await app.db.update(queue).set({ position: queueItems[i].position - 1 }).where(eq(queue.id, queueItems[i].id));
      }
    } else if (oldPosition > newPos) {
      // Moving up
      for (let i = itemIndex - 1; i >= 0 && queueItems[i].position >= newPos; i--) {
        await app.db.update(queue).set({ position: queueItems[i].position + 1 }).where(eq(queue.id, queueItems[i].id));
      }
    }

    await app.db.update(queue).set({ position: newPos }).where(eq(queue.id, queueItems[itemIndex].id));

    const updated = await app.db.select({
      id: queue.id,
      userId: queue.userId,
      trackId: queue.trackId,
      track: {
        id: mediaTracks.id,
        title: mediaTracks.title,
        artist: mediaTracks.artist,
        album: mediaTracks.album,
        duration: mediaTracks.duration,
        artworkUrl: mediaTracks.artworkUrl,
      },
      position: queue.position,
      createdAt: queue.createdAt,
    }).from(queue)
      .innerJoin(mediaTracks, eq(queue.trackId, mediaTracks.id))
      .where(eq(queue.userId, session.user.id))
      .orderBy(queue.position);

    app.logger.info({ userId: session.user.id, trackId: request.body.trackId }, 'Queue reordered');
    return updated;
  });
}
