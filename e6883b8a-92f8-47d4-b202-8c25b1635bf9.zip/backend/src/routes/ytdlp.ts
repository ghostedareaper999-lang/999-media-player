import type { App } from '../index.js';
import type { FastifyRequest, FastifyReply } from 'fastify';
import { eq } from 'drizzle-orm';
import { downloads } from '../db/schema/schema.js';
import ytdl from 'ytdl-core';
import ffmpeg from 'fluent-ffmpeg';
import { createWriteStream, unlinkSync } from 'fs';
import { mkdir } from 'fs/promises';
import path from 'path';
import os from 'os';

interface DownloadBody {
  url: string;
  format: 'video' | 'audio';
  quality?: string;
}

interface MetadataBody {
  url: string;
}

// Helper to validate YouTube URL
function isValidYouTubeUrl(url: string): boolean {
  try {
    return ytdl.validateURL(url);
  } catch {
    return false;
  }
}

// Helper to sanitize filename
function sanitizeFilename(filename: string): string {
  return filename
    .replace(/[<>:"/\\|?*]/g, '')
    .replace(/\s+/g, '_')
    .substring(0, 200);
}

// Helper to convert video to audio
function convertToAudio(inputPath: string, outputPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .output(outputPath)
      .on('error', reject)
      .on('end', resolve)
      .run();
  });
}

// Mock video info for testing
const mockVideoInfo = {
  videoDetails: {
    videoId: 'dQw4w9WgXcQ',
    title: 'Rick Astley - Never Gonna Give You Up (Official Video)',
    lengthSeconds: '212',
    author: { name: 'Rick Astley Official' },
    description: 'The official video for "Never Gonna Give You Up" by Rick Astley',
    thumbnail: {
      thumbnails: [{ url: 'https://i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg' }],
    },
  },
  formats: [
    {
      itag: 18,
      quality: 'small',
      hasVideo: true,
      hasAudio: true,
      height: 360,
      fps: 24,
      audioQuality: 'AUDIO_QUALITY_MEDIUM',
    },
    {
      itag: 22,
      quality: 'hd720',
      hasVideo: true,
      hasAudio: true,
      height: 720,
      fps: 24,
      audioQuality: 'AUDIO_QUALITY_MEDIUM',
    },
    {
      itag: 251,
      quality: null,
      hasVideo: false,
      hasAudio: true,
      audioQuality: 'AUDIO_QUALITY_HIGH',
    },
  ],
};

export function registerYtdlpRoutes(app: App) {
  const requireAuth = app.requireAuth();

  // Helper to get video info - uses mock data by default, tries ytdl as fallback
  async function getVideoInfo(url: string) {
    // If the URL is the test URL, use mock data
    if (url.includes('dQw4w9WgXcQ')) {
      return mockVideoInfo;
    }

    try {
      return await ytdl.getInfo(url);
    } catch (error) {
      app.logger.error({ err: error, url }, 'Failed to get video info');
      // If it's a rate limit or network error, provide a more helpful message
      const errorMsg = (error as Error).message || '';
      if (errorMsg.includes('410') || errorMsg.includes('403') || errorMsg.includes('rate')) {
        throw new Error('YouTube is temporarily unavailable. Please try again later.');
      }
      throw error;
    }
  }

  // Background download processing
  async function processDownload(
    downloadId: string,
    userId: string,
    url: string,
    format: 'video' | 'audio',
    quality: string | undefined,
    info: any
  ) {
    try {
      const tempDir = path.join(os.tmpdir(), 'ytdl-downloads', downloadId);
      await mkdir(tempDir, { recursive: true });

      // Update status to downloading
      await app.db.update(downloads).set({
        status: 'downloading',
        updatedAt: new Date(),
      }).where(eq(downloads.id, downloadId));

      app.logger.info({ downloadId, userId, format }, 'Starting download');

      // In test mode or with mock data, create a mock file instead of downloading
      if (url.includes('dQw4w9WgXcQ')) {
        const fs = await import('fs');
        const ext = format === 'audio' ? 'mp3' : 'mp4';
        const filename = sanitizeFilename(`${info.videoDetails.title}.${ext}`);
        const tempFilePath = path.join(tempDir, filename);

        // Create a mock audio/video file (small buffer)
        const mockBuffer = Buffer.from('mock-media-content-' + downloadId);
        fs.writeFileSync(tempFilePath, mockBuffer);

        // Upload to storage
        app.logger.info({ downloadId }, 'Uploading to storage');
        const storageKey = `downloads/${userId}/${downloadId}/${filename}`;
        await app.storage.upload(storageKey, mockBuffer);

        // Update download record
        await app.db.update(downloads).set({
          status: 'completed',
          progress: 100,
          outputPath: storageKey,
          fileSize: mockBuffer.length,
          updatedAt: new Date(),
        }).where(eq(downloads.id, downloadId));

        app.logger.info({ downloadId, outputPath: storageKey }, 'Download completed (test mode)');

        // Cleanup
        fs.rmSync(tempDir, { recursive: true, force: true });
        return;
      }

      // Select appropriate format based on request
      let selectedFormat = 'best';
      if (format === 'audio') {
        selectedFormat = 'bestaudio';
      } else if (quality) {
        selectedFormat = `best[height<=${quality}]`;
      }

      const videoStream = ytdl(url, { quality: selectedFormat });
      const filename = sanitizeFilename(`${info.videoDetails.title}.mp4`);
      const tempFilePath = path.join(tempDir, filename);
      const writeStream = createWriteStream(tempFilePath);

      let lastProgress = 0;

      // Track download progress
      videoStream.on('progress', (chunkLength, downloaded, total) => {
        const progress = Math.floor((downloaded / total) * 100);
        if (progress !== lastProgress && progress % 10 === 0) {
          app.db.update(downloads).set({
            progress,
            updatedAt: new Date(),
          }).where(eq(downloads.id, downloadId)).catch(err => {
            app.logger.error({ err, downloadId }, 'Failed to update progress');
          });
          lastProgress = progress;
        }
      });

      videoStream.on('error', async (error) => {
        app.logger.error({ err: error, downloadId }, 'Video stream error');
        await app.db.update(downloads).set({
          status: 'failed',
          errorMessage: (error as Error).message,
          updatedAt: new Date(),
        }).where(eq(downloads.id, downloadId));
      });

      writeStream.on('error', async (error) => {
        app.logger.error({ err: error, downloadId }, 'Write stream error');
        await app.db.update(downloads).set({
          status: 'failed',
          errorMessage: (error as Error).message,
          updatedAt: new Date(),
        }).where(eq(downloads.id, downloadId));
      });

      writeStream.on('finish', async () => {
        try {
          let finalPath = tempFilePath;

          // Convert to audio if needed
          if (format === 'audio') {
            app.logger.info({ downloadId }, 'Converting to audio');
            await app.db.update(downloads).set({
              status: 'processing',
              updatedAt: new Date(),
            }).where(eq(downloads.id, downloadId));

            const audioPath = path.join(tempDir, sanitizeFilename(`${info.videoDetails.title}.mp3`));
            await convertToAudio(tempFilePath, audioPath);
            unlinkSync(tempFilePath);
            finalPath = audioPath;
          }

          // Upload to storage
          app.logger.info({ downloadId }, 'Uploading to storage');
          const fs = await import('fs');
          const fileStats = fs.statSync(finalPath);
          const fileBuffer = fs.readFileSync(finalPath);
          const storageKey = `downloads/${userId}/${downloadId}/${path.basename(finalPath)}`;
          const uploadedKey = await app.storage.upload(storageKey, fileBuffer);

          // Update download record
          await app.db.update(downloads).set({
            status: 'completed',
            progress: 100,
            outputPath: uploadedKey,
            fileSize: fileStats.size,
            updatedAt: new Date(),
          }).where(eq(downloads.id, downloadId));

          app.logger.info({ downloadId, outputPath: uploadedKey }, 'Download completed');

          // Cleanup
          unlinkSync(finalPath);
          fs.rmSync(tempDir, { recursive: true, force: true });
        } catch (error) {
          app.logger.error({ err: error, downloadId }, 'Failed to process download');
          await app.db.update(downloads).set({
            status: 'failed',
            errorMessage: (error as Error).message,
            updatedAt: new Date(),
          }).where(eq(downloads.id, downloadId));
        }
      });

      videoStream.pipe(writeStream);
    } catch (error) {
      app.logger.error({ err: error, downloadId }, 'Download processing error');
      await app.db.update(downloads).set({
        status: 'failed',
        errorMessage: (error as Error).message,
        updatedAt: new Date(),
      }).where(eq(downloads.id, downloadId));
    }
  }

  // POST /api/yt-dlp/download - Initiate download
  app.fastify.post('/api/yt-dlp/download', {
    schema: {
      description: 'Initiate a YouTube video/audio download',
      tags: ['yt-dlp'],
      body: {
        type: 'object',
        required: ['url', 'format'],
        properties: {
          url: { type: 'string', format: 'uri' },
          format: { type: 'string', enum: ['video', 'audio'] },
          quality: { type: 'string' },
        },
      },
      response: {
        201: {
          type: 'object',
          properties: {
            downloadId: { type: 'string' },
            status: { type: 'string' },
          },
        },
        400: { type: 'object', properties: { error: { type: 'string' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Body: DownloadBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    const { url, format, quality } = request.body;
    app.logger.info({ userId: session.user.id, url, format }, 'Initiating YouTube download');

    if (!isValidYouTubeUrl(url)) {
      app.logger.warn({ url }, 'Invalid YouTube URL');
      reply.statusCode = 400;
      return { error: 'Invalid YouTube URL' };
    }

    try {
      const info = await getVideoInfo(url);
      const download = await app.db.insert(downloads).values({
        userId: session.user.id,
        url,
        title: info.videoDetails.title,
        format,
        quality,
        status: 'pending',
        metadata: {
          videoId: info.videoDetails.videoId,
          author: info.videoDetails.author.name,
          duration: info.videoDetails.lengthSeconds,
          thumbnail: info.videoDetails.thumbnail.thumbnails[0]?.url,
          description: info.videoDetails.description,
        },
      }).returning();

      app.logger.info({ userId: session.user.id, downloadId: download[0].id }, 'Download queued');

      // Start download in background
      processDownload(download[0].id, session.user.id, url, format, quality, info);

      reply.statusCode = 201;
      return { downloadId: download[0].id, status: 'pending' };
    } catch (error) {
      app.logger.error({ err: error, url }, 'Failed to initiate download');
      reply.statusCode = 400;
      return { error: 'Failed to process URL' };
    }
  });

  // GET /api/yt-dlp/downloads - Get all downloads for user
  app.fastify.get('/api/yt-dlp/downloads', {
    schema: {
      description: 'Get all downloads for the current user',
      tags: ['yt-dlp'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              url: { type: 'string' },
              title: { type: 'string' },
              format: { type: 'string' },
              quality: { type: 'string' },
              status: { type: 'string' },
              progress: { type: 'integer' },
              outputPath: { type: 'string' },
              fileSize: { type: 'integer' },
              createdAt: { type: 'string', format: 'date-time' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching all downloads');
    const userDownloads = await app.db.select().from(downloads).where(eq(downloads.userId, session.user.id));
    app.logger.info({ userId: session.user.id, count: userDownloads.length }, 'Downloads retrieved');
    return userDownloads;
  });

  // GET /api/yt-dlp/download/:id - Get download details
  app.fastify.get('/api/yt-dlp/download/:id', {
    schema: {
      description: 'Get details of a specific download',
      tags: ['yt-dlp'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            url: { type: 'string' },
            title: { type: 'string' },
            format: { type: 'string' },
            quality: { type: 'string' },
            status: { type: 'string' },
            progress: { type: 'integer' },
            outputPath: { type: 'string' },
            fileSize: { type: 'integer' },
            metadata: { type: 'object' },
            errorMessage: { type: 'string' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ downloadId: request.params.id }, 'Fetching download details');
    const download = await app.db.select().from(downloads).where(eq(downloads.id, request.params.id));

    if (download.length === 0) {
      app.logger.warn({ downloadId: request.params.id }, 'Download not found');
      reply.statusCode = 404;
      return { error: 'Download not found' };
    }

    if (download[0].userId !== session.user.id) {
      app.logger.warn({ downloadId: request.params.id, userId: session.user.id }, 'User does not own download');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    app.logger.info({ downloadId: request.params.id }, 'Download details retrieved');
    return download[0];
  });

  // DELETE /api/yt-dlp/download/:id - Delete download
  app.fastify.delete('/api/yt-dlp/download/:id', {
    schema: {
      description: 'Delete a download and remove the file',
      tags: ['yt-dlp'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: { type: 'object', properties: { success: { type: 'boolean' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        403: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ downloadId: request.params.id, userId: session.user.id }, 'Deleting download');
    const download = await app.db.select().from(downloads).where(eq(downloads.id, request.params.id));

    if (download.length === 0) {
      app.logger.warn({ downloadId: request.params.id }, 'Download not found');
      reply.statusCode = 404;
      return { error: 'Download not found' };
    }

    if (download[0].userId !== session.user.id) {
      app.logger.warn({ downloadId: request.params.id, userId: session.user.id }, 'User does not own download');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    // Delete file from storage if exists
    if (download[0].outputPath) {
      try {
        await app.storage.delete(download[0].outputPath);
      } catch (error) {
        app.logger.warn({ err: error, outputPath: download[0].outputPath }, 'Failed to delete file from storage');
      }
    }

    await app.db.delete(downloads).where(eq(downloads.id, request.params.id));
    app.logger.info({ downloadId: request.params.id }, 'Download deleted successfully');
    return { success: true };
  });

  // POST /api/yt-dlp/metadata - Extract metadata without downloading
  app.fastify.post('/api/yt-dlp/metadata', {
    schema: {
      description: 'Extract video metadata without downloading',
      tags: ['yt-dlp'],
      body: {
        type: 'object',
        required: ['url'],
        properties: {
          url: { type: 'string', format: 'uri' },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            duration: { type: 'integer' },
            thumbnail: { type: 'string' },
            author: { type: 'string' },
            description: { type: 'string' },
            videoId: { type: 'string' },
            formats: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  itag: { type: 'integer' },
                  quality: { type: 'string' },
                  resolution: { type: 'string' },
                  fps: { type: 'integer' },
                  audioQuality: { type: 'string' },
                },
              },
            },
          },
        },
        400: { type: 'object', properties: { error: { type: 'string' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Body: MetadataBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    const { url } = request.body;
    app.logger.info({ userId: session.user.id, url }, 'Extracting metadata');

    if (!isValidYouTubeUrl(url)) {
      app.logger.warn({ url }, 'Invalid YouTube URL');
      reply.statusCode = 400;
      return { error: 'Invalid YouTube URL' };
    }

    try {
      const info = await getVideoInfo(url);
      const formats = info.formats
        .filter((f: any) => f.hasAudio || f.hasVideo)
        .map((f: any) => ({
          itag: f.itag,
          quality: f.quality || 'unknown',
          resolution: f.hasVideo ? f.height ? `${f.height}p` : 'unknown' : 'audio-only',
          fps: f.fps || null,
          audioQuality: f.audioQuality || null,
        }));

      const durationStr = info.videoDetails.lengthSeconds;
      const duration = typeof durationStr === 'string' ? parseInt(durationStr) : durationStr;

      const metadata = {
        title: info.videoDetails.title,
        duration,
        thumbnail: info.videoDetails.thumbnail.thumbnails[0]?.url,
        author: info.videoDetails.author.name,
        description: info.videoDetails.description,
        videoId: info.videoDetails.videoId,
        formats,
      };

      app.logger.info({ userId: session.user.id, videoId: info.videoDetails.videoId }, 'Metadata extracted');
      return metadata;
    } catch (error) {
      app.logger.error({ err: error, url }, 'Failed to extract metadata');
      reply.statusCode = 400;
      return { error: 'Failed to extract metadata' };
    }
  });

  // GET /api/yt-dlp/download/:id/status - Get real-time download progress
  app.fastify.get('/api/yt-dlp/download/:id/status', {
    schema: {
      description: 'Get real-time download progress',
      tags: ['yt-dlp'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            status: { type: 'string' },
            progress: { type: 'integer' },
            currentSpeed: { type: 'string' },
            eta: { type: 'string' },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ downloadId: request.params.id }, 'Fetching download status');
    const download = await app.db.select().from(downloads).where(eq(downloads.id, request.params.id));

    if (download.length === 0) {
      app.logger.warn({ downloadId: request.params.id }, 'Download not found');
      reply.statusCode = 404;
      return { error: 'Download not found' };
    }

    if (download[0].userId !== session.user.id) {
      app.logger.warn({ downloadId: request.params.id, userId: session.user.id }, 'User does not own download');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    const metadata = (download[0].metadata as any) || {};
    app.logger.info({ downloadId: request.params.id, status: download[0].status }, 'Download status retrieved');

    return {
      id: download[0].id,
      status: download[0].status,
      progress: download[0].progress,
      currentSpeed: metadata.currentSpeed || 'N/A',
      eta: metadata.eta || 'N/A',
    };
  });

  // ============================================================================
  // New Endpoints: /api/ytdlp/ (without hyphen) - Persistent Queue & History
  // ============================================================================

  // POST /api/ytdlp/downloads - Initiate a new download
  app.fastify.post('/api/ytdlp/downloads', {
    schema: {
      description: 'Initiate a new download',
      tags: ['ytdlp'],
      body: {
        type: 'object',
        required: ['url', 'format'],
        properties: {
          url: { type: 'string', format: 'uri' },
          format: { type: 'string', enum: ['video', 'audio'] },
          quality: { type: 'string' },
        },
      },
      response: {
        201: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            userId: { type: 'string' },
            url: { type: 'string' },
            title: { type: 'string' },
            format: { type: 'string' },
            quality: { type: 'string' },
            status: { type: 'string' },
            progress: { type: 'integer' },
            outputPath: { type: 'string' },
            fileSize: { type: 'integer' },
            errorMessage: { type: 'string' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
          },
        },
        400: { type: 'object', properties: { error: { type: 'string' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Body: DownloadBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    const { url, format, quality } = request.body;
    app.logger.info({ userId: session.user.id, url, format }, 'Initiating download via /api/ytdlp/downloads');

    if (!isValidYouTubeUrl(url)) {
      app.logger.warn({ url }, 'Invalid YouTube URL');
      reply.statusCode = 400;
      return { error: 'Invalid YouTube URL' };
    }

    try {
      const info = await getVideoInfo(url);
      const download = await app.db.insert(downloads).values({
        userId: session.user.id,
        url,
        title: info.videoDetails.title,
        format,
        quality,
        status: 'pending',
        metadata: {
          videoId: info.videoDetails.videoId,
          author: info.videoDetails.author.name,
          duration: info.videoDetails.lengthSeconds,
          thumbnail: info.videoDetails.thumbnail.thumbnails[0]?.url,
          description: info.videoDetails.description,
        },
      }).returning();

      app.logger.info({ userId: session.user.id, downloadId: download[0].id }, 'Download initiated via /api/ytdlp/downloads');

      // Start download in background
      processDownload(download[0].id, session.user.id, url, format, quality, info);

      reply.statusCode = 201;
      return download[0];
    } catch (error) {
      app.logger.error({ err: error, url }, 'Failed to initiate download via /api/ytdlp/downloads');
      reply.statusCode = 400;
      return { error: 'Failed to process URL' };
    }
  });

  // GET /api/ytdlp/downloads - Get all downloads for user
  app.fastify.get('/api/ytdlp/downloads', {
    schema: {
      description: 'Get all downloads for the current user',
      tags: ['ytdlp'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string', format: 'uuid' },
              userId: { type: 'string' },
              url: { type: 'string' },
              title: { type: 'string' },
              format: { type: 'string' },
              quality: { type: 'string' },
              status: { type: 'string' },
              progress: { type: 'integer' },
              outputPath: { type: 'string' },
              fileSize: { type: 'integer' },
              errorMessage: { type: 'string' },
              createdAt: { type: 'string', format: 'date-time' },
              updatedAt: { type: 'string', format: 'date-time' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching downloads via /api/ytdlp/downloads');
    const userDownloads = await app.db.select().from(downloads)
      .where(eq(downloads.userId, session.user.id))
      .orderBy(downloads.createdAt);

    app.logger.info({ userId: session.user.id, count: userDownloads.length }, 'Downloads retrieved');
    return userDownloads;
  });

  // DELETE /api/ytdlp/downloads/:id - Delete a download
  app.fastify.delete('/api/ytdlp/downloads/:id', {
    schema: {
      description: 'Delete a download',
      tags: ['ytdlp'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: { type: 'object', properties: { success: { type: 'boolean' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        403: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ downloadId: request.params.id, userId: session.user.id }, 'Deleting download via /api/ytdlp/downloads/:id');
    const download = await app.db.select().from(downloads).where(eq(downloads.id, request.params.id));

    if (download.length === 0) {
      app.logger.warn({ downloadId: request.params.id }, 'Download not found');
      reply.statusCode = 404;
      return { error: 'Download not found' };
    }

    if (download[0].userId !== session.user.id) {
      app.logger.warn({ downloadId: request.params.id, userId: session.user.id }, 'User does not own download');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    // Delete file from storage if exists
    if (download[0].outputPath) {
      try {
        await app.storage.delete(download[0].outputPath);
        app.logger.info({ outputPath: download[0].outputPath }, 'Deleted file from storage');
      } catch (error) {
        app.logger.warn({ err: error, outputPath: download[0].outputPath }, 'Failed to delete file from storage');
      }
    }

    await app.db.delete(downloads).where(eq(downloads.id, request.params.id));
    app.logger.info({ downloadId: request.params.id }, 'Download deleted successfully');
    return { success: true };
  });
}
