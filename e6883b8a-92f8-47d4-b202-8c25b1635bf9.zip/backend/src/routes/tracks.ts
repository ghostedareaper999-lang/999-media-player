import type { App } from '../index.js';
import type { FastifyRequest, FastifyReply } from 'fastify';
import { eq, and, ilike, desc, or } from 'drizzle-orm';
import { mediaTracks } from '../db/schema/schema.js';

interface CreateTrackBody {
  filePath: string;
  fileName: string;
  title?: string;
  artist?: string;
  album?: string;
  genre?: string;
  duration?: number;
  fileSize?: number;
  mimeType?: string;
  artworkUrl?: string;
  lyrics?: string;
  year?: number;
  trackNumber?: number;
  bitrate?: number;
  sampleRate?: number;
}

interface UpdateTrackBody {
  title?: string;
  artist?: string;
  album?: string;
  genre?: string;
  artworkUrl?: string;
  lyrics?: string;
  year?: number;
  trackNumber?: number;
}

interface SearchQuery {
  q?: string;
}

export function registerTrackRoutes(app: App) {
  const requireAuth = app.requireAuth();

  // GET /api/tracks - Get all tracks for user
  app.fastify.get('/api/tracks', {
    schema: {
      description: 'Get all media tracks for the current user',
      tags: ['tracks'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              userId: { type: 'string' },
              filePath: { type: 'string' },
              fileName: { type: 'string' },
              title: { type: 'string' },
              artist: { type: 'string' },
              album: { type: 'string' },
              genre: { type: 'string' },
              duration: { type: 'integer' },
              fileSize: { type: 'integer' },
              mimeType: { type: 'string' },
              artworkUrl: { type: 'string' },
              lyrics: { type: 'string' },
              year: { type: 'integer' },
              trackNumber: { type: 'integer' },
              bitrate: { type: 'integer' },
              sampleRate: { type: 'integer' },
              createdAt: { type: 'string', format: 'date-time' },
              updatedAt: { type: 'string', format: 'date-time' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching all tracks');
    const tracks = await app.db.select().from(mediaTracks).where(eq(mediaTracks.userId, session.user.id));
    app.logger.info({ userId: session.user.id, count: tracks.length }, 'Tracks retrieved');
    return tracks;
  });

  // POST /api/tracks - Create a new track
  app.fastify.post('/api/tracks', {
    schema: {
      description: 'Create a new media track',
      tags: ['tracks'],
      body: {
        type: 'object',
        required: ['filePath', 'fileName'],
        properties: {
          filePath: { type: 'string' },
          fileName: { type: 'string' },
          title: { type: 'string' },
          artist: { type: 'string' },
          album: { type: 'string' },
          genre: { type: 'string' },
          duration: { type: 'integer' },
          fileSize: { type: 'integer' },
          mimeType: { type: 'string' },
          artworkUrl: { type: 'string' },
          lyrics: { type: 'string' },
          year: { type: 'integer' },
          trackNumber: { type: 'integer' },
          bitrate: { type: 'integer' },
          sampleRate: { type: 'integer' },
        },
      },
      response: {
        201: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            filePath: { type: 'string' },
            fileName: { type: 'string' },
            title: { type: 'string' },
            artist: { type: 'string' },
            album: { type: 'string' },
            genre: { type: 'string' },
            duration: { type: 'integer' },
            fileSize: { type: 'integer' },
            mimeType: { type: 'string' },
            artworkUrl: { type: 'string' },
            lyrics: { type: 'string' },
            year: { type: 'integer' },
            trackNumber: { type: 'integer' },
            bitrate: { type: 'integer' },
            sampleRate: { type: 'integer' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
          },
        },
        400: { type: 'object', properties: { error: { type: 'string' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Body: CreateTrackBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    const { filePath, fileName, ...rest } = request.body;
    app.logger.info({ userId: session.user.id, filePath }, 'Creating track');

    // Check if track already exists with same filePath
    const existing = await app.db.select().from(mediaTracks).where(
      and(eq(mediaTracks.userId, session.user.id), eq(mediaTracks.filePath, filePath))
    );

    if (existing.length > 0) {
      app.logger.warn({ userId: session.user.id, filePath }, 'Track with this filePath already exists');
      reply.statusCode = 400;
      return { error: 'Track with this file path already exists' };
    }

    const track = await app.db.insert(mediaTracks).values({
      userId: session.user.id,
      filePath,
      fileName,
      ...rest,
    }).returning();

    app.logger.info({ userId: session.user.id, trackId: track[0].id }, 'Track created successfully');
    reply.statusCode = 201;
    return track[0];
  });

  // GET /api/tracks/:id - Get single track
  app.fastify.get('/api/tracks/:id', {
    schema: {
      description: 'Get a single media track by ID',
      tags: ['tracks'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            filePath: { type: 'string' },
            fileName: { type: 'string' },
            title: { type: 'string' },
            artist: { type: 'string' },
            album: { type: 'string' },
            genre: { type: 'string' },
            duration: { type: 'integer' },
            fileSize: { type: 'integer' },
            mimeType: { type: 'string' },
            artworkUrl: { type: 'string' },
            lyrics: { type: 'string' },
            year: { type: 'integer' },
            trackNumber: { type: 'integer' },
            bitrate: { type: 'integer' },
            sampleRate: { type: 'integer' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ trackId: request.params.id }, 'Fetching track');
    const track = await app.db.select().from(mediaTracks).where(eq(mediaTracks.id, request.params.id));

    if (track.length === 0) {
      app.logger.warn({ trackId: request.params.id }, 'Track not found');
      reply.statusCode = 404;
      return { error: 'Track not found' };
    }

    app.logger.info({ trackId: request.params.id }, 'Track retrieved');
    return track[0];
  });

  // PUT /api/tracks/:id - Update track
  app.fastify.put('/api/tracks/:id', {
    schema: {
      description: 'Update a media track',
      tags: ['tracks'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      body: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          artist: { type: 'string' },
          album: { type: 'string' },
          genre: { type: 'string' },
          artworkUrl: { type: 'string' },
          lyrics: { type: 'string' },
          year: { type: 'integer' },
          trackNumber: { type: 'integer' },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            userId: { type: 'string' },
            filePath: { type: 'string' },
            fileName: { type: 'string' },
            title: { type: 'string' },
            artist: { type: 'string' },
            album: { type: 'string' },
            genre: { type: 'string' },
            duration: { type: 'integer' },
            fileSize: { type: 'integer' },
            mimeType: { type: 'string' },
            artworkUrl: { type: 'string' },
            lyrics: { type: 'string' },
            year: { type: 'integer' },
            trackNumber: { type: 'integer' },
            bitrate: { type: 'integer' },
            sampleRate: { type: 'integer' },
            createdAt: { type: 'string', format: 'date-time' },
            updatedAt: { type: 'string', format: 'date-time' },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        403: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string }, Body: UpdateTrackBody }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ trackId: request.params.id, userId: session.user.id }, 'Updating track');
    const track = await app.db.select().from(mediaTracks).where(eq(mediaTracks.id, request.params.id));

    if (track.length === 0) {
      app.logger.warn({ trackId: request.params.id }, 'Track not found');
      reply.statusCode = 404;
      return { error: 'Track not found' };
    }

    if (track[0].userId !== session.user.id) {
      app.logger.warn({ trackId: request.params.id, userId: session.user.id }, 'User does not own track');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    const updated = await app.db.update(mediaTracks).set({
      ...request.body,
      updatedAt: new Date(),
    }).where(eq(mediaTracks.id, request.params.id)).returning();

    app.logger.info({ trackId: request.params.id }, 'Track updated successfully');
    return updated[0];
  });

  // DELETE /api/tracks/:id - Delete track
  app.fastify.delete('/api/tracks/:id', {
    schema: {
      description: 'Delete a media track',
      tags: ['tracks'],
      params: {
        type: 'object',
        required: ['id'],
        properties: {
          id: { type: 'string', format: 'uuid' },
        },
      },
      response: {
        200: { type: 'object', properties: { success: { type: 'boolean' } } },
        401: { type: 'object', properties: { error: { type: 'string' } } },
        403: { type: 'object', properties: { error: { type: 'string' } } },
        404: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ trackId: request.params.id, userId: session.user.id }, 'Deleting track');
    const track = await app.db.select().from(mediaTracks).where(eq(mediaTracks.id, request.params.id));

    if (track.length === 0) {
      app.logger.warn({ trackId: request.params.id }, 'Track not found');
      reply.statusCode = 404;
      return { error: 'Track not found' };
    }

    if (track[0].userId !== session.user.id) {
      app.logger.warn({ trackId: request.params.id, userId: session.user.id }, 'User does not own track');
      reply.statusCode = 403;
      return { error: 'Forbidden' };
    }

    await app.db.delete(mediaTracks).where(eq(mediaTracks.id, request.params.id));
    app.logger.info({ trackId: request.params.id }, 'Track deleted successfully');
    return { success: true };
  });

  // GET /api/tracks/search - Search tracks
  app.fastify.get('/api/tracks/search', {
    schema: {
      description: 'Search media tracks by title, artist, album, genre, or lyrics',
      tags: ['tracks'],
      querystring: {
        type: 'object',
        properties: {
          q: { type: 'string', description: 'Search query' },
        },
      },
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: { type: 'string' },
              userId: { type: 'string' },
              filePath: { type: 'string' },
              fileName: { type: 'string' },
              title: { type: 'string' },
              artist: { type: 'string' },
              album: { type: 'string' },
              genre: { type: 'string' },
              duration: { type: 'integer' },
              fileSize: { type: 'integer' },
              mimeType: { type: 'string' },
              artworkUrl: { type: 'string' },
              lyrics: { type: 'string' },
              year: { type: 'integer' },
              trackNumber: { type: 'integer' },
              bitrate: { type: 'integer' },
              sampleRate: { type: 'integer' },
              createdAt: { type: 'string', format: 'date-time' },
              updatedAt: { type: 'string', format: 'date-time' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest<{ Querystring: SearchQuery }>, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    const query = request.query.q || '';
    app.logger.info({ userId: session.user.id, query }, 'Searching tracks');

    const searchTerm = `%${query}%`;
    const results = await app.db.select().from(mediaTracks).where(
      and(
        eq(mediaTracks.userId, session.user.id),
        or(
          ilike(mediaTracks.title, searchTerm),
          ilike(mediaTracks.artist, searchTerm),
          ilike(mediaTracks.album, searchTerm),
          ilike(mediaTracks.genre, searchTerm),
          ilike(mediaTracks.lyrics, searchTerm)
        )
      )
    );

    app.logger.info({ userId: session.user.id, query, count: results.length }, 'Search completed');
    return results;
  });

  // GET /api/tracks/albums - Get albums summary
  app.fastify.get('/api/tracks/albums', {
    schema: {
      description: 'Get unique albums with track count',
      tags: ['tracks'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              album: { type: 'string' },
              artist: { type: 'string' },
              trackCount: { type: 'integer' },
              artworkUrl: { type: 'string' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching albums');
    const tracks = await app.db.select().from(mediaTracks).where(eq(mediaTracks.userId, session.user.id));

    const albumMap = new Map<string, { album: string | null, artist: string | null, count: number, artworkUrl: string | null }>();
    tracks.forEach(track => {
      const key = `${track.album || 'Unknown'}|${track.artist || 'Unknown'}`;
      if (!albumMap.has(key)) {
        albumMap.set(key, { album: track.album, artist: track.artist, count: 0, artworkUrl: track.artworkUrl });
      }
      const entry = albumMap.get(key)!;
      entry.count += 1;
    });

    const albums = Array.from(albumMap.values()).map(a => ({
      album: a.album,
      artist: a.artist,
      trackCount: a.count,
      artworkUrl: a.artworkUrl,
    }));

    app.logger.info({ userId: session.user.id, count: albums.length }, 'Albums retrieved');
    return albums;
  });

  // GET /api/tracks/artists - Get artists summary
  app.fastify.get('/api/tracks/artists', {
    schema: {
      description: 'Get unique artists with track count',
      tags: ['tracks'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              artist: { type: 'string' },
              trackCount: { type: 'integer' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching artists');
    const tracks = await app.db.select().from(mediaTracks).where(eq(mediaTracks.userId, session.user.id));

    const artistMap = new Map<string, number>();
    tracks.forEach(track => {
      const artist = track.artist || 'Unknown';
      artistMap.set(artist, (artistMap.get(artist) || 0) + 1);
    });

    const artists = Array.from(artistMap.entries()).map(([artist, count]) => ({
      artist,
      trackCount: count,
    }));

    app.logger.info({ userId: session.user.id, count: artists.length }, 'Artists retrieved');
    return artists;
  });

  // GET /api/tracks/genres - Get genres summary
  app.fastify.get('/api/tracks/genres', {
    schema: {
      description: 'Get unique genres with track count',
      tags: ['tracks'],
      response: {
        200: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              genre: { type: 'string' },
              trackCount: { type: 'integer' },
            },
          },
        },
        401: { type: 'object', properties: { error: { type: 'string' } } },
      },
    },
  }, async (request: FastifyRequest, reply: FastifyReply) => {
    const session = await requireAuth(request, reply);
    if (!session) return;

    app.logger.info({ userId: session.user.id }, 'Fetching genres');
    const tracks = await app.db.select().from(mediaTracks).where(eq(mediaTracks.userId, session.user.id));

    const genreMap = new Map<string, number>();
    tracks.forEach(track => {
      const genre = track.genre || 'Unknown';
      genreMap.set(genre, (genreMap.get(genre) || 0) + 1);
    });

    const genres = Array.from(genreMap.entries()).map(([genre, count]) => ({
      genre,
      trackCount: count,
    }));

    app.logger.info({ userId: session.user.id, count: genres.length }, 'Genres retrieved');
    return genres;
  });
}
