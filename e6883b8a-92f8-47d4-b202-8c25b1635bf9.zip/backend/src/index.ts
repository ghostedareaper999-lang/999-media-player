import { createApplication } from "@specific-dev/framework";
import * as appSchema from './db/schema/schema.js';
import * as authSchema from './db/schema/auth-schema.js';
import { registerTrackRoutes } from './routes/tracks.js';
import { registerPlaylistRoutes } from './routes/playlists.js';
import { registerHistoryRoutes } from './routes/history.js';
import { registerQueueRoutes } from './routes/queue.js';
import { registerYtdlpRoutes } from './routes/ytdlp.js';

// Combine schemas
const schema = { ...appSchema, ...authSchema };

// Create application with schema for full database type support
export const app = await createApplication(schema);

// Export App type for use in route files
export type App = typeof app;

// Enable authentication
app.withAuth();

// Enable storage
app.withStorage();

// Register routes
registerTrackRoutes(app);
registerPlaylistRoutes(app);
registerHistoryRoutes(app);
registerQueueRoutes(app);
registerYtdlpRoutes(app);

await app.run();
app.logger.info('Application running');
