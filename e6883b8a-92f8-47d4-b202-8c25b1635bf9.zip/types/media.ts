
export interface MediaTrack {
  id: string;
  userId: string;
  filePath: string;
  fileName: string;
  title?: string;
  artist?: string;
  album?: string;
  genre?: string;
  duration?: number;
  fileSize?: number;
  mimeType?: string;
  artworkUrl?: string;
  lyrics?: string;
  year?: number;
  trackNumber?: number;
  bitrate?: number;
  sampleRate?: number;
  createdAt: string;
  updatedAt: string;
}

export interface Playlist {
  id: string;
  userId: string;
  name: string;
  description?: string;
  artworkUrl?: string;
  trackCount: number;
  createdAt: string;
  updatedAt: string;
  tracks?: PlaylistTrack[];
}

export interface PlaylistTrack {
  id: string;
  title?: string;
  artist?: string;
  album?: string;
  duration?: number;
  artworkUrl?: string;
  position: number;
}

export interface PlayHistory {
  id: string;
  track: {
    id: string;
    title?: string;
    artist?: string;
    album?: string;
    artworkUrl?: string;
  };
  playedAt: string;
  duration: number;
  completed: boolean;
}

export interface QueueItem {
  id: string;
  track: {
    id: string;
    title?: string;
    artist?: string;
    album?: string;
    duration?: number;
    artworkUrl?: string;
  };
  position: number;
}

export interface Album {
  album: string;
  artist?: string;
  trackCount: number;
  artworkUrl?: string;
}

export interface Artist {
  artist: string;
  trackCount: number;
}

export interface Genre {
  genre: string;
  trackCount: number;
}
