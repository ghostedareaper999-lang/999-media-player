
import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Dimensions, TouchableOpacity } from 'react-native';
import { colors } from '@/styles/commonStyles';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
} from 'react-native-reanimated';

interface WaveformSeekbarProps {
  player: any;
  currentTime: number;
  duration: number;
  onSeek: (time: number) => void;
  style?: 'bars' | 'line' | 'filled' | 'gradient';
  color?: string;
  height?: number;
}

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const BAR_COUNT = 100;

export function WaveformSeekbar({
  player,
  currentTime,
  duration,
  onSeek,
  style = 'bars',
  color = colors.primary,
  height = 60,
}: WaveformSeekbarProps) {
  const [waveformData, setWaveformData] = useState<number[]>(
    Array(BAR_COUNT).fill(0).map(() => 0.2 + Math.random() * 0.6)
  );
  const progressWidth = useSharedValue(0);

  // Update progress indicator
  useEffect(() => {
    if (duration > 0) {
      const progress = (currentTime / duration) * SCREEN_WIDTH;
      progressWidth.value = withTiming(progress, { duration: 100 });
    }
  }, [currentTime, duration]);

  const animatedProgressStyle = useAnimatedStyle(() => ({
    width: progressWidth.value,
  }));

  const handlePress = (event: any) => {
    const locationX = event.nativeEvent.locationX;
    const seekTime = (locationX / SCREEN_WIDTH) * duration;
    console.log('Waveform seekbar tapped, seeking to:', seekTime);
    onSeek(seekTime);
  };

  const renderBars = () => {
    const bars = [];
    const barWidth = SCREEN_WIDTH / BAR_COUNT;
    
    for (let i = 0; i < BAR_COUNT; i++) {
      const barHeight = Math.max(waveformData[i] * height, 4);
      const isPassed = (i / BAR_COUNT) * duration <= currentTime;
      
      bars.push(
        <View
          key={i}
          style={[
            styles.bar,
            {
              width: barWidth - 2,
              height: barHeight,
              backgroundColor: isPassed ? color : colors.outlineVariant,
            },
          ]}
        />
      );
    }
    
    return bars;
  };

  const renderFilled = () => {
    return (
      <View style={styles.filledContainer}>
        <View style={styles.filledBackground}>
          {waveformData.map((value, index) => {
            const barWidth = SCREEN_WIDTH / BAR_COUNT;
            const barHeight = value * height;
            
            return (
              <View
                key={`bg-${index}`}
                style={[
                  styles.filledBar,
                  {
                    width: barWidth,
                    height: barHeight,
                    backgroundColor: colors.outlineVariant,
                  },
                ]}
              />
            );
          })}
        </View>
        <Animated.View style={[styles.filledProgress, animatedProgressStyle]}>
          {waveformData.map((value, index) => {
            const barWidth = SCREEN_WIDTH / BAR_COUNT;
            const barHeight = value * height;
            
            return (
              <View
                key={`fg-${index}`}
                style={[
                  styles.filledBar,
                  {
                    width: barWidth,
                    height: barHeight,
                    backgroundColor: color,
                  },
                ]}
              />
            );
          })}
        </Animated.View>
      </View>
    );
  };

  return (
    <TouchableOpacity
      style={[styles.container, { height }]}
      activeOpacity={0.8}
      onPress={handlePress}
    >
      {style === 'bars' && <View style={styles.barsContainer}>{renderBars()}</View>}
      {(style === 'filled' || style === 'gradient') && renderFilled()}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  barsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: '100%',
  },
  bar: {
    borderRadius: 2,
  },
  filledContainer: {
    width: '100%',
    height: '100%',
    position: 'relative',
  },
  filledBackground: {
    flexDirection: 'row',
    alignItems: 'center',
    height: '100%',
    position: 'absolute',
    width: '100%',
  },
  filledProgress: {
    flexDirection: 'row',
    alignItems: 'center',
    height: '100%',
    overflow: 'hidden',
  },
  filledBar: {
    borderRadius: 1,
  },
});
