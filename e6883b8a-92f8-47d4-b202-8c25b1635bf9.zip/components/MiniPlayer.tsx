
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ImageSourcePropType } from 'react-native';
import { IconSymbol } from '@/components/IconSymbol';
import { MiniplayerPartyMode } from '@/components/MiniplayerPartyMode';
import { usePlayer } from '@/contexts/PlayerContext';
import { useDynamicColors } from '@/hooks/useDynamicColors';
import { colors, spacing, borderRadius, typography } from '@/styles/commonStyles';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';

function resolveImageSource(source: string | number | ImageSourcePropType | undefined): ImageSourcePropType {
  if (!source) return { uri: '' };
  if (typeof source === 'string') return { uri: source };
  return source as ImageSourcePropType;
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 80,
    left: spacing.md,
    right: spacing.md,
    borderRadius: borderRadius.lg,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  gradient: {
    padding: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  artworkContainer: {
    position: 'relative',
  },
  artwork: {
    width: 56,
    height: 56,
    borderRadius: borderRadius.md,
    backgroundColor: colors.surface,
  },
  pulseRing: {
    position: 'absolute',
    width: 56,
    height: 56,
    borderRadius: borderRadius.md,
    borderWidth: 2,
    borderColor: colors.primary,
  },
  info: {
    flex: 1,
  },
  title: {
    ...typography.bodyLarge,
    color: colors.onPrimary,
    fontWeight: '600',
    marginBottom: spacing.xs,
  },
  artist: {
    ...typography.labelMedium,
    color: colors.onPrimary,
    opacity: 0.8,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  controlButton: {
    padding: spacing.xs,
    borderRadius: borderRadius.full,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  progressBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.onPrimary,
  },
});

export function MiniPlayer() {
  const player = usePlayer();
  const router = useRouter();
  const [partyModeEnabled, setPartyModeEnabled] = useState(false);
  const dynamicColors = useDynamicColors(player.currentTrack?.artworkUrl);
  
  const pulseScale = useSharedValue(1);

  useEffect(() => {
    loadPartyModeSettings();
  }, []);

  useEffect(() => {
    if (player.isPlaying) {
      pulseScale.value = withRepeat(
        withTiming(1.1, { duration: 1000, easing: Easing.inOut(Easing.ease) }),
        -1,
        true
      );
    } else {
      pulseScale.value = withTiming(1, { duration: 300 });
    }
  }, [player.isPlaying]);

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseScale.value }],
    opacity: player.isPlaying ? 0.6 : 0,
  }));

  const loadPartyModeSettings = async () => {
    try {
      const settings = await AsyncStorage.getItem('miniplayer_settings');
      if (settings) {
        const parsed = JSON.parse(settings);
        setPartyModeEnabled(parsed.partyMode ?? false);
        console.log('Loaded miniplayer settings');
      }
    } catch (error) {
      console.error('Error loading miniplayer settings:', error);
    }
  };

  if (!player.currentTrack) {
    return null;
  }

  const handlePress = () => {
    console.log('Opening player screen from miniplayer');
    router.push('/player');
  };

  const handlePlayPause = (e: any) => {
    e.stopPropagation();
    if (player.isPlaying) {
      player.pause();
    } else {
      player.resume();
    }
  };

  const handleNext = (e: any) => {
    e.stopPropagation();
    player.next();
  };

  const trackTitle = player.currentTrack.title || player.currentTrack.fileName;
  const trackArtist = player.currentTrack.artist || 'Unknown Artist';

  const partyModeColors = dynamicColors
    ? [
        dynamicColors.vibrant,
        dynamicColors.lightVibrant,
        dynamicColors.darkVibrant,
        dynamicColors.muted,
      ]
    : [colors.primary, colors.secondary, colors.tertiary, colors.primaryContainer];

  const gradientColors = dynamicColors
    ? [dynamicColors.darkVibrant, dynamicColors.vibrant]
    : [colors.primaryContainer, colors.primary];

  return (
    <MiniplayerPartyMode enabled={partyModeEnabled} colors={partyModeColors}>
      <TouchableOpacity style={styles.container} onPress={handlePress} activeOpacity={0.9}>
        <LinearGradient colors={gradientColors} style={styles.gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
          <View style={styles.artworkContainer}>
            <Animated.View style={[styles.pulseRing, pulseStyle]} />
            <Image
              source={resolveImageSource(player.currentTrack.artworkUrl)}
              style={styles.artwork}
              resizeMode="cover"
            />
          </View>
          <View style={styles.info}>
            <Text style={styles.title} numberOfLines={1}>
              {trackTitle}
            </Text>
            <Text style={styles.artist} numberOfLines={1}>
              {trackArtist}
            </Text>
          </View>
          <View style={styles.controls}>
            <TouchableOpacity style={styles.controlButton} onPress={handlePlayPause}>
              <IconSymbol
                ios_icon_name={player.isPlaying ? 'pause.fill' : 'play.fill'}
                android_material_icon_name={player.isPlaying ? 'pause' : 'play-arrow'}
                size={24}
                color={colors.onPrimary}
              />
            </TouchableOpacity>
            <TouchableOpacity style={styles.controlButton} onPress={handleNext}>
              <IconSymbol
                ios_icon_name="forward.fill"
                android_material_icon_name="skip-next"
                size={24}
                color={colors.onPrimary}
              />
            </TouchableOpacity>
          </View>
        </LinearGradient>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: `${(player.position / player.duration) * 100}%` }]} />
        </View>
      </TouchableOpacity>
    </MiniplayerPartyMode>
  );
}
