
import React, { useEffect } from 'react';
import { Image, StyleSheet, ImageSourcePropType } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  withSequence,
  Easing,
} from 'react-native-reanimated';

interface AnimatingThumbnailProps {
  source: string | number | ImageSourcePropType | undefined;
  audioPeak: number;
  size: number;
  borderRadius?: number;
}

function resolveImageSource(source: string | number | ImageSourcePropType | undefined): ImageSourcePropType {
  if (!source) return { uri: '' };
  if (typeof source === 'string') return { uri: source };
  return source as ImageSourcePropType;
}

export function AnimatingThumbnail({
  source,
  audioPeak,
  size,
  borderRadius = 12,
}: AnimatingThumbnailProps) {
  const scale = useSharedValue(1);
  const rotation = useSharedValue(0);
  const glowOpacity = useSharedValue(0);

  useEffect(() => {
    // Scale animation based on audio peak
    const scaleValue = 1 + audioPeak * 0.15;
    scale.value = withSpring(scaleValue, {
      damping: 10,
      stiffness: 100,
    });

    // Subtle rotation based on audio peak
    rotation.value = withTiming(audioPeak * 5, { duration: 100 });

    // Glow effect that pulses with audio
    glowOpacity.value = withSequence(
      withTiming(audioPeak * 0.8, { duration: 100, easing: Easing.out(Easing.ease) }),
      withTiming(0, { duration: 300, easing: Easing.in(Easing.ease) })
    );
  }, [audioPeak]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: scale.value },
      { rotate: `${rotation.value}deg` },
    ],
  }));

  const glowStyle = useAnimatedStyle(() => ({
    opacity: glowOpacity.value,
  }));

  return (
    <Animated.View style={[styles.container, animatedStyle, { width: size, height: size }]}>
      {/* Glow effect behind the image */}
      <Animated.View
        style={[
          styles.glow,
          glowStyle,
          {
            width: size + 20,
            height: size + 20,
            borderRadius: borderRadius + 10,
          },
        ]}
      />
      <Image
        source={resolveImageSource(source)}
        style={[styles.image, { borderRadius }]}
        resizeMode="cover"
      />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    overflow: 'visible',
    alignItems: 'center',
    justifyContent: 'center',
  },
  glow: {
    position: 'absolute',
    backgroundColor: 'rgba(139, 92, 246, 0.5)',
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 10,
  },
  image: {
    width: '100%',
    height: '100%',
  },
});
