
import { IconSymbol } from '@/components/IconSymbol';
import { useAuth } from '@/contexts/AuthContext';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal,
  Image,
} from 'react-native';
import React from 'react';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, spacing, borderRadius, typography } from '@/styles/commonStyles';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
} from 'react-native-reanimated';

interface DrawerProps {
  visible: boolean;
  onClose: () => void;
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
  },
  drawer: {
    width: '85%',
    maxWidth: 340,
    height: '100%',
    backgroundColor: colors.surface,
  },
  header: {
    padding: spacing.xl,
    paddingTop: spacing.xl * 2,
  },
  headerGradient: {
    padding: spacing.xl,
    paddingTop: spacing.xl * 2.5,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.primaryContainer,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.onPrimaryContainer,
  },
  userDetails: {
    flex: 1,
  },
  headerTitle: {
    ...typography.titleLarge,
    color: colors.onPrimary,
    fontWeight: '700',
    marginBottom: spacing.xs,
  },
  headerSubtitle: {
    ...typography.bodyMedium,
    color: colors.onPrimary,
    opacity: 0.9,
  },
  content: {
    flex: 1,
  },
  section: {
    paddingVertical: spacing.md,
  },
  sectionTitle: {
    ...typography.labelSmall,
    color: colors.textSecondary,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.sm,
    textTransform: 'uppercase',
    fontWeight: '700',
    letterSpacing: 1,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    gap: spacing.md,
  },
  menuItemText: {
    ...typography.bodyLarge,
    color: colors.text,
    flex: 1,
    fontWeight: '500',
  },
  divider: {
    height: 1,
    backgroundColor: colors.outlineVariant,
    marginVertical: spacing.sm,
    marginHorizontal: spacing.md,
  },
  footer: {
    padding: spacing.xl,
    borderTopWidth: 1,
    borderTopColor: colors.outlineVariant,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.errorContainer,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    gap: spacing.sm,
  },
  logoutButtonText: {
    ...typography.labelLarge,
    color: colors.error,
    fontWeight: '600',
  },
  confirmModal: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.75)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  confirmContent: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.xl,
    padding: spacing.xl,
    width: '85%',
    maxWidth: 400,
  },
  confirmTitle: {
    ...typography.titleLarge,
    color: colors.text,
    fontWeight: '700',
    marginBottom: spacing.md,
  },
  confirmMessage: {
    ...typography.bodyMedium,
    color: colors.textSecondary,
    marginBottom: spacing.xl,
    lineHeight: 22,
  },
  confirmButtons: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  confirmButton: {
    flex: 1,
    padding: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  confirmButtonCancel: {
    backgroundColor: colors.surfaceVariant,
  },
  confirmButtonLogout: {
    backgroundColor: colors.error,
  },
  confirmButtonText: {
    ...typography.labelLarge,
    color: colors.text,
    fontWeight: '600',
  },
  confirmButtonTextLogout: {
    color: colors.onError,
  },
});

export default function Drawer({ visible, onClose }: DrawerProps) {
  const { user, signOut } = useAuth();
  const router = useRouter();
  const [confirmLogoutVisible, setConfirmLogoutVisible] = React.useState(false);

  const handleNavigate = (route: string) => {
    console.log('Navigating to:', route);
    onClose();
    router.push(route as any);
  };

  const handleLogout = () => {
    setConfirmLogoutVisible(true);
  };

  const confirmLogout = async () => {
    console.log('User confirmed logout');
    setConfirmLogoutVisible(false);
    onClose();
    try {
      await signOut();
      console.log('User signed out successfully');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const userName = user?.name || user?.email || 'User';
  const userInitial = userName.charAt(0).toUpperCase();

  return (
    <>
      <Modal
        visible={visible}
        transparent
        animationType="slide"
        onRequestClose={onClose}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={onClose}
        >
          <TouchableOpacity
            activeOpacity={1}
            style={styles.drawer}
            onPress={(e) => e.stopPropagation()}
          >
            <LinearGradient
              colors={[colors.primary, colors.primaryContainer, colors.secondaryContainer]}
              style={styles.headerGradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <View style={styles.userInfo}>
                <View style={styles.avatar}>
                  <Text style={styles.avatarText}>{userInitial}</Text>
                </View>
                <View style={styles.userDetails}>
                  <Text style={styles.headerTitle}>{userName}</Text>
                  <Text style={styles.headerSubtitle}>Music Player Pro</Text>
                </View>
              </View>
            </LinearGradient>

            <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Library</Text>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/(tabs)/(home)')}
                >
                  <IconSymbol
                    ios_icon_name="house.fill"
                    android_material_icon_name="home"
                    size={24}
                    color={colors.primary}
                  />
                  <Text style={styles.menuItemText}>Home</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/(tabs)/tracks')}
                >
                  <IconSymbol
                    ios_icon_name="music.note"
                    android_material_icon_name="music-note"
                    size={24}
                    color={colors.primary}
                  />
                  <Text style={styles.menuItemText}>Tracks</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/(tabs)/albums')}
                >
                  <IconSymbol
                    ios_icon_name="square.stack.fill"
                    android_material_icon_name="album"
                    size={24}
                    color={colors.primary}
                  />
                  <Text style={styles.menuItemText}>Albums</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/(tabs)/artists')}
                >
                  <IconSymbol
                    ios_icon_name="person.fill"
                    android_material_icon_name="person"
                    size={24}
                    color={colors.primary}
                  />
                  <Text style={styles.menuItemText}>Artists</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/(tabs)/playlists')}
                >
                  <IconSymbol
                    ios_icon_name="music.note.list"
                    android_material_icon_name="queue-music"
                    size={24}
                    color={colors.primary}
                  />
                  <Text style={styles.menuItemText}>Playlists</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.divider} />

              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Playback</Text>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/queue')}
                >
                  <IconSymbol
                    ios_icon_name="list.bullet"
                    android_material_icon_name="queue-music"
                    size={24}
                    color={colors.secondary}
                  />
                  <Text style={styles.menuItemText}>Queue</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/history')}
                >
                  <IconSymbol
                    ios_icon_name="clock.fill"
                    android_material_icon_name="history"
                    size={24}
                    color={colors.secondary}
                  />
                  <Text style={styles.menuItemText}>History</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.divider} />

              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Tools</Text>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/video-converter')}
                >
                  <IconSymbol
                    ios_icon_name="arrow.triangle.2.circlepath"
                    android_material_icon_name="sync"
                    size={24}
                    color={colors.tertiary}
                  />
                  <Text style={styles.menuItemText}>Video Converter</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/yt-downloader')}
                >
                  <IconSymbol
                    ios_icon_name="arrow.down.circle.fill"
                    android_material_icon_name="download"
                    size={24}
                    color={colors.tertiary}
                  />
                  <Text style={styles.menuItemText}>YouTube Downloader</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.divider} />

              <View style={styles.section}>
                <Text style={styles.sectionTitle}>More</Text>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/settings')}
                >
                  <IconSymbol
                    ios_icon_name="gear"
                    android_material_icon_name="settings"
                    size={24}
                    color={colors.text}
                  />
                  <Text style={styles.menuItemText}>Settings</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => handleNavigate('/about')}
                >
                  <IconSymbol
                    ios_icon_name="info.circle"
                    android_material_icon_name="info"
                    size={24}
                    color={colors.text}
                  />
                  <Text style={styles.menuItemText}>About</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>

            <View style={styles.footer}>
              <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
                <IconSymbol
                  ios_icon_name="arrow.right.square"
                  android_material_icon_name="logout"
                  size={20}
                  color={colors.error}
                />
                <Text style={styles.logoutButtonText}>Sign Out</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      <Modal
        visible={confirmLogoutVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setConfirmLogoutVisible(false)}
      >
        <View style={styles.confirmModal}>
          <View style={styles.confirmContent}>
            <Text style={styles.confirmTitle}>Sign Out</Text>
            <Text style={styles.confirmMessage}>
              Are you sure you want to sign out? Your playback will be stopped and you'll need to sign in again to access your library.
            </Text>
            <View style={styles.confirmButtons}>
              <TouchableOpacity
                style={[styles.confirmButton, styles.confirmButtonCancel]}
                onPress={() => setConfirmLogoutVisible(false)}
              >
                <Text style={styles.confirmButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.confirmButton, styles.confirmButtonLogout]}
                onPress={confirmLogout}
              >
                <Text style={[styles.confirmButtonText, styles.confirmButtonTextLogout]}>
                  Sign Out
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}
