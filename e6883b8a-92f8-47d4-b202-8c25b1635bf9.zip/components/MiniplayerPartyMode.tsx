
import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  Easing,
  interpolateColor,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';

interface MiniplayerPartyModeProps {
  enabled: boolean;
  colors: string[];
  children: React.ReactNode;
}

export function MiniplayerPartyMode({
  enabled,
  colors: gradientColors,
  children,
}: MiniplayerPartyModeProps) {
  const borderOpacity = useSharedValue(0.3);
  const borderWidth = useSharedValue(2);
  const colorProgress = useSharedValue(0);

  useEffect(() => {
    if (enabled) {
      // Breathing border opacity
      borderOpacity.value = withRepeat(
        withSequence(
          withTiming(1, { duration: 1000, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.3, { duration: 1000, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        true
      );

      // Breathing border width
      borderWidth.value = withRepeat(
        withSequence(
          withTiming(4, { duration: 1000, easing: Easing.inOut(Easing.ease) }),
          withTiming(2, { duration: 1000, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        true
      );

      // Color cycling animation
      colorProgress.value = withRepeat(
        withTiming(1, { duration: 3000, easing: Easing.linear }),
        -1,
        false
      );
    } else {
      borderOpacity.value = withTiming(0, { duration: 300 });
      borderWidth.value = withTiming(0, { duration: 300 });
      colorProgress.value = 0;
    }
  }, [enabled]);

  const animatedBorderStyle = useAnimatedStyle(() => ({
    opacity: borderOpacity.value,
    borderWidth: borderWidth.value,
  }));

  if (!enabled) {
    return <View style={styles.container}>{children}</View>;
  }

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.border, animatedBorderStyle]}>
        <LinearGradient
          colors={gradientColors}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      </Animated.View>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 12,
    borderColor: 'transparent',
  },
});
