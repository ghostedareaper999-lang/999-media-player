
import React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';

interface MediaControlsProps {
  isPlaying: boolean;
  isLooping: boolean;
  isShuffle: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onToggleLoop: () => void;
  onToggleShuffle: () => void;
  size?: 'small' | 'medium' | 'large';
  color?: string;
}

export function MediaControls({
  isPlaying,
  isLooping,
  isShuffle,
  onPlayPause,
  onNext,
  onPrevious,
  onToggleLoop,
  onToggleShuffle,
  size = 'medium',
  color = colors.text,
}: MediaControlsProps) {
  const iconSize = size === 'small' ? 24 : size === 'medium' ? 32 : 48;
  const playPauseSize = size === 'small' ? 40 : size === 'medium' ? 56 : 72;

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={onToggleShuffle} style={styles.button}>
        <IconSymbol
          ios_icon_name="shuffle"
          android_material_icon_name="shuffle"
          size={iconSize}
          color={isShuffle ? colors.primary : color}
        />
      </TouchableOpacity>

      <TouchableOpacity onPress={onPrevious} style={styles.button}>
        <IconSymbol
          ios_icon_name="backward.fill"
          android_material_icon_name="skip-previous"
          size={iconSize}
          color={color}
        />
      </TouchableOpacity>

      <TouchableOpacity
        onPress={onPlayPause}
        style={[styles.playButton, { width: playPauseSize, height: playPauseSize }]}
      >
        <IconSymbol
          ios_icon_name={isPlaying ? 'pause.fill' : 'play.fill'}
          android_material_icon_name={isPlaying ? 'pause' : 'play-arrow'}
          size={playPauseSize - 16}
          color={color}
        />
      </TouchableOpacity>

      <TouchableOpacity onPress={onNext} style={styles.button}>
        <IconSymbol
          ios_icon_name="forward.fill"
          android_material_icon_name="skip-next"
          size={iconSize}
          color={color}
        />
      </TouchableOpacity>

      <TouchableOpacity onPress={onToggleLoop} style={styles.button}>
        <IconSymbol
          ios_icon_name="repeat"
          android_material_icon_name="repeat"
          size={iconSize}
          color={isLooping ? colors.primary : color}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    width: '100%',
    paddingHorizontal: 20,
  },
  button: {
    padding: 8,
  },
  playButton: {
    borderRadius: 100,
    backgroundColor: colors.primaryContainer,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
