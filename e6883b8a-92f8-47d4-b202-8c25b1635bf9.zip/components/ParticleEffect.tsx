
import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  Easing,
  withSpring,
} from 'react-native-reanimated';
import { colors } from '@/styles/commonStyles';

interface ParticleEffectProps {
  audioPeak: number;
  enabled: boolean;
  particleCount?: number;
  color?: string;
}

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

interface ParticleProps {
  index: number;
  audioPeak: number;
  color: string;
  initialX: number;
  initialY: number;
}

function Particle({ index, audioPeak, color, initialX, initialY }: ParticleProps) {
  const translateX = useSharedValue(initialX);
  const translateY = useSharedValue(initialY);
  const opacity = useSharedValue(0.3);
  const scale = useSharedValue(1);

  useEffect(() => {
    // Speed increases with audio peak
    const speed = 2000 - audioPeak * 1500;
    const targetX = Math.random() * SCREEN_WIDTH;
    const targetY = Math.random() * SCREEN_HEIGHT;

    translateX.value = withRepeat(
      withTiming(targetX, { duration: speed, easing: Easing.inOut(Easing.ease) }),
      -1,
      true
    );

    translateY.value = withRepeat(
      withTiming(targetY, { duration: speed, easing: Easing.inOut(Easing.ease) }),
      -1,
      true
    );

    // Opacity pulses with audio
    opacity.value = withRepeat(
      withSequence(
        withTiming(0.3 + audioPeak * 0.6, { duration: 300 }),
        withTiming(0.1, { duration: 500 })
      ),
      -1,
      true
    );

    // Scale pulses with audio
    scale.value = withRepeat(
      withSequence(
        withSpring(1 + audioPeak * 0.8, { damping: 5, stiffness: 100 }),
        withTiming(0.6, { duration: 500 })
      ),
      -1,
      true
    );
  }, [audioPeak]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: scale.value },
    ],
    opacity: opacity.value,
  }));

  return (
    <Animated.View
      style={[
        styles.particle,
        animatedStyle,
        { backgroundColor: color },
      ]}
    />
  );
}

export function ParticleEffect({
  audioPeak,
  enabled,
  particleCount = 30,
  color = colors.primary,
}: ParticleEffectProps) {
  const particlePositions = useRef(
    Array.from({ length: particleCount }, () => ({
      x: Math.random() * SCREEN_WIDTH,
      y: Math.random() * SCREEN_HEIGHT,
    }))
  ).current;

  if (!enabled) return null;

  return (
    <View style={styles.container} pointerEvents="none">
      {particlePositions.map((pos, i) => (
        <Particle
          key={i}
          index={i}
          audioPeak={audioPeak}
          color={color}
          initialX={pos.x}
          initialY={pos.y}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  particle: {
    position: 'absolute',
    width: 6,
    height: 6,
    borderRadius: 3,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 5,
  },
});
