
import { useState, useEffect } from 'react';
import { colors } from '@/styles/commonStyles';
import { authenticatedPost } from '@/utils/api';

interface DynamicColors {
  vibrant: string;
  darkVibrant: string;
  lightVibrant: string;
  muted: string;
  darkMuted: string;
  lightMuted: string;
}

// Enhanced in-memory cache with timestamp for cache invalidation
interface CacheEntry {
  colors: DynamicColors;
  timestamp: number;
}

const colorCache: Record<string, CacheEntry> = {};
const CACHE_DURATION = 30 * 60 * 1000; // 30 minutes

export function useDynamicColors(artworkUrl?: string): DynamicColors | null {
  const [extractedColors, setExtractedColors] = useState<DynamicColors | null>(null);

  useEffect(() => {
    if (!artworkUrl) {
      setExtractedColors(null);
      return;
    }

    // Check cache first
    const cached = colorCache[artworkUrl];
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
      setExtractedColors(cached.colors);
      return;
    }

    extractColors(artworkUrl);
  }, [artworkUrl]);

  const extractColors = async (imageUrl: string) => {
    try {
      console.log('[DynamicColors] Extracting colors from:', imageUrl);
      const result = await authenticatedPost<DynamicColors>('/api/colors/extract', { imageUrl });
      console.log('[DynamicColors] Extracted colors:', result);
      
      // Cache the result with timestamp
      colorCache[imageUrl] = {
        colors: result,
        timestamp: Date.now(),
      };
      
      setExtractedColors(result);
    } catch (error) {
      console.error('[DynamicColors] Failed to extract colors from API, using enhanced defaults:', error);
      
      // Enhanced fallback with more vibrant colors
      const fallback: DynamicColors = {
        vibrant: colors.primary,
        darkVibrant: colors.primaryContainer,
        lightVibrant: colors.secondary,
        muted: colors.tertiary,
        darkMuted: colors.tertiaryContainer,
        lightMuted: colors.secondaryContainer,
      };
      
      colorCache[imageUrl] = {
        colors: fallback,
        timestamp: Date.now(),
      };
      
      setExtractedColors(fallback);
    }
  };

  return extractedColors;
}
